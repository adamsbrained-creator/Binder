package app.binder

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import android.content.Intent
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val model: BinderViewModel by viewModels()   // the same instance the screen gets from viewModel() below

    // [scrapbook hook 1] A binder:// link, or Scrapbook asking for something (see Bridge.kt). The first intent is read once, not again after a rotation.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        model.handleIntent(this, intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) model.handleIntent(this, intent)
        setContent {
            val vm: BinderViewModel = viewModel()
            val dark = when (vm.opts.theme) {
                "light" -> false
                "dark" -> true
                else -> isSystemInDarkTheme()
            }
            DisposableEffect(dark) {
                val style = SystemBarStyle.auto(AColor.TRANSPARENT, AColor.TRANSPARENT) { dark }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            BinderTheme(dark) { App(vm) }
        }
    }
}

@Composable
fun App(vm: BinderViewModel) {
    val nav = vm.nav
    val top = nav.top
    val overlay = vm.drawer || vm.menu || vm.ratingEdit != null || vm.sheet != null || vm.itemSheet != null || vm.quick != null || vm.statusFor != null || vm.newBindSheet
    BackHandler(enabled = overlay || vm.reorder || vm.selected != null || top != Route.Home || nav.stack.size > 1) {
        when {
            vm.ratingEdit != null -> vm.ratingEdit = null
            vm.statusFor != null -> vm.statusFor = null
            vm.sheet != null -> vm.sheet = null
            vm.itemSheet != null -> vm.itemSheet = null
            vm.selected != null -> vm.selected = null
            vm.newBindSheet -> vm.newBindSheet = false
            vm.quick != null -> vm.quick = null
            vm.menu -> vm.menu = false
            vm.drawer -> vm.drawer = false
            vm.reorder -> vm.reorder = false
            else -> nav.back()
        }
    }

    CompositionLocalProvider(LocalOpts provides vm.opts) {
        Box(Modifier.fillMaxSize().background(P.bg)) {
            Crossfade(targetState = top, label = "route") { r ->
                when (r) {
                    Route.Home -> HomeScreen(vm)
                    Route.Search -> SearchScreen(vm)
                    Route.More -> MoreScreen(vm)
                    Route.NewList -> NewListScreen(vm)
                    Route.About -> AboutScreen(vm)
                    is Route.Setting -> SettingsPageScreen(vm, r.page)
                    is Route.Lists -> ListsScreen(vm, r.mode)
                    is Route.Lst -> when (vm.lists.firstOrNull { it.id == r.id }?.kind) {
                        Kind.TRACKER -> TrackerScreen(vm, r.id)
                        Kind.TIME -> TimeScreen(vm, r.id)
                        Kind.HABITS -> HabitsScreen(vm, r.id)
                        Kind.HEARD -> HeardScreen(vm, r.id)
                        Kind.PRODUCTIVITY -> ProductivityScreen(vm, r.id)
                        else -> ListScreen(vm, r.id)
                    }
                    is Route.ItemEdit -> when (vm.lists.firstOrNull { it.id == r.listId }?.kind) {
                        Kind.TRACKER -> EntryScreen(vm, r.listId, r.itemId)
                        Kind.TIME -> DateScreen(vm, r.listId, r.itemId)
                        Kind.HABITS -> HabitEditScreen(vm, r.listId, r.itemId)
                        Kind.HEARD -> SongScreen(vm, r.listId, r.itemId)
                        Kind.PRODUCTIVITY -> ProductivityEntryScreen(vm, r.listId, r.itemId)
                        else -> ItemScreen(vm, r.listId, r.itemId)
                    }
                    is Route.Habit -> HabitDetailScreen(vm, r.listId, r.itemId)
                }
            }
            val topLevel = top == Route.Home || top == Route.Search || top == Route.More
            if (topLevel) NavBar(vm, top)
            val gap = if (topLevel) navHeight(vm.opts.nav) else 0
            val u = vm.undo
            if (vm.reorder) ReorderBar(vm, gap) else if (u != null) UndoBar(vm, u, gap)
            if (vm.drawer) Drawer(vm, top)
            if (vm.menu) MenuSheet(vm)
            val sh = vm.sheet
            val its = vm.itemSheet
            if (its != null) ItemSheet(vm, its)
            if (sh != null) ActionSheet(vm, sh)
            val q = vm.quick
            if (q != null) QuickAdd(vm, q)
            if (vm.newBindSheet) NewBindSheet(vm)
            val re = vm.ratingEdit
            if (re != null) RatingSheet(vm, re)
            val ic = vm.iconFor
            val icList = if (ic == null) null else vm.lists.firstOrNull { it.id == ic }
            if (icList != null) TimeIconSheet(vm, icList)
            val sf = vm.statusFor
            val sfList = if (sf == null) null else vm.lists.firstOrNull { it.id == sf }
            if (sfList != null) StatusSheet(vm, sfList)
        }
        val rn = vm.rename
        if (rn != null) RenameDialog(vm, rn)
        val ge = vm.groupDialog
        if (ge != null) GroupDialog(vm, ge)
    }
}
