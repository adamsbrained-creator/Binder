package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ───────── the Glass look: a soft coloured backdrop with frosted cards on it ─────────
// Used by the Productivity page (see Productivity.kt). The colours of each backdrop are in GlassLogic.kt.
// The cards are see-through white (or white-ish in dark mode) with a thin light edge, so the colours behind show through softly.

/** The glass look in use on a page: which backdrop, and whether the app is dark. */
@Immutable
class GlassLook(val bg: GlassBg, val dark: Boolean) {
    /** The fill of a glass card. [level] 0 is the airy one, 1 is stronger, 2 is nearly solid (the front card of a stack). */
    fun fill(level: Int = 0): Color {
        val a = if (dark) floatArrayOf(0.07f, 0.12f, 0.17f) else floatArrayOf(0.5f, 0.72f, 0.92f)
        return Color.White.copy(alpha = a[level.coerceIn(0, 2)])
    }

    /** The thin light line round a glass card. */
    fun edge(): Color = Color.White.copy(alpha = if (dark) 0.16f else 0.85f)
}

/** Set while a page uses the glass look; null means the classic flat cards. */
val LocalGlass = staticCompositionLocalOf<GlassLook?> { null }

fun Modifier.glassCard(g: GlassLook, shape: Shape, level: Int = 0): Modifier =
    this.clip(shape).background(g.fill(level)).border(1.dp, g.edge(), shape)

/** A card surface: glass while the page uses the glass look, otherwise the app's usual grey. */
@Composable
fun Modifier.pSurface(shape: Shape, level: Int = 0): Modifier {
    val g = LocalGlass.current
    return if (g == null) this.clip(shape).background(P.surface) else this.glassCard(g, shape, level)
}

/** The backdrop: a three-colour wash with three soft glows. Draws nothing for the Plain backdrop. */
@Composable
fun GlassBackdrop(bg: GlassBg, dark: Boolean, modifier: Modifier = Modifier.fillMaxSize()) {
    val base = if (dark) bg.darkBase else bg.base
    if (bg.isPlain || base.size < 2) {
        Box(modifier)
        return
    }
    val glowAlpha = if (dark) 0.45f else 0.85f
    Canvas(modifier) {
        val w = this.size.width
        val h = this.size.height
        drawRect(Brush.verticalGradient(base.map { Color(it) }))
        fun glow(c: Long, cx: Float, cy: Float, r: Float) {
            val centre = Offset(cx, cy)
            drawCircle(
                Brush.radialGradient(listOf(Color(c).copy(alpha = glowAlpha), Color(c).copy(alpha = 0f)), center = centre, radius = r),
                radius = r, center = centre,
            )
        }
        bg.glow.getOrNull(0)?.let { glow(it, w * 0.1f, h * 0.1f, w * 0.95f) }
        bg.glow.getOrNull(1)?.let { glow(it, w * 1.0f, h * 0.42f, w * 0.9f) }
        bg.glow.getOrNull(2)?.let { glow(it, w * 0.05f, h * 0.95f, w * 0.85f) }
    }
}

/** A round glass button (back, menu, previous / next). */
@Composable
fun GlassCircle(g: GlassLook, icon: ImageVector, desc: String, size: Dp = 48.dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).glassCard(g, CircleShape, 1).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = P.fg, modifier = Modifier.size(size * 0.46f)) }
}

/** The top bar of a glass page: a round back button, the name in a glass pill, and buttons on the right. */
@Composable
fun GlassHeader(g: GlassLook, title: String, onBack: () -> Unit, right: @Composable RowScope.() -> Unit) {
    Box(Modifier.fillMaxWidth().height(64.dp)) {
        Box(Modifier.align(Alignment.CenterStart)) { GlassCircle(g, Ic.Back, "Back", onClick = onBack) }
        Box(Modifier.align(Alignment.Center).widthIn(max = 170.dp).glassCard(g, CircleShape).padding(horizontal = 16.dp, vertical = 8.dp)) {
            Txt(title, 14, P.mute, maxLines = 1)
        }
        Row(Modifier.align(Alignment.CenterEnd), horizontalArrangement = Arrangement.spacedBy(8.dp), content = right)
    }
}

/**
 * Today / Workflow / All as one glass pill along the bottom, left of the corner button.
 * [endPad] keeps it clear of that button; [lift] raises it a row when the button is the wide labelled pill.
 */
@Composable
fun BoxScope.GlassDock(g: GlassLook, tabs: List<String>, selected: Int, endPad: Dp, lift: Dp, onSelect: (Int) -> Unit) {
    Row(
        Modifier.align(Alignment.BottomStart).navigationBarsPadding()
            .padding(start = 16.dp, end = endPad, bottom = 18.dp + lift)
            .fillMaxWidth().height(58.dp).glassCard(g, CircleShape, 1).padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        tabs.forEachIndexed { i, t ->
            val on = i == selected
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(CircleShape)
                    .background(if (on) Color.White.copy(alpha = if (g.dark) 0.92f else 1f) else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Txt(
                    t, 15, if (on) Color(0xFF111111) else P.mute,
                    weight = if (on) FontWeight.Medium else FontWeight.Normal, maxLines = 1,
                )
            }
        }
    }
}

/** A small tile that shows one backdrop in Settings: the wash, with a peeking card and a front card on it. */
@Composable
fun GlassSwatch(bg: GlassBg, dark: Boolean, on: Boolean, onClick: () -> Unit) {
    val look = remember(bg, dark) { GlassLook(bg, dark) }
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.width(76.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            Modifier.size(76.dp, 96.dp).clip(shape).background(P.bg)
                .border(if (on) 3.dp else 1.dp, if (on) Coral else P.line, shape),
        ) {
            GlassBackdrop(bg, dark)
            Column(Modifier.align(Alignment.BottomCenter).padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Box(Modifier.padding(horizontal = 5.dp).fillMaxWidth().height(9.dp).glassCard(look, CircleShape))
                Box(Modifier.fillMaxWidth().height(28.dp).glassCard(look, RoundedCornerShape(10.dp), 2))
            }
        }
        Txt(bg.name, 12, if (on) P.fg else P.mute, weight = if (on) FontWeight.Medium else FontWeight.Normal, maxLines = 1)
    }
}
