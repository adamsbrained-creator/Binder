package app.binder

// The plain maths of a Productivity bind (no Compose, so it can be tested on a normal JVM). The screens are in Productivity.kt.
//
// An entry is an Item: title = what you worked on, note = the description, sub = the mood (the name of one of Moods),
// stage = its place in the workflow, added = when it was logged, group = the project it belongs to ("" = General).
// A project is a Group of the bind. It may carry its own workflow (Group.stages, first to last; the last stage means done);
// without one it uses the default Plan / Doing / Review / Done. An entry's stage is an index into its project's workflow.
// Only optional keys were added to the file (the group's "stages"), so backups and older files need nothing new.

class Mood(val name: String, val emoji: String)

/** The moods you can pick on an entry, in the order they are shown. */
val Moods = listOf(
    Mood("Focused", "🎯"),
    Mood("Calm", "😌"),
    Mood("Energized", "⚡"),
    Mood("Anxious", "😰"),
    Mood("Stressed", "😖"),
)

/** Which of [Moods] this entry has; -1 when it has none (or one that is no longer offered). */
fun Item.moodIndex(): Int = Moods.indexOfFirst { it.name == sub }

fun Item.moodEmoji(): String = Moods.getOrNull(moodIndex())?.emoji ?: "📝"

/** The emoji an entry wears: its own when it has one, else its mood's. */
fun Item.faceEmoji(): String = emoji.ifBlank { moodEmoji() }

/** One emoji out of whatever was typed or pasted; "" for blank text or for letters and digits (anything else is welcome). */
fun cleanEmoji(s: String): String {
    val e = firstEmoji(s)
    if (e.isEmpty()) return ""
    return if (Character.isLetterOrDigit(e.codePointAt(0)) && !e.contains("\u20E3")) "" else e
}

// ───────── the cards of the Today tab ─────────

const val BLOCK_WEEK = "week"
const val BLOCK_STREAK = "streak"
const val BLOCK_ENTRIES = "entries"

/** The cards of the Today tab in their usual order. */
val TodayBlocks = listOf(BLOCK_WEEK, BLOCK_STREAK, BLOCK_ENTRIES)

/** The order to show the cards in: the saved one (names separated by commas), then any card it does not mention, in the usual order. Unknown names and repeats are ignored. */
fun blockOrder(saved: String): List<String> {
    val mine = saved.split(",").map { it.trim() }.filter { it in TodayBlocks }.distinct()
    return mine + TodayBlocks.filter { it !in mine }
}

/** The order to show the cards in: the saved one, and when nothing is saved yet the usual one, except that the glass look leads with the entries (the stack of cards). */
fun todayOrder(saved: String, glass: Boolean): List<String> =
    if (glass && saved.isBlank()) listOf(BLOCK_ENTRIES, BLOCK_WEEK, BLOCK_STREAK) else blockOrder(saved)

/** [order] with the card [from] moved to where [to] is, the cards between shifting by one; unchanged when either is not in it. */
fun movedBlock(order: List<String>, from: String, to: String): List<String> {
    val a = order.indexOf(from)
    val b = order.indexOf(to)
    if (a < 0 || b < 0 || a == b) return order
    return order.toMutableList().also {
        it.removeAt(a)
        it.add(b, from)
    }
}

// ───────── workflows ─────────

/** The workflow a project has until you give it its own: Plan, Doing, Review, Done. */
val WorkStages: List<String> get() = Kind.PRODUCTIVITY.stages

const val MinStages = 2
const val MaxStages = 6

/** A ready-made workflow to start a project from. */
class FlowTemplate(val name: String, val stages: List<String>)

val FlowTemplates = listOf(
    FlowTemplate("Plan to done", listOf("Plan", "Doing", "Review", "Done")),
    FlowTemplate("To do", listOf("To do", "In progress", "Done")),
    FlowTemplate("Ship it", listOf("Backlog", "Building", "Testing", "Shipped")),
    FlowTemplate("Study", listOf("Learn", "Practice", "Review", "Mastered")),
    FlowTemplate("Writing", listOf("Idea", "Draft", "Edit", "Published")),
)

/** The names a workflow editor should save: trimmed, blanks dropped, at most [MaxStages]; the default one if fewer than [MinStages] are left. */
fun cleanFlow(names: List<String>): List<String> {
    val c = names.map { it.trim() }.filter { it.isNotEmpty() }.take(MaxStages)
    return if (c.size < MinStages) WorkStages else c
}

/** What a project stores for [names]: nothing at all when it is just the default workflow. */
fun flowToStore(names: List<String>): List<String> = cleanFlow(names).let { if (it == WorkStages) emptyList() else it }

/** The workflow of a project ("" = General): its own stages, or the default when it has none (or fewer than two). */
fun BinderList.flowOf(gid: String): List<String> =
    groups.firstOrNull { it.id == gid }?.stages?.takeIf { it.size >= MinStages } ?: WorkStages

/** The workflow this entry follows: the one of its project. */
fun BinderList.flowFor(item: Item): List<String> = flowOf(groupIdOf(item))

/** Where the entry sits in [flow]; a stage past the end (the workflow got shorter) counts as the last one. */
fun Item.stageIn(flow: List<String>): Int = stage.coerceIn(0, flow.lastIndex)

fun Item.isFinishedIn(flow: List<String>): Boolean = stageIn(flow) == flow.lastIndex

/** The stage after [stage]; after the last one it starts over at the first. */
fun nextStageIn(flow: List<String>, stage: Int): Int = (stage.coerceIn(0, flow.lastIndex) + 1) % flow.size

/** How many of [items] sit in each stage of [flow]. */
fun stageCountsIn(items: List<Item>, flow: List<String>): List<Int> = flow.indices.map { s -> items.count { it.stageIn(flow) == s } }

/** Share of [entries] that have reached the last stage of their own project's workflow (0 when there are none). */
fun BinderList.finishedShare(entries: List<Item>): Float =
    if (entries.isEmpty()) 0f else entries.count { it.isFinishedIn(flowFor(it)) }.toFloat() / entries.size

// ───────── projects ─────────

/** Which entries a page shows: every project at once. */
const val ALL_PROJECTS = "*"

/** The entries of one project ([gid] "" = General, those in no project), or all of them for [ALL_PROJECTS]. */
fun BinderList.inProject(gid: String): List<Item> =
    if (gid == ALL_PROJECTS) items else items.filter { groupIdOf(it) == gid }

/** The name to show for a project id. */
fun BinderList.projectName(gid: String): String = groups.firstOrNull { it.id == gid }?.name?.ifBlank { "Project" } ?: "General"

// ───────── days and streaks ─────────

/** The day numbers (see epochDay) on which at least one entry was logged. */
fun loggedDays(items: List<Item>): Set<Int> = items.map { epochDay(it.added) }.toSet()

/** Days in a row with an entry, counted back from today. A today with nothing logged yet does not break the streak. */
fun entryStreak(days: Set<Int>, today: Int): Int {
    var d = if (today in days) today else today - 1
    var n = 0
    while (d in days) {
        n++
        d--
    }
    return n
}

/** The longest run of days in a row with an entry, ever. */
fun bestEntryStreak(days: Set<Int>): Int {
    var best = 0
    var run = 0
    var prev = 0
    var first = true
    for (d in days.sorted()) {
        run = if (!first && d == prev + 1) run + 1 else 1
        if (run > best) best = run
        prev = d
        first = false
    }
    return best
}

/** How far the streak ring is filled: the current streak against the best one. */
fun streakFraction(streak: Int, best: Int): Float =
    if (best <= 0) 0f else (streak.toFloat() / best).coerceIn(0f, 1f)

/** The title and the line under it on the streak card. */
fun streakText(streak: Int): Pair<String, String> = when {
    streak <= 0 -> "Start a new streak" to "Add an entry today to get going."
    streak >= 7 -> "You’ve been keeping track" to "You’ve added an entry every day for the past week."
    streak == 1 -> "Nice start" to "You’ve logged today. Come back tomorrow to keep it going."
    else -> "You’re on a roll" to "You’ve added an entry $streak days in a row."
}

/** The seven day numbers of the week that holds [today], when weeks start on [firstDow] (Calendar.firstDayOfWeek). */
fun weekOf(today: Int, firstDow: Int): List<Int> {
    val start = today - rowInWeek(today, firstDow)
    return (0..6).map { start + it }
}

enum class DayState { DONE, TODAY, MISSED, UPCOMING }

/** How one square of the week strip looks: ticked, today (nothing yet), missed, or still to come. */
fun dayState(day: Int, today: Int, days: Set<Int>): DayState = when {
    day in days -> DayState.DONE
    day == today -> DayState.TODAY
    day > today -> DayState.UPCOMING
    else -> DayState.MISSED
}

// ───────── lists of entries ─────────

/** The entries logged today, newest first. */
fun todaysEntries(items: List<Item>, now: Long): List<Item> {
    val today = epochDay(now)
    return items.filter { epochDay(it.added) == today }.sortedByDescending { it.added }
}

/** The entries with this mood (a [mood] of -1 keeps every entry), then those whose title, description or mood contain [q]. */
fun List<Item>.filtered(mood: Int, q: String): List<Item> = filter { mood < 0 || it.moodIndex() == mood }
    .filter { q.isBlank() || it.title.contains(q, true) || it.note.contains(q, true) || it.sub.contains(q, true) }

// ───────── a whole bind ─────────

/** How much of today's work is done: the ring on Home. */
fun productivityFraction(l: BinderList, now: Long): Float = l.finishedShare(todaysEntries(l.items, now))

/** The small line under the bind's name on Home: "2 today · 6 day streak". */
fun productivityLine(items: List<Item>, now: Long): String {
    if (items.isEmpty()) return "No entries yet"
    val streak = entryStreak(loggedDays(items), epochDay(now))
    val today = todaysEntries(items, now).size
    return if (streak > 0) "$today today · $streak day streak" else "$today today"
}

/** The big thing on a small card: the streak in days, "6d". */
fun productivityFace(items: List<Item>, now: Long): String = "${entryStreak(loggedDays(items), epochDay(now))}d"

/** The emoji of the latest entry, its own or its mood's (Home wears it), null when there are none or the bind is not a Productivity bind. */
fun BinderList.productivityEmoji(): String? =
    if (kind.isProductivity) items.maxByOrNull { it.added }?.faceEmoji() else null
