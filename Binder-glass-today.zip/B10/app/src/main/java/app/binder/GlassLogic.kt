package app.binder

// The colours behind the Productivity page's "Glass" look (no Compose here, so it can be tested on a normal JVM).
// The drawing is in Glass.kt. Colours are 0xAARRGGBB.

/**
 * One backdrop: a three-colour wash from top to bottom ([base] in light mode, [darkBase] in dark mode) with three soft glows on it ([glow]).
 * A backdrop with no colours ("Plain") draws nothing, so the glass cards sit on the app's own background.
 */
class GlassBg(val name: String, val base: List<Long>, val darkBase: List<Long>, val glow: List<Long>) {
    val isPlain: Boolean get() = base.isEmpty()
}

/** The backdrops offered in Settings > Productivity look (and in the Productivity menu > Background). The first one is the default. */
val GlassBgs = listOf(
    GlassBg("Blush", listOf(0xFFFBD9D0, 0xFFF7DDE6, 0xFFE4DDF6), listOf(0xFF2A1A24, 0xFF1F1626, 0xFF161226), listOf(0xFFFFB98A, 0xFFC9B8FF, 0xFFFFC9DD)),
    GlassBg("Sunset", listOf(0xFFFFE3C2, 0xFFFFD0C0, 0xFFF6C6DA), listOf(0xFF2E1C14, 0xFF2A161A, 0xFF1E1220), listOf(0xFFFFB36B, 0xFFFF8FA3, 0xFFFFD27A)),
    GlassBg("Ocean", listOf(0xFFD8ECFA, 0xFFD2E3F8, 0xFFDCD8F6), listOf(0xFF0F2030, 0xFF101C33, 0xFF141733), listOf(0xFF7FC4F5, 0xFF9DB4F5, 0xFF8FE0E8)),
    GlassBg("Mint", listOf(0xFFDCF3E6, 0xFFD6EFEA, 0xFFE3EEF8), listOf(0xFF0F2A22, 0xFF0E2628, 0xFF121E2C), listOf(0xFF8FE3B4, 0xFF8FDDE0, 0xFFBFE6A0)),
    GlassBg("Lilac", listOf(0xFFE8E0FA, 0xFFEFDDF3, 0xFFF8DDEA), listOf(0xFF1E1633, 0xFF241633, 0xFF2A1530), listOf(0xFFB9A6F5, 0xFFE3A7E6, 0xFFF5A9C6)),
    GlassBg("Sand", listOf(0xFFF3EBDD, 0xFFEFE6DA, 0xFFE9E3DC), listOf(0xFF24201A, 0xFF201C18, 0xFF1A1814), listOf(0xFFF0D49A, 0xFFE8C3A6, 0xFFD6D2B8)),
    GlassBg("Plain", emptyList(), emptyList(), emptyList()),
)

/** The backdrop at [i]; an index that is out of range (an old or damaged setting) gives the nearest one. */
fun glassBgAt(i: Int): GlassBg = GlassBgs[i.coerceIn(0, GlassBgs.lastIndex)]
