package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class GlassTest {
    @Test fun theGlassLookIsTheDefaultOnBlush() {
        assertEquals(ProdLook.GLASS, Opts().prodLook)
        assertEquals(0, Opts().prodBg)
        assertEquals("Blush", glassBgAt(Opts().prodBg).name)
        assertEquals(2, ProdLook.entries.size)
    }

    @Test fun everyBackdropIsWellFormed() {
        assertTrue(GlassBgs.size >= 2)
        assertEquals(GlassBgs.size, GlassBgs.map { it.name }.distinct().size)    // names are unique
        GlassBgs.forEach { b ->
            if (b.isPlain) {
                assertTrue(b.base.isEmpty() && b.darkBase.isEmpty() && b.glow.isEmpty())
            } else {
                assertEquals(3, b.base.size)
                assertEquals(3, b.darkBase.size)
                assertEquals(3, b.glow.size)
                (b.base + b.darkBase + b.glow).forEach { c -> assertEquals(0xFFL, c ushr 24) }   // fully opaque 0xAARRGGBB
            }
        }
        assertTrue(GlassBgs.last().isPlain)
        assertFalse(GlassBgs.first().isPlain)
    }

    @Test fun anIndexOutOfRangeGivesTheNearestBackdrop() {
        assertSame(GlassBgs.first(), glassBgAt(-5))
        assertSame(GlassBgs.last(), glassBgAt(999))
        assertSame(GlassBgs[2], glassBgAt(2))
    }

    @Test fun theGlassLookLeadsWithTheEntriesUntilYouRearrange() {
        assertEquals(listOf(BLOCK_ENTRIES, BLOCK_WEEK, BLOCK_STREAK), todayOrder("", glass = true))
        assertEquals(listOf(BLOCK_WEEK, BLOCK_STREAK, BLOCK_ENTRIES), todayOrder("", glass = false))
        // a saved order wins in both looks
        assertEquals(listOf(BLOCK_STREAK, BLOCK_WEEK, BLOCK_ENTRIES), todayOrder("streak,week", glass = true))
        assertEquals(listOf(BLOCK_STREAK, BLOCK_WEEK, BLOCK_ENTRIES), todayOrder("streak,week", glass = false))
    }
}
