package app.binder

import org.junit.Assert.assertEquals
import org.junit.Test

class NewBindStyleTest {
    @Test fun gridIsTheDefault() {
        assertEquals(NewBindStyle.GRID, Opts().newBind)
    }

    @Test fun theSheetShowsEveryTemplateInRowsOfFour() {
        val rows = KindGroups.flatMap { it.second }.chunked(4)
        assertEquals(listOf(4, 4, 4, 3), rows.map { it.size })
    }
}
