package app.binder

import org.json.JSONArray
import org.json.JSONObject

// Saving and loading the lists as JSON. Kept apart from the ViewModel so it can be tested on a plain JVM.

fun listsToJson(all: List<BinderList>): JSONObject {
    val arr = JSONArray()
    for (b in all) {
        val items = JSONArray()
        for (i in b.items) {
            items.put(
                JSONObject().put("id", i.id).put("title", i.title).put("sub", i.sub).put("stage", i.stage)
                    .put("rating", i.rating.toDouble()).put("note", i.note).put("added", i.added)
                    .put("cover", i.cover).put("images", JSONArray(i.images))
                    .put("sourceName", i.sourceName).put("sourceId", i.sourceId).put("sourceUrl", i.sourceUrl)
                    .put("year", i.year).put("genre", i.genre).put("description", i.description)
                    .put("detailsPending", i.detailsPending)
                    .apply { if (i.extra.isNotEmpty()) put("extra", i.extra) }
                    .apply { if (i.due != 0L) put("due", i.due) }
                    .apply { if (i.group.isNotEmpty()) put("group", i.group) }
                    .apply { if (i.marks.isNotEmpty()) put("marks", JSONObject().also { m -> for ((d, n) in i.marks) m.put(d.toString(), n) }) }
                    .apply { if (i.target != 1) put("target", i.target) }
                    .apply { if (i.streakGoal != 0) put("streakGoal", i.streakGoal) }
                    .apply { if (i.scrap.isNotEmpty()) put("scrap", i.scrap) }
                    .apply { if (i.emoji.isNotEmpty()) put("emoji", i.emoji) }
            )
        }
        arr.put(
            JSONObject().put("id", b.id).put("name", b.name).put("kind", b.kind.name)
                .put("layout", b.layout.name).put("sort", b.sort.name).put("pinned", b.pinned)
                .put("created", b.created).put("columns", b.columns)
                .put("under", JSONArray(b.under.map { it.name })).put("items", items)
                .apply { if (b.source != null) put("source", b.source.name) }
                .apply { if (b.timeIcon != TimeIcon.TILE) put("timeIcon", b.timeIcon.name) }
                .apply { if (b.groups.isNotEmpty()) put("groups", JSONArray(b.groups.map { g -> JSONObject().put("id", g.id).put("name", g.name).apply { if (g.stages.isNotEmpty()) put("stages", JSONArray(g.stages)) } })) }
                .apply { if (b.stageNames.any { it.isNotBlank() }) put("stageNames", JSONArray(b.stageNames)) }
                .apply { if (b.stageHidden.isNotEmpty()) put("stageHidden", JSONArray(b.stageHidden.sorted())) }
                .apply { if (b.emoji.isNotEmpty()) put("emoji", b.emoji) }
                .apply { if (b.tint >= 0) put("tint", b.tint) }
                .apply { if (b.accent != 0) put("accent", b.accent) }
                .apply { if (b.image.isNotEmpty()) put("image", b.image) }
                .apply { if (b.imageFill) put("imageFill", true) }
                .apply { if (b.caption.isNotEmpty()) put("caption", b.caption) }
                .apply { if (b.blocks.isNotEmpty()) put("blocks", b.blocks) }
                .apply { if (b.tintStrength != 1) put("tintStrength", b.tintStrength) }
                .apply { if (!b.showMark) put("showMark", false) }
                .apply { if (!b.showProgress) put("showProgress", false) }
                .apply { if (!b.showLine) put("showLine", false) }
                .apply { if (b.corners != 1) put("corners", b.corners) }
                .apply { if (b.cardColor >= 0) put("cardColor", b.cardColor) }
        )
    }
    return JSONObject().put("format", "binder").put("version", 3).put("lists", arr)
}

/** A habit's check-ins: {"20376": 1, ...} (day number -> times). Anything unreadable is skipped. */
private fun readMarks(o: JSONObject?): Map<Int, Int> {
    if (o == null) return emptyMap()
    val out = HashMap<Int, Int>()
    val keys = o.keys()
    while (keys.hasNext()) {
        val k = keys.next()
        val day = k.toIntOrNull() ?: continue
        val n = o.optInt(k, 0)
        if (n > 0) out[day] = n
    }
    return out
}

/** Reads both the new format and the old version 0.1 file (a plain list). */
fun parseLists(s: String): List<BinderList> {
    val t = s.trim()
    val arr = if (t.startsWith("[")) JSONArray(t) else JSONObject(t).getJSONArray("lists")
    return List(arr.length()) { n ->
        val o = arr.getJSONObject(n)
        val its = o.getJSONArray("items")
        val items = List(its.length()) { m ->
            val i = its.getJSONObject(m)
            val imgs = i.optJSONArray("images")
            Item(
                id = i.getString("id"), title = i.getString("title"), sub = i.optString("sub"),
                stage = i.optInt("stage"), rating = i.optDouble("rating", 0.0).toFloat(),
                note = i.optString("note"), added = i.optLong("added"), cover = i.optInt("cover", -1),
                images = if (imgs == null) emptyList() else List(imgs.length()) { k -> imgs.getString(k) },
                sourceName = i.optString("sourceName"), sourceId = i.optString("sourceId"),
                sourceUrl = i.optString("sourceUrl"), year = i.optString("year"),
                genre = i.optString("genre"), description = i.optString("description"),
                detailsPending = i.optBoolean("detailsPending", false), extra = i.optString("extra"),
                due = i.optLong("due", 0L), group = i.optString("group"),
                marks = readMarks(i.optJSONObject("marks")),
                target = i.optInt("target", 1).coerceAtLeast(1), streakGoal = i.optInt("streakGoal", 0).coerceAtLeast(0),
                scrap = i.optString("scrap"), emoji = i.optString("emoji"),
            )
        }
        val underArr = o.optJSONArray("under")
        val under = if (underArr == null) setOf(Under.TITLE, Under.RATING) else
            (0 until underArr.length()).mapNotNull { k -> Under.entries.firstOrNull { it.name == underArr.optString(k) } }.toSet()
        val groupArr = o.optJSONArray("groups")
        val groups = if (groupArr == null) emptyList() else List(groupArr.length()) { k ->
            val g = groupArr.getJSONObject(k)
            val st = g.optJSONArray("stages")
            Group(id = g.getString("id"), name = g.optString("name"), stages = if (st == null) emptyList() else List(st.length()) { j -> st.optString(j) })
        }
        val namesArr = o.optJSONArray("stageNames")
        val stageNames = if (namesArr == null) emptyList() else List(namesArr.length()) { k -> namesArr.optString(k) }
        val hiddenArr = o.optJSONArray("stageHidden")
        val stageHidden = if (hiddenArr == null) emptySet() else (0 until hiddenArr.length()).map { k -> hiddenArr.optInt(k, -1) }.filter { it >= 0 }.toSet()
        BinderList(
            id = o.getString("id"), name = o.getString("name"),
            kind = runCatching { Kind.valueOf(o.getString("kind")) }.getOrDefault(Kind.BOOKS),
            layout = runCatching { Layout.valueOf(o.getString("layout")) }.getOrDefault(Layout.GRID),
            sort = runCatching { Sort.valueOf(o.getString("sort")) }.getOrDefault(Sort.MANUAL),
            pinned = o.optBoolean("pinned", false),
            created = o.optLong("created"), items = items,
            columns = o.optInt("columns", 3).coerceIn(2, 4), under = under,
            source = Source.entries.firstOrNull { it.name == o.optString("source") },
            timeIcon = TimeIcon.entries.firstOrNull { it.name == o.optString("timeIcon") } ?: TimeIcon.TILE,
            groups = groups, stageNames = stageNames, stageHidden = stageHidden,
            emoji = o.optString("emoji"), tint = o.optInt("tint", -1).takeIf { it >= 0 } ?: -1,
            accent = o.optInt("accent", 0), image = o.optString("image"),
            imageFill = o.optBoolean("imageFill", false), caption = o.optString("caption"),
            blocks = o.optString("blocks"),
            tintStrength = o.optInt("tintStrength", 1).coerceIn(0, 2),
            showMark = o.optBoolean("showMark", true),
            showProgress = o.optBoolean("showProgress", true),
            showLine = o.optBoolean("showLine", true),
            corners = o.optInt("corners", 1).coerceIn(0, 2),
            cardColor = o.optInt("cardColor", -1).takeIf { it in 0..MAX_CARD } ?: -1,
        )
    }
}
