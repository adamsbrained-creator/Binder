package app.binder

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// The "Customize look" sheet of a bind (press and hold a bind > Customize look): everything about how it looks, in one place.
// A live preview of its Home card on top, then the text under its name, a picture, its accent colour, its background and its icon.

@Composable
private fun AccentDot(color: Color?, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(color ?: P.surface)
            .border(2.dp, if (selected) P.fg else P.line, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { if (color == null) Txt("App", 12, P.mute) }
}

/** A slider drawn as the colours it picks from, with a round handle. [value] is 0 to 1. */
@Composable
private fun GradientSlider(label: String, valueText: String, value: Float, stops: List<Color>, onChange: (Float) -> Unit) {
    val change by rememberUpdatedState(onChange)
    Column(Modifier.padding(top = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Txt(label, 13, P.mute)
            Txt(valueText, 13, P.mute)
        }
        BoxWithConstraints(
            Modifier.padding(top = 6.dp).fillMaxWidth().height(36.dp).clip(CircleShape)
                .background(Brush.horizontalGradient(stops))
                .pointerInput(Unit) { detectTapGestures { o -> change((o.x / size.width).coerceIn(0f, 1f)) } }
                .pointerInput(Unit) { detectHorizontalDragGestures { c, _ -> c.consume(); change((c.position.x / size.width).coerceIn(0f, 1f)) } },
        ) {
            Box(
                Modifier.offset(x = (maxWidth - 32.dp) * value.coerceIn(0f, 1f) + 0.dp, y = 2.dp).size(32.dp)
                    .border(3.dp, Color.White, CircleShape).border(1.dp, Color.Black.copy(alpha = 0.25f), CircleShape),
            )
        }
    }
}

@Composable
private fun LookToggle(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Txt(title, 15, weight = FontWeight.Medium)
            Txt(sub, 12, P.mute, Modifier.padding(top = 1.dp))
        }
        Toggle(on, onChange)
    }
}

@Composable
fun BoxScope.LookSheet(vm: BinderViewModel, l: BinderList) {
    var emoji by remember { mutableStateOf(l.emoji) }
    var custom by remember { mutableStateOf("") }
    var tint by remember { mutableStateOf(l.tint) }
    var accent by remember { mutableStateOf(l.accent) }
    var hex by remember { mutableStateOf("") }
    var image by remember { mutableStateOf(l.image) }
    var fill by remember { mutableStateOf(l.imageFill) }
    var caption by remember { mutableStateOf(l.caption) }
    var strength by remember { mutableStateOf(l.tintStrength) }
    var showMark by remember { mutableStateOf(l.showMark) }
    var showProgress by remember { mutableStateOf(l.showProgress) }
    var showLine by remember { mutableStateOf(l.showLine) }
    var corners by remember { mutableStateOf(l.corners) }
    var cardColor by remember { mutableStateOf(l.cardColor) }
    // the sliders: they start where the bind's colour is (its own, or the preset it uses)
    var sh by remember { mutableStateOf(if (l.cardColor >= 0) cardHue(l.cardColor) else Tints.getOrNull(l.tint)?.hue?.toInt() ?: 210) }
    var ss by remember { mutableStateOf(if (l.cardColor >= 0) cardSat(l.cardColor) else if (l.tint in Tints.indices) 65 else 0) }
    var sb by remember { mutableStateOf(if (l.cardColor >= 0) cardBright(l.cardColor) else listOf(25, 50, 75)[l.tintStrength.coerceIn(0, 2)]) }
    val darkTheme = P.bg == DarkPal.bg
    val save = {
        vm.setLook(l.id, emoji, tint, accent, image, fill, caption)
        vm.setCardStyle(l.id, strength, showMark, showProgress, showLine, corners, cardColor)
        vm.lookFor = null
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importImages(listOf(uri)) { names -> if (names.isNotEmpty()) image = names[0] }
    }
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.62f).dp
    BackHandler(true) { save() }   // back keeps what was set, like tapping outside

    SheetFrame(save) {
        Txt("Look", 22, weight = FontWeight.Medium)
        Txt("How ${l.name} looks on the home screen and inside.", 12, P.mute, Modifier.padding(top = 2.dp, bottom = 12.dp))
        Column(Modifier.heightIn(max = maxH).verticalScroll(rememberScrollState())) {
            val shown = l.copy(
                emoji = emoji, tint = tint, accent = accent, image = image,
                imageFill = fill && image.isNotEmpty(), caption = caption.trim(),
                tintStrength = strength, showMark = showMark, showProgress = showProgress, showLine = showLine, corners = corners,
                cardColor = cardColor,
            )
            Row(Modifier.fillMaxWidth()) {
                RingTile(shown, Modifier.weight(1f), {}, {})
                Spacer(Modifier.weight(1f))
            }

            Cap("TEXT")
            Field("Line under the name (empty = automatic)", caption) { caption = it }

            Cap("PICTURE")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill(if (image.isEmpty()) "Add picture" else "Change picture") {
                    pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (image.isNotEmpty()) Pill("Remove") { image = ""; fill = false }
            }
            if (image.isNotEmpty()) {
                Seg(listOf("Small icon", "Fill the card"), if (fill) 1 else 0, Modifier.padding(top = 10.dp)) { fill = it == 1 }
            }

            Cap("ACCENT")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AccentDot(null, accent == 0) { accent = 0; hex = "" }
                BindAccents.forEach { a ->
                    AccentDot(a.color, accent == a.color.toArgb()) { accent = a.color.toArgb(); hex = "" }
                }
            }
            Field("Or type a colour, like #F5B83D", hex, Modifier.padding(top = 10.dp)) { v ->
                hex = v
                val c = parseHexColor(v)
                if (c != null) accent = c
            }

            Cap("CARD STYLE")
            Txt("Colour strength", 13, P.mute, Modifier.padding(bottom = 8.dp))
            Seg(TintStrengths, strength) { strength = it }
            Txt("Corners", 13, P.mute, Modifier.padding(top = 14.dp, bottom = 8.dp))
            Seg(listOf("Square", "Usual", "Round"), corners) { corners = it }
            LookToggle("Icon", "The ring, emoji or face on its card.", showMark) { showMark = it }
            LookToggle("Progress line", "On its small card in the Pinned view.", showProgress) { showProgress = it }
            LookToggle("Line under the name", "The count or the text you wrote above.", showLine) { showLine = it }

            LookPicker(
                strength = strength,
                name = l.name, emoji = emoji, tint = if (cardColor >= 0) -2 else if (tint < 0) -1 else tint, custom = custom,
                onEmoji = { emoji = it; custom = "" },
                onTint = { i ->
                    tint = i; cardColor = -1
                    // the sliders jump to the preset that was tapped, ready to be fine-tuned
                    sh = Tints.getOrNull(i)?.hue?.toInt() ?: 210
                    ss = if (i in Tints.indices) 65 else 0
                    sb = listOf(25, 50, 75)[strength.coerceIn(0, 2)]
                },
                afterSwatches = {
                    Txt("Or make your own", 13, P.mute, Modifier.padding(top = 16.dp))
                    GradientSlider(
                        "Hue", "$sh°", sh / 359f,
                        (0..6).map { hslColor(it * 60f, 0.9f, 0.5f) },
                    ) { v -> sh = (v * 359).toInt(); cardColor = packCard(sh, ss, sb) }
                    GradientSlider(
                        "Saturation", "$ss%", ss / 100f,
                        listOf(customShade(sh, 0, sb, darkTheme), customShade(sh, 100, sb, darkTheme)),
                    ) { v -> ss = (v * 100).toInt(); cardColor = packCard(sh, ss, sb) }
                    GradientSlider(
                        "Brightness", "$sb%", sb / 100f,
                        listOf(customShade(sh, ss, 0, darkTheme), customShade(sh, ss, 100, darkTheme)),
                    ) { v -> sb = (v * 100).toInt(); cardColor = packCard(sh, ss, sb) }
                    if (cardColor >= 0) Box(Modifier.padding(top = 12.dp)) { Pill("Back to the presets") { cardColor = -1 } }
                },
                onCustom = { custom = firstEmoji(it); emoji = custom },
                showPreview = false,
            )
            Spacer(Modifier.height(8.dp))
        }
        BigButton("Done", Modifier.padding(top = 12.dp)) { save() }
    }
}
