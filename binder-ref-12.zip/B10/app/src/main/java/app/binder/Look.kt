package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// The look of a bind: the colour behind its card on Home and the icon it wears there.
// A bind saves them as two optional keys ("tint" = a place in Tints, "emoji" = the icon). Without them a bind looks as it always did.

/**
 * A background colour for a bind's card. It is one hue; the shade is worked out from it for the theme and the strength
 * (Soft / Rich / Vivid), so the colours stay clean and never turn muddy or washed out. Light text on dark cards, dark text on light ones.
 */
class Tint(val name: String, val hue: Float, val sat: Float = 1f)

val Tints = listOf(
    Tint("Butter", 46f), Tint("Rose", 346f), Tint("Peach", 22f), Tint("Lavender", 256f),
    Tint("Sky", 208f), Tint("Aqua", 178f), Tint("Mint", 140f), Tint("Lime", 82f),
    Tint("Orchid", 290f), Tint("Coral", 6f), Tint("Sand", 36f, 0.55f), Tint("Slate", 215f, 0.22f),
)

/** The names of the three strengths of a card colour, in the order a bind saves them. */
val TintStrengths = listOf("Soft", "Rich", "Vivid")

/** The shade of this colour in light or dark mode at a strength (0 = Soft, 1 = Rich, 2 = Vivid). */
fun Tint.shade(dark: Boolean, strength: Int): Color {
    val k = strength.coerceIn(0, 2)
    val s: Float
    val l: Float
    if (dark) {
        s = listOf(0.42f, 0.55f, 0.66f)[k]
        l = listOf(0.17f, 0.25f, 0.34f)[k]
    } else {
        s = listOf(0.90f, 0.88f, 0.86f)[k]
        l = listOf(0.92f, 0.85f, 0.75f)[k]
    }
    return hslColor(hue, (s * sat).coerceIn(0f, 1f), l)
}

// ───────── a colour of your own, from three sliders ─────────
// Hue (0 to 359), saturation (0 to 100) and brightness (0 to 100) are packed in one whole number, so a bind saves one small key.
// The slider's brightness is relative to the theme (dark cards stay deep, light cards stay light) and the result is always nudged
// until the text on top stays readable, so no slider position can make a card you cannot read.

const val MAX_CARD = 359 * 10201 + 100 * 101 + 100

fun packCard(hue: Int, sat: Int, bright: Int): Int = hue.coerceIn(0, 359) * 10201 + sat.coerceIn(0, 100) * 101 + bright.coerceIn(0, 100)
fun cardHue(v: Int): Int = (v / 10201).coerceIn(0, 359)
fun cardSat(v: Int): Int = (v / 101 % 101).coerceIn(0, 100)
fun cardBright(v: Int): Int = (v % 101).coerceIn(0, 100)

/** The card colour for these slider values in light or dark mode. */
fun customShade(hue: Int, sat: Int, bright: Int, dark: Boolean): Color {
    val b = bright.coerceIn(0, 100) / 100f
    val s = sat.coerceIn(0, 100) / 100f
    var l = if (dark) 0.10f + 0.46f * b else 0.58f + 0.39f * b
    var c = hslColor(hue.toFloat(), s, l)
    var n = 0
    if (dark) {
        while (c.luminance() > 0.16f && n < 40) { l -= 0.015f; c = hslColor(hue.toFloat(), s, l.coerceAtLeast(0.02f)); n++ }
    } else {
        while (c.luminance() < 0.30f && n < 40) { l += 0.015f; c = hslColor(hue.toFloat(), s, l.coerceAtMost(0.99f)); n++ }
    }
    return c
}

fun customShade(v: Int, dark: Boolean): Color = customShade(cardHue(v), cardSat(v), cardBright(v), dark)

/** A colour from hue (0 to 360), saturation and lightness (0 to 1). */
fun hslColor(h: Float, s: Float, l: Float): Color {
    val c = (1f - kotlin.math.abs(2f * l - 1f)) * s
    val hp = ((h % 360f) + 360f) % 360f / 60f
    val x = c * (1f - kotlin.math.abs(hp % 2f - 1f))
    val (r1, g1, b1) = when (hp.toInt()) {
        0 -> Triple(c, x, 0f)
        1 -> Triple(x, c, 0f)
        2 -> Triple(0f, c, x)
        3 -> Triple(0f, x, c)
        4 -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    val m = l - c / 2f
    return Color(r1 + m, g1 + m, b1 + m)
}

/** The grey for small text on a bind's card: a little see-through version of the main ink when the card has a colour (plain grey would be too faint on it). */
@Composable
fun softInk(tint: Int): Color = if (tint in Tints.indices) P.fg.copy(alpha = 0.75f) else P.mute

@Composable
fun BinderList.softInk(): Color = if (cardColor >= 0) P.fg.copy(alpha = 0.75f) else softInk(tint)

/** A bind's own accent: the colour it picked, or the app's accent. */
val BinderList.accentColor: Color get() = if (accent != 0) Color(accent) else Coral

/** The accents a bind can pick (a hex colour can be typed in too). */
val BindAccents = listOf(
    AccentChoice("Yellow", Color(0xFFF7D046)), AccentChoice("Amber", Color(0xFFF5B83D)), AccentChoice("Orange", Color(0xFFFF9F43)),
    AccentChoice("Coral", Color(0xFFF46C4E)), AccentChoice("Rose", Color(0xFFF43F5E)), AccentChoice("Pink", Color(0xFFFF8FB1)),
    AccentChoice("Violet", Color(0xFF9B8CFF)), AccentChoice("Blue", Color(0xFF5B7CFA)), AccentChoice("Sky", Color(0xFF4DA3FF)),
    AccentChoice("Teal", Color(0xFF3DD9D3)), AccentChoice("Green", Color(0xFF5CCB8A)), AccentChoice("Lime", Color(0xFFA3E635)),
)

/** "#F5B83D" (or without the #) as an opaque colour; null if it is not six hex digits. */
fun parseHexColor(s: String): Int? {
    val t = s.trim().removePrefix("#")
    if (t.length != 6 || !t.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return null
    return (0xFF000000L or t.toLong(16)).toInt()
}

@Composable
fun Tint.color(strength: Int = 1): Color = shade(P.bg == DarkPal.bg, strength)

/** The background of a bind's card on Home: its colour (at its strength) if it has one, otherwise the usual grey. */
@Composable
fun BinderList.cardBg(): Color =
    if (cardColor >= 0) customShade(cardColor, P.bg == DarkPal.bg)
    else Tints.getOrNull(tint)?.color(tintStrength) ?: P.surface

/** A bind's own card corner: square, the usual size of that card, or round. */
fun BinderList.corner(usual: androidx.compose.ui.unit.Dp): androidx.compose.ui.unit.Dp = when (corners) {
    0 -> 8.dp
    2 -> 38.dp
    else -> usual
}

/** The emoji a template wears on its tile in New bind. */
val Kind.emoji: String
    get() = when (this) {
        Kind.BOOKS -> "📒"; Kind.MANGA -> "📖"; Kind.COMICS -> "💥"; Kind.MOVIES -> "🎬"; Kind.SERIES -> "📺"
        Kind.ALBUMS -> "💿"; Kind.GAMES -> "🎮"; Kind.PLACES -> "🗺️"; Kind.HEARD -> "🎧"; Kind.ANYTHING -> "✨"
        Kind.CHECKLIST -> "✅"; Kind.TRACKER -> "📊"; Kind.TIME -> "⏳"; Kind.HABITS -> "🌱"; Kind.PRODUCTIVITY -> "🎯"; Kind.TASKS -> "🗓️"
    }

/** The colour a template starts with (a place in [Tints]). */
val Kind.defaultTint: Int
    get() = when (this) {
        Kind.BOOKS -> 0; Kind.MANGA -> 1; Kind.COMICS -> 2; Kind.MOVIES -> 3; Kind.SERIES -> 4
        Kind.ALBUMS -> 5; Kind.GAMES -> 6; Kind.PLACES -> 7; Kind.HEARD -> 8; Kind.ANYTHING -> 11
        Kind.CHECKLIST -> 10; Kind.TRACKER -> 9; Kind.TIME -> 4; Kind.HABITS -> 7; Kind.PRODUCTIVITY -> 2; Kind.TASKS -> 6
    }

/** How New bind groups the templates. Every kind appears exactly once. */
val KindGroups: List<Pair<String, List<Kind>>> = listOf(
    "Media" to listOf(Kind.BOOKS, Kind.MANGA, Kind.COMICS, Kind.MOVIES, Kind.SERIES, Kind.ALBUMS, Kind.GAMES, Kind.PLACES, Kind.HEARD),
    "Tracking and planning" to listOf(Kind.CHECKLIST, Kind.TASKS, Kind.TRACKER, Kind.TIME, Kind.HABITS, Kind.PRODUCTIVITY),
    "From scratch" to listOf(Kind.ANYTHING),
)

/** The icons offered in New bind. Anything else can be typed in. */
val LookEmojis = listOf(
    "📒", "📚", "📖", "💥", "🎬", "📺", "💿", "🎮", "🗺️", "🎧",
    "✨", "✅", "📊", "⏳", "🌱", "🎯", "🔥", "⭐", "❤️", "🍿",
    "🎵", "🎨", "🏋️", "🍳", "✈️", "🏠", "💡", "🧠", "💰", "🛒",
    "📝", "🌍", "🎲", "🧩", "☕", "🐶", "🌙", "💪", "🎸", "📷",
)

/** The first symbol of what was typed (one emoji, even one made of several parts); "" for blank text. */
fun firstEmoji(s: String): String {
    val t = s.trim()
    if (t.isEmpty()) return ""
    val bi = java.text.BreakIterator.getCharacterInstance()
    bi.setText(t)
    val end = bi.next()
    return if (end == java.text.BreakIterator.DONE) t else t.substring(0, end)
}

@Composable
private fun Swatch(color: Color, label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(color)
            .border(2.dp, if (selected) Coral else P.line, CircleShape)
            .semantics { contentDescription = label; this.selected = selected }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { if (label == "None") Txt("–", 18, P.mute) }
}

@Composable
private fun EmojiCell(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(Radius.sm)
    Box(
        Modifier.size(48.dp).clip(shape).background(P.surface)
            .border(2.dp, if (selected) Coral else Color.Transparent, shape)
            .semantics { this.selected = selected }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { if (label == "Auto") Txt("Auto", 12, P.mute) else Txt(label, 24) }
}

/**
 * The Look part of the New bind page: a preview of the Home card, a row of background colours and the icons.
 * [emoji] "" means the bind's usual mark (the progress ring, a tracker's face ...); [tint] -1 means the plain grey card.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LookPicker(
    name: String, emoji: String, tint: Int, custom: String,
    onEmoji: (String) -> Unit, onTint: (Int) -> Unit, onCustom: (String) -> Unit,
    showPreview: Boolean = true,   // false where the page has a preview of its own
    strength: Int = 1,             // the strength the swatches are drawn at
    afterSwatches: @Composable () -> Unit = {},   // extra controls right under the colour row (the sliders)
) {
    val soft = softInk(tint)
    Cap("LOOK")
    if (showPreview) {
        Row(Modifier.fillMaxWidth()) {
            Box(
                Modifier.weight(1f).height(128.dp).clip(RoundedCornerShape(Radius.xl))
                    .background(Tints.getOrNull(tint)?.color() ?: P.surface)
            ) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    if (emoji.isEmpty()) ProgressRing(0f, 44.dp)
                    else Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) { Txt(emoji, 32) }
                    Column {
                        Txt(name, 18, weight = FontWeight.Medium, maxLines = 1)
                        Txt("0 of 0 done", 13, soft, Modifier.padding(top = 2.dp), maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
        }
    }
    Txt("Background", 13, P.mute, Modifier.padding(top = 16.dp, bottom = 8.dp))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Swatch(P.surface, "None", tint == -1) { onTint(-1) }
        Tints.forEachIndexed { i, t -> Swatch(t.color(strength), t.name, tint == i) { onTint(i) } }
    }
    afterSwatches()
    Txt("Icon", 13, P.mute, Modifier.padding(top = 16.dp, bottom = 8.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        EmojiCell("Auto", emoji.isEmpty()) { onEmoji("") }
        LookEmojis.forEach { e -> EmojiCell(e, emoji == e) { onEmoji(e) } }
    }
    Field("Or type your own emoji", custom, Modifier.padding(top = 12.dp)) { onCustom(it) }
}
