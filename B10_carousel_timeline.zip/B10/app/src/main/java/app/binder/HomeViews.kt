package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import kotlin.math.roundToInt
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties

// ───────── the view switcher of the Binds screen ─────────
// A row of filter chips with a small button at its right. The button shows the icon of the current view;
// tapping it opens a menu with every view. (Layout concept: Binder_Views mockup.)

private val isDarkPal: Boolean
    @Composable get() = P === DarkPal

/** The soft coral that marks the selected view (the mockup's "tile-on"). */
private val tileOn: Color
    @Composable get() = if (isDarkPal) Color(0xFF4A2C26) else Color(0xFFFBD5CC)

private fun HomeStyle.hint(): String = when (this) {
    HomeStyle.PINNED -> "Favorites on top"
    HomeStyle.TILES -> "Progress rings in a grid"
    HomeStyle.ROWS -> "Progress rings, one per row"
    HomeStyle.COMPACT -> "Thin progress bars"
    HomeStyle.FILL -> "Cards fill as you go"
    HomeStyle.GROUPED -> "By status"
    HomeStyle.NUMERALS -> "Big counts, hairlines"
    HomeStyle.STACKS -> "Covers fanned out"
    HomeStyle.BENTO -> "One big card, the rest small"
}

/**
 * The icon of a view: lines follow the text colour, the small accents are coral.
 * Drawn on a 24 x 24 grid so it matches the mockup.
 */
@Composable
fun ViewIcon(style: HomeStyle, modifier: Modifier = Modifier) {
    val ink = P.fg
    Canvas(modifier) {
        val u = this.size.width / 24f
        val sw = Stroke(width = 1.6f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)

        fun box(x: Float, y: Float, w: Float, h: Float, r: Float, fill: Color? = null) {
            if (fill != null) drawRoundRect(fill, Offset(x * u, y * u), Size(w * u, h * u), CornerRadius(r * u), style = Fill)
            drawRoundRect(ink, Offset(x * u, y * u), Size(w * u, h * u), CornerRadius(r * u), style = sw)
        }

        fun dot(x: Float, y: Float, r: Float, accent: Boolean) {
            if (accent) drawCircle(Coral, r * u, Offset(x * u, y * u), style = Fill)
            else drawCircle(ink, r * u, Offset(x * u, y * u), style = sw)
        }

        fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
            drawLine(ink, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = 1.6f * u, cap = StrokeCap.Round)
        }

        when (style) {
            // three long rows, each with a ring dot and a line
            HomeStyle.ROWS -> {
                listOf(4f, 9.6f, 15.2f).forEachIndexed { i, y ->
                    box(3.5f, y, 17f, 4.8f, 2.4f)
                    dot(7f, y + 2.4f, 1.5f, accent = i == 0)
                    line(11f, y + 2.4f, 17f, y + 2.4f)
                }
            }
            // two small cards on top, two rows below
            HomeStyle.PINNED -> {
                box(3.5f, 3.5f, 7f, 7f, 2.2f, fill = Coral)
                box(13.5f, 3.5f, 7f, 7f, 2.2f)
                box(3.5f, 13f, 17f, 3.4f, 1.7f)
                box(3.5f, 18f, 17f, 2.6f, 1.3f)
            }
            // a grid of four rounded tiles, each with a ring dot
            HomeStyle.TILES -> {
                box(3.5f, 3.5f, 7.5f, 7.5f, 2.6f)
                box(13f, 3.5f, 7.5f, 7.5f, 2.6f)
                box(3.5f, 13f, 7.5f, 7.5f, 2.6f)
                box(13f, 13f, 7.5f, 7.5f, 2.6f)
                dot(7.25f, 7.25f, 1.7f, accent = true)
                dot(16.75f, 7.25f, 1.7f, accent = false)
                dot(7.25f, 16.75f, 1.7f, accent = false)
                dot(16.75f, 16.75f, 1.7f, accent = true)
            }
            // short lines, each with a long coral bar under it
            HomeStyle.COMPACT -> {
                listOf(4.5f to 8f, 10.5f to 14f, 16.5f to 20f).forEach { (t, b) ->
                    line(4f, t, 12f, t)
                    drawLine(Coral, Offset(4f * u, b * u), Offset(20f * u, b * u), strokeWidth = 2f * u, cap = StrokeCap.Round)
                }
            }
            // three bars, filled with coral as far as they are done
            HomeStyle.FILL -> {
                listOf(4f to 10f, 9.7f to 14f, 15.4f to 6f).forEach { (y, w) ->
                    drawRoundRect(Coral, Offset(3.5f * u, y * u), Size(w * u, 4.6f * u), CornerRadius(2.3f * u), style = Fill)
                    box(3.5f, y, 17f, 4.6f, 2.3f)
                }
            }
            // a title line, one long row, then two short ones
            HomeStyle.GROUPED -> {
                line(4f, 4f, 10f, 4f)
                line(4f, 13.4f, 10f, 13.4f)
                box(3.5f, 6.2f, 17f, 4.4f, 2.2f)
                box(3.5f, 15.6f, 7.5f, 4.6f, 2.2f)
                box(13f, 15.6f, 7.5f, 4.6f, 2.2f)
                dot(7f, 8.4f, 1.2f, accent = true)
            }
            // three coral squares, each with a line
            HomeStyle.NUMERALS -> {
                listOf(4f, 10f, 16f).forEach { y ->
                    drawRoundRect(Coral, Offset(3.5f * u, y * u), Size(4f * u, 4f * u), CornerRadius(1.2f * u), style = Fill)
                }
                line(11f, 6f, 20.5f, 6f)
                line(11f, 12f, 20.5f, 12f)
                line(11f, 18f, 20.5f, 18f)
            }
            // three cards fanned out, the middle one on top
            HomeStyle.STACKS -> {
                rotate(-12f, Offset(7.5f * u, 12.5f * u)) { box(3.5f, 6f, 8f, 13f, 2.2f) }
                rotate(12f, Offset(16.5f * u, 12.5f * u)) { box(12.5f, 6f, 8f, 13f, 2.2f) }
                box(8f, 4.5f, 8f, 15f, 2.2f, fill = Coral)
            }
            // one big card and two small ones
            HomeStyle.BENTO -> {
                box(3.5f, 3.5f, 9f, 17f, 2.6f)
                box(14.5f, 3.5f, 6f, 7.5f, 2.2f, fill = Coral)
                box(14.5f, 13f, 6f, 7.5f, 2.2f)
            }
        }
    }
}

@Composable
private fun HomeChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.heightIn(min = 44.dp).clickable(onClick = onClick).padding(horizontal = 4.dp)
            .semantics { role = Role.Button; selected = on },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.height(34.dp).clip(CircleShape).background(if (on) P.primary else P.surface)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center,
        ) { Txt(label, 14, if (on) P.onPrimary else P.fg, weight = FontWeight.Medium, maxLines = 1) }
    }
}

/**
 * The row under the page title: All / Media / Checklists on the left, the view button on the right.
 * [all], [media] and [checklists] are the counts shown in the chips.
 */
@Composable
fun HomeViewBar(vm: BinderViewModel, all: Int, media: Int, checklists: Int) {
    var menuOpen by remember { mutableStateOf(false) }
    val current = vm.opts.home
    Row(
        Modifier.fillMaxWidth().padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            HomeChip("All · $all", vm.homeFilter == 0) { vm.homeFilter = 0 }
            HomeChip("Media · $media", vm.homeFilter == 1) { vm.homeFilter = 1 }
            HomeChip("Checklists · $checklists", vm.homeFilter == 2) { vm.homeFilter = 2 }
        }
        Box {
            Box(
                Modifier.heightIn(min = 44.dp).width(64.dp).clickable { menuOpen = !menuOpen }
                    .semantics { contentDescription = "Change view, current: ${current.label}" },
                contentAlignment = Alignment.Center,
            ) {
                Row(
                    Modifier.height(34.dp).clip(CircleShape).background(if (menuOpen) tileOn else P.surface)
                        .padding(start = 10.dp, end = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    ViewIcon(current, Modifier.size(22.dp))
                    Icon(
                        Ic.ChevronDown, null, tint = P.mute,
                        modifier = Modifier.size(14.dp).rotate(if (menuOpen) 180f else 0f),
                    )
                }
            }
            if (menuOpen) {
                ViewMenu(
                    current = current,
                    onPick = { s ->
                        menuOpen = false
                        if (s != current) vm.change { it.copy(home = s) }
                    },
                    onDismiss = { menuOpen = false },
                )
            }
        }
    }
}

/** The dropdown: one row per view, with its icon, a short hint and a check on the one in use. */
@Composable
private fun ViewMenu(current: HomeStyle, onPick: (HomeStyle) -> Unit, onDismiss: () -> Unit) {
    val density = LocalDensity.current
    val below = with(density) { 46.dp.roundToPx() }
    val shape = RoundedCornerShape(24.dp)
    val bg = if (isDarkPal) Color(0xFF232323) else Color.White
    Popup(
        alignment = Alignment.TopEnd,
        offset = IntOffset(0, below),
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true),
    ) {
        Column(
            Modifier.width(290.dp).heightIn(max = 580.dp)
                .shadow(18.dp, shape).clip(shape).background(bg).border(1.dp, P.line, shape)
                .verticalScroll(rememberScrollState()).padding(8.dp),
        ) {
            Txt(
                "VIEW", 11, P.mute, Modifier.padding(start = 10.dp, top = 6.dp, bottom = 6.dp),
                ls = 0.08.em,
            )
            HomeStyle.entries.forEach { s ->
                val on = s == current
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(16.dp))
                        .background(if (on) Coral.copy(alpha = 0.16f) else Color.Transparent)
                        .clickable { onPick(s) }
                        .semantics { role = Role.RadioButton; selected = on }
                        .padding(start = 8.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(if (on) tileOn else P.surface),
                        contentAlignment = Alignment.Center,
                    ) { ViewIcon(s, Modifier.size(24.dp)) }
                    Column(Modifier.weight(1f)) {
                        Txt(s.label, 15, weight = FontWeight.Medium, maxLines = 1)
                        Txt(s.hint(), 12, P.mute, maxLines = 1)
                    }
                    if (on) Icon(Ic.Check, null, tint = Coral, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

// ───────── Tiles: a progress ring and the name, two to a row ─────────

@Composable
fun RingTile(l: BinderList, modifier: Modifier, open: () -> Unit, hold: () -> Unit) {
    Column(
        modifier.height(128.dp).clip(RoundedCornerShape(28.dp)).background(P.surface)
            .tapHold(open, hold).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        BindMark(l, 44.dp)
        Column {
            Txt(l.name, 18, weight = FontWeight.Medium, maxLines = 1)
            Txt(l.entryLine() ?: "${l.doneCount()} of ${l.items.size} done", 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
        }
    }
}

// ───────── Compact: a name, a percentage and a thin bar, no card ─────────

@Composable
fun ColumnScope.CompactHome(
    shown: List<BinderList>, pad: Int, open: (BinderList) -> Unit, hold: (BinderList) -> Unit,
) {
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 6.dp, bottom = pad.dp)) {
        items(shown, key = { it.id }) { l ->
            val n = l.items.size
            Column(Modifier.fillMaxWidth().tapHold({ open(l) }, { hold(l) }).padding(horizontal = 4.dp, vertical = 10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Txt(l.name, 18, modifier = Modifier.weight(1f), maxLines = 1)
                    Txt(l.lastFace() ?: "${(l.progress() * 100).roundToInt()}%", 15, weight = FontWeight.Medium, modifier = Modifier.padding(start = 12.dp))
                }
                Txt(
                    l.entryLine() ?: "$n ${if (n == 1) "item" else "items"} · ${l.doneCount()} done", 13, P.mute,
                    Modifier.padding(top = 2.dp, bottom = 6.dp), maxLines = 1,
                )
                Progress(l.progress())
            }
        }
    }
}

// ───────── Fill: the card itself fills with coral as the list gets done ─────────

@Composable
fun ColumnScope.FillHome(
    shown: List<BinderList>, pad: Int, open: (BinderList) -> Unit, hold: (BinderList) -> Unit,
) {
    LazyColumn(
        Modifier.weight(1f),
        contentPadding = PaddingValues(top = 6.dp, bottom = pad.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(shown, key = { it.id }) { l ->
            Box(
                Modifier.fillMaxWidth().height(62.dp).clip(RoundedCornerShape(22.dp)).background(P.surface)
                    .tapHold({ open(l) }, { hold(l) }),
            ) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(l.progress().coerceIn(0f, 1f)).background(Coral.copy(alpha = 0.3f)))
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Txt(l.name, 18, modifier = Modifier.weight(1f), maxLines = 1)
                    val face = l.lastFace()
                    if (face != null) Txt(face, 22, modifier = Modifier.padding(start = 12.dp))
                    else {
                        Txt("${l.doneCount()}", 18, weight = FontWeight.Medium, modifier = Modifier.padding(start = 12.dp))
                        Txt(" / ${l.items.size}", 14, P.mute)
                    }
                }
            }
        }
    }
}

// ───────── Grouped: by status ─────────

@Composable
private fun SectionLabel(text: String, count: Int, first: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = if (first) 4.dp else 22.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Txt(text.uppercase(), 11, P.mute, ls = 0.08.em)
        Txt("$count", 12, P.mute)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColumnScope.GroupedHome(
    shown: List<BinderList>, pad: Int, open: (BinderList) -> Unit, hold: (BinderList) -> Unit,
) {
    // a bind with items but nothing done yet counts as "Not started" (the mockup would have dropped it)
    // a tracker is never "completed": once it has an entry it stays in progress, so its face stays on show
    val prog = shown.filter { if (it.kind.isTracker) it.items.isNotEmpty() else it.progress() > 0f && it.progress() < 1f }
    val done = shown.filter { !it.kind.isTracker && it.items.isNotEmpty() && it.progress() >= 1f }
    val idle = shown.filter { if (it.kind.isTracker) it.items.isEmpty() else it.progress() <= 0f }
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 6.dp, bottom = pad.dp)) {
        if (prog.isNotEmpty()) {
            item(key = "~prog") { SectionLabel("In progress", prog.size, first = true) }
            items(prog, key = { it.id }) { l ->
                Row(
                    Modifier.padding(bottom = 8.dp).fillMaxWidth().height(76.dp).clip(RoundedCornerShape(28.dp))
                        .background(P.surface).tapHold({ open(l) }, { hold(l) }).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    BindMark(l, 48.dp)
                    Column(Modifier.weight(1f)) {
                        Txt(l.name, 18, weight = FontWeight.Medium, maxLines = 1)
                        Txt(l.entryLine() ?: "${l.items.size} ${if (l.items.size == 1) "item" else "items"} · ${l.doneCount()} done", 13, P.mute, maxLines = 1)
                    }
                }
            }
        }
        if (done.isNotEmpty()) {
            item(key = "~done") { SectionLabel("Completed", done.size, first = prog.isEmpty()) }
            items(done.chunked(2), key = { it.first().id }) { pair ->
                Row(Modifier.padding(bottom = 8.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pair.forEach { l ->
                        Row(
                            Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(20.dp)).background(P.surface)
                                .tapHold({ open(l) }, { hold(l) }).padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Box(Modifier.size(26.dp).clip(CircleShape).background(Coral), contentAlignment = Alignment.Center) {
                                Icon(Ic.Check, null, tint = Color(0xFF111111), modifier = Modifier.size(14.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Txt(l.name, 16, maxLines = 1)
                                Txt("${l.items.size} ${if (l.items.size == 1) "item" else "items"}", 12, P.mute, maxLines = 1)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        if (idle.isNotEmpty()) {
            item(key = "~idle") { SectionLabel("Not started", idle.size, first = prog.isEmpty() && done.isEmpty()) }
            item(key = "~idle-pills") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    idle.forEach { l ->
                        Box(
                            Modifier.height(44.dp).dashedBorder(22.dp).tapHold({ open(l) }, { hold(l) }).padding(horizontal = 20.dp),
                            contentAlignment = Alignment.Center,
                        ) { Txt(l.name, 15, maxLines = 1) }
                    }
                }
            }
        }
    }
}

// ───────── Numerals: big counts between hairlines ─────────

@Composable
fun ColumnScope.NumeralsHome(
    shown: List<BinderList>, pad: Int, open: (BinderList) -> Unit, hold: (BinderList) -> Unit,
) {
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 6.dp, bottom = pad.dp)) {
        items(shown, key = { it.id }) { l ->
            val n = l.items.size
            val d = l.doneCount()
            val full = n > 0 && d == n
            val empty = n == 0
            val note = if (empty) "Empty" else if (full) "All done" else "$d done · ${n - d} left"
            Column(Modifier.fillMaxWidth()) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(P.line))
                Row(
                    Modifier.fillMaxWidth().height(72.dp).tapHold({ open(l) }, { hold(l) }).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Txt("$n", 44, if (empty) P.mute else P.fg, Modifier.width(78.dp), maxLines = 1)
                    Column(Modifier.weight(1f)) {
                        Txt(l.name, 19, maxLines = 1)
                        Txt(note, 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                    }
                    Box(
                        Modifier.padding(start = 12.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (full) Coral else P.surface).padding(horizontal = 10.dp, vertical = 4.dp),
                    ) {
                        Txt(
                            "${(l.progress() * 100).roundToInt()}%", 14,
                            if (full) Color(0xFF111111) else if (empty) P.mute else P.fg,
                            weight = FontWeight.Medium,
                        )
                    }
                }
            }
        }
    }
}
