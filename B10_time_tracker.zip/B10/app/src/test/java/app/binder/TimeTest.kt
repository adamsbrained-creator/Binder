package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class TimeTest {

    private fun at(y: Int, m: Int, d: Int, h: Int = 0, min: Int = 0): Long =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d, h, min, 0) }.timeInMillis

    @Test fun theYearOnThe15thOfOctober() {
        val now = at(2026, 10, 15, 15, 19)
        val g = gaugeOf(periodSpan("year", now), now)
        assertEquals(365, g.total)
        assertEquals(288, g.passed)        // today counts as passed ...
        assertEquals(77, g.remaining)      // ... so 288 + 77 = 365
        assertEquals(0.788f, g.fraction, 0.001f)
        assertTrue(g.live)
        assertEquals("77 days left", heroText(periodSpan("year", now), now))
    }

    @Test fun monthWeekAndDayAddUp() {
        val now = at(2026, 10, 15, 15, 19)
        val month = gaugeOf(periodSpan("month", now), now)
        assertEquals(31, month.total); assertEquals(15, month.passed); assertEquals(16, month.remaining)
        val week = gaugeOf(periodSpan("week", now), now)
        assertEquals(7, week.total); assertEquals(7, week.passed + week.remaining)
        val day = gaugeOf(periodSpan("day", now), now)
        assertEquals(24, day.total); assertEquals(Step.HOUR, day.step); assertEquals(16, day.passed)
    }

    @Test fun beforeAndAfterASpan() {
        val s = Span("x", "", at(2026, 3, 1), at(2026, 3, 11), Step.DAY)
        val before = gaugeOf(s, at(2026, 2, 1))
        assertFalse(before.live); assertEquals(0, before.passed); assertEquals(10, before.remaining); assertEquals(0f, before.fraction)
        val after = gaugeOf(s, at(2026, 4, 1))
        assertFalse(after.live); assertEquals(10, after.passed); assertEquals(0, after.remaining); assertEquals(1f, after.fraction)
        assertEquals("Done", heroText(s, at(2026, 4, 1)))
    }

    @Test fun aDateCountsCalendarDaysToTheEndOfItsDay() {
        val now = at(2026, 10, 15, 15, 19)
        val d = Item(title = "Exam", added = startOfDay(now), due = at(2026, 12, 5))
        val sp = d.span()
        assertEquals("51 days left", heroText(sp, now))   // 15 Oct to 5 Dec is 51 days
        assertEquals(Step.DAY, sp.step)
        assertEquals(52, gaugeOf(sp, now).total)          // 15 Oct .. 5 Dec, both days included
        assertEquals("51 days", leftShort(sp, now))
    }

    @Test fun aDateOnItsOwnDayCountsHours() {
        val now = at(2026, 10, 15, 15, 19)
        val d = Item(title = "Today", added = startOfDay(now), due = startOfDay(now))
        assertEquals(Step.HOUR, d.span().step)
        assertEquals("8h 41m left", heroText(d.span(), now))
    }

    @Test fun aDueDateBeforeTheStartDoesNotBreakAnything() {
        val now = at(2026, 10, 15)
        val d = Item(title = "Odd", added = at(2026, 12, 1), due = at(2026, 11, 1))
        val g = gaugeOf(d.span(), now)
        assertTrue(g.total >= 1)
        assertEquals(Item(title = "None").due, 0L)
        val none = Item(title = "None", added = now).span()    // no due date saved: one day, never negative
        assertTrue(none.end > none.start)
    }

    @Test fun dotsAreSizedToStayUnderAboutFourHundred() {
        assertEquals(Step.HOUR, stepFor(at(2026, 1, 1), at(2026, 1, 2)))
        assertEquals(Step.DAY, stepFor(at(2026, 1, 1), at(2027, 1, 1)))
        assertEquals(Step.WEEK, stepFor(at(2026, 1, 1), at(2030, 1, 1)))
        assertEquals(Step.MONTH, stepFor(at(2026, 1, 1), at(2046, 1, 1)))
        assertEquals(Step.YEAR, stepFor(at(1999, 1, 1), at(2089, 1, 1)))
        assertEquals(7, dotColumns(7)); assertEquals(6, dotColumns(24)); assertEquals(7, dotColumns(31))
        assertEquals(20, dotColumns(365)); assertEquals(1, dotColumns(0))
    }

    @Test fun leftTextPicksTheRightUnit() {
        val h = 3_600_000L
        assertEquals("Done", leftText(0))
        assertEquals("5 min left", leftText(5 * 60_000L))
        assertEquals("1 min left", leftText(10_000L))
        assertEquals("9h 41m left", leftText(9 * h + 41 * 60_000L))
        assertEquals("2 days left", leftText(48 * h))
        assertEquals("1h 0m left", leftText(h))
        assertEquals("47h 0m left", leftText(47 * h))
    }

    @Test fun aTimeBindSavesAndLoadsLikeAnyBind() {
        val d = Item(title = "Trip", note = "Lisbon", added = at(2026, 10, 15), due = at(2026, 12, 5))
        val l = BinderList(name = "Time", kind = Kind.TIME, layout = Layout.LIST, items = listOf(d))
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals(Kind.TIME, back.kind)
        assertEquals(d, back.items.single())
        assertEquals(at(2026, 12, 5), back.items.single().due)
        assertEquals(0, back.doneCount())
        assertTrue(back.progress() in 0f..1f)
        assertTrue(back.entryLine()!!.contains("left in"))
        assertTrue(back.entryLine()!!.endsWith("· 1 date"))
        assertTrue(Kind.TIME.hasOwnPage && !Kind.BOOKS.hasOwnPage)
    }

    @Test fun oldItemsLoadWithNoDueDate() {
        val old = """{"format":"binder","version":3,"lists":[{"id":"a","name":"Books","kind":"BOOKS","items":[{"id":"1","title":"Dune"}]}]}"""
        assertEquals(0L, parseLists(old).single().items.single().due)
    }
}
