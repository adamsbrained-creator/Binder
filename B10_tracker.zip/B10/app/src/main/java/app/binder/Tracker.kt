package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// A tracker is a normal bind (Kind.TRACKER) with its own page: Overview / Stats / History, and a "New entry" screen.
// Every entry is a plain Item: stage = face (0..4), rating = 1..10, note, added = when. Old files and backups need nothing new.

val Faces = listOf("😩", "😕", "😐", "🙂", "😄")
private val Words get() = Kind.TRACKER.stages

/** The face that belongs to a rating out of 10: 1 Drained, 3 Low, 5 Okay, 7 Good, 9 Great. */
fun levelOf(rating: Float): Int = ((rating - 1f) / 2f).roundToInt().coerceIn(0, 4)

/** The rating a face starts at, until you move the slider yourself. */
fun defaultRating(level: Int): Int = level * 2 + 1

fun startOfDay(ms: Long, plusDays: Int = 0): Long = Calendar.getInstance().apply {
    timeInMillis = ms
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    add(Calendar.DAY_OF_MONTH, plusDays)
}.timeInMillis

fun List<Item>.averageRating(): Float = if (isEmpty()) 0f else sumOf { it.rating.toDouble() }.toFloat() / size

private fun fmt(p: String, ms: Long) = SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))
private fun timeOf(ms: Long) = fmt("hh:mm a", ms)
private fun oneDecimal(v: Float) = String.format(Locale.US, "%.1f", v)

private fun dayName(start: Long, now: Long): String = when (start) {
    startOfDay(now) -> "Today"
    startOfDay(now, -1) -> "Yesterday"
    else -> fmt("EEE, MMM d", start)
}

private fun ago(ms: Long, now: Long): String {
    val m = (now - ms) / 60_000
    return when {
        m < 2 -> "Just now"
        m < 60 -> "$m min ago"
        m < 24 * 60 && startOfDay(ms) == startOfDay(now) -> "${m / 60} h ago"
        else -> "${dayName(startOfDay(ms), now)}, ${timeOf(ms)}"
    }
}

private fun Item.line(): String = note.ifBlank { "Feeling ${title.lowercase()}" }

// ───────── small pieces ─────────

@Composable
private fun Dot(size: Int = 9) =
    Box(Modifier.padding(start = 8.dp).size(size.dp).clip(CircleShape).background(Coral))

@Composable
private fun Rate(r: Float, size: Int = 15) = Row {
    Txt("${r.roundToInt()}", size, weight = FontWeight.Medium)
    Txt(" / 10", size, P.mute)
}

/** Ten little segments, filled up to the rating. */
@Composable
private fun Meter(r: Float, modifier: Modifier = Modifier) =
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        repeat(10) { i ->
            Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(if (i < r.roundToInt()) Coral else P.line))
        }
    }

@Composable
private fun Card(modifier: Modifier = Modifier, radius: Int = 26, content: @Composable () -> Unit) =
    Box(modifier.clip(RoundedCornerShape(radius.dp)).background(P.surface)) { content() }

/** The "Each entry has" part of the New bind page, shown when Tracker is picked. */
@Composable
fun TrackerHas(note: String) {
    Txt(note, 12, P.mute, Modifier.padding(start = 4.dp, top = 10.dp))
    Cap("EACH ENTRY HAS")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Triple("🙂", "An emoji level", "5 faces"), Triple("7", "A rating", "out of 10")).forEach { (icon, title, value) ->
            Row(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(22.dp)).background(P.surface).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { Txt(icon, if (icon == "7") 16 else 24, weight = if (icon == "7") FontWeight.Medium else FontWeight.Normal) }
                Txt(title, 16, modifier = Modifier.weight(1f))
                Txt(value, 14, P.mute)
            }
        }
    }
}

// ───────── the tracker page ─────────

@Composable
fun TrackerScreen(vm: BinderViewModel, id: String) {
    val nav = vm.nav
    val o = vm.opts
    var tab by rememberSaveable { mutableStateOf(0) }
    val l = vm.lists.firstOrNull { it.id == id }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val now = System.currentTimeMillis()
    val entries = l.items.sortedByDescending { it.added }
    val today = entries.count { it.added >= startOfDay(now) }
    val add = { nav.push(Route.ItemEdit(l.id, null)) }

    Box(Modifier.fillMaxSize()) {
        Screen {
            Header2(
                l.name, if (entries.isEmpty()) "" else listOf("$today today", "Stats", "History")[tab], onBack = { nav.pop() },
                right = {
                    CircleBtn(Ic.Dots, "${o.list} options") {
                        vm.sheet = SheetData(
                            l.name,
                            listOf(
                                Act("Add entry") { add() },
                                Act(if (l.pinned) "Unpin" else "Pin to top") { vm.togglePin(l.id) },
                                Act("Rename") { vm.rename = l },
                                Act("Delete ${o.listLower}", danger = true) { vm.deleteList(l); nav.pop() },
                            ),
                        )
                    }
                },
            )
            if (entries.isEmpty()) {
                EmptyBlock("Nothing logged yet", "Log how you feel and your stats will build up here.", "Log an entry") { add() }
            } else {
                Seg(listOf("Overview", "Stats", "History"), tab, Modifier.padding(top = 6.dp)) { tab = it }
                when (tab) {
                    0 -> Overview(entries, now, add) { tab = 2 }
                    1 -> StatsTab(entries, now)
                    else -> HistoryTab(vm, l, entries, now)
                }
            }
        }
        MenuFab(vm, onAdd = add, onAddHold = add)
    }
}

@Composable
private fun ColumnScope.Overview(entries: List<Item>, now: Long, add: () -> Unit, viewAll: () -> Unit) {
    val last = entries.first()
    val todays = entries.filter { it.added >= startOfDay(now) }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 110.dp)) {
        Cap("NOW")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Txt(Faces[last.stage], 56)
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Txt(last.title, 26, weight = FontWeight.Medium); Dot() }
                        Txt(last.line(), 14, P.mute, maxLines = 1)
                        Txt(ago(last.added, now), 12, P.mute, Modifier.padding(top = 2.dp))
                    }
                    Box(Modifier.align(Alignment.Top).clip(RoundedCornerShape(14.dp)).background(P.bg).padding(horizontal = 10.dp, vertical = 4.dp)) { Rate(last.rating) }
                }
                Meter(last.rating, Modifier.padding(top = 16.dp))
            }
        }
        Cap("TODAY")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(Modifier.weight(1f).height(108.dp)) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Txt("${todays.size}", 34)
                    Txt("Entries logged", 14, P.mute)
                }
            }
            Card(Modifier.weight(1f).height(108.dp)) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    if (todays.isEmpty()) Txt("–", 34)
                    else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Txt(Faces[levelOf(todays.averageRating())], 30); Txt(oneDecimal(todays.averageRating()), 34)
                    }
                    Txt("Avg rating", 14, P.mute)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Cap("RECENT", Modifier.padding(start = 4.dp))
            Txt("View all", 13, Coral, Modifier.padding(bottom = 8.dp, end = 4.dp).clickable { viewAll() })
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            entries.take(3).forEach { e ->
                Card(Modifier.width(68.dp).height(80.dp), 20) {
                    Column(Modifier.fillMaxSize(), Arrangement.spacedBy(6.dp, Alignment.CenterVertically), Alignment.CenterHorizontally) {
                        Txt(Faces[e.stage], 30)
                        Txt(if (e.added >= startOfDay(now)) timeOf(e.added) else fmt("EEE", e.added), 12, P.mute)
                    }
                }
            }
            DashedSlot(Modifier.width(68.dp).height(80.dp), 20.dp) { add() }
        }
    }
}

@Composable
private fun ColumnScope.StatsTab(entries: List<Item>, now: Long) {
    val days = (6 downTo 0).map { startOfDay(now, -it) }
    val byDay = entries.groupBy { startOfDay(it.added) }
    val todays = byDay[days.last()].orEmpty()
    val week = entries.filter { it.added >= days.first() }
    val top = entries.groupingBy { it.stage }.eachCount().maxByOrNull { it.value }
    fun face(list: List<Item>) = if (list.isEmpty()) "–" else Faces[levelOf(list.averageRating())]

    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 110.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(
                Triple("TODAY", face(todays), "${todays.size} entries"),
                Triple("THIS WEEK", face(week), "${week.size} entries"),
                Triple("MOST FREQUENT", top?.let { Faces[it.key] } ?: "–", top?.let { "${it.value}×" } ?: "–"),
            ).forEach { (cap, icon, sub) ->
                Card(Modifier.weight(1f), 22) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), Arrangement.spacedBy(8.dp), Alignment.CenterHorizontally) {
                        Txt(cap, 10, P.mute, ls = 0.06.em, maxLines = 1)
                        Txt(icon, 30)
                        Txt(sub, 13, P.mute)
                    }
                }
            }
        }
        Card(Modifier.fillMaxWidth().padding(top = 14.dp)) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 14.dp)) {
                Txt("LAST 7 DAYS · RATING", 11, P.mute, Modifier.padding(bottom = 12.dp), ls = 0.08.em)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.height(150.dp).width(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        listOf(10, 8, 6, 4, 2).forEach { Txt("$it", 11, P.mute) }
                    }
                    Column(Modifier.weight(1f)) {
                        val line = P.line
                        Row(
                            Modifier.fillMaxWidth().height(150.dp).drawBehind {
                                val step = 30.dp.toPx()
                                for (k in 0..5) drawLine(line, Offset(0f, minOf(k * step, size.height - 1f)), Offset(size.width, minOf(k * step, size.height - 1f)), 1.dp.toPx())
                            },
                            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom,
                        ) {
                            days.forEachIndexed { i, d ->
                                val avg = byDay[d].orEmpty().averageRating()
                                Box(
                                    Modifier.weight(1f).height((avg * 15f).dp)
                                        .clip(RoundedCornerShape(8.dp, 8.dp, 4.dp, 4.dp))
                                        .background(if (i == days.lastIndex) Coral else Coral.copy(alpha = 0.35f))
                                )
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            days.forEach { Txt(fmt("EEE", it), 11, P.mute, Modifier.weight(1f), align = TextAlign.Center, maxLines = 1) }
                        }
                    }
                }
            }
        }
        Cap("DAILY AVERAGES")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            days.reversed().filter { byDay[it].orEmpty().isNotEmpty() }.forEach { d ->
                val avg = byDay[d].orEmpty().averageRating()
                Row(
                    Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(22.dp)).background(P.surface).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Txt(Faces[levelOf(avg)], 26)
                    Txt(fmt("EEE", d), 16, modifier = Modifier.weight(1f))
                    Meter(avg, Modifier.width(100.dp))
                    Txt(oneDecimal(avg), 14, P.mute, Modifier.width(30.dp), align = TextAlign.End)
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.HistoryTab(vm: BinderViewModel, l: BinderList, entries: List<Item>, now: Long) {
    val groups = entries.groupBy { startOfDay(it.added) }.toList()
    LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 110.dp)) {
        groups.forEach { (day, list) ->
            item(key = "day$day") { Cap(dayName(day, now).uppercase(), Modifier.padding(start = 4.dp)) }
            items(list, key = { it.id }) { e ->
                val edit = { vm.nav.push(Route.ItemEdit(l.id, e.id)) }
                Box(Modifier.padding(bottom = 8.dp)) {
                    SwipeRow(true, "Edit", "Delete", onRight = { edit() }, onLeft = { vm.deleteItem(l.id, e) }) {
                        Row(
                            Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(22.dp)).background(P.surface)
                                .clickable { edit() }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Box(Modifier.width(48.dp), contentAlignment = Alignment.Center) { Txt(Faces[e.stage], 32) }
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) { Txt(e.title, 16); Dot(7) }
                                Txt(e.line(), 12, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Txt(timeOf(e.added), 14, P.mute)
                                Box(Modifier.padding(top = 2.dp)) { Rate(e.rating, 13) }
                            }
                        }
                    }
                }
            }
        }
        item { Txt("Swipe left on an entry to delete it", 12, P.mute, Modifier.fillMaxWidth().padding(top = 8.dp), align = TextAlign.Center) }
    }
}

// ───────── new entry ─────────

@Composable
fun EntryScreen(vm: BinderViewModel, listId: String, itemId: String?) {
    val nav = vm.nav
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.items?.firstOrNull { it.id == itemId }
    var level by rememberSaveable { mutableStateOf(existing?.stage ?: 3) }
    var rating by rememberSaveable { mutableStateOf(existing?.rating?.roundToInt() ?: defaultRating(3)) }
    var touched by rememberSaveable { mutableStateOf(existing != null) } // once you move the slider, faces stop changing it
    var note by rememberSaveable { mutableStateOf(existing?.note ?: "") }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    Screen {
        Header2(
            if (existing == null) "New entry" else "Edit entry", l.name, onBack = { nav.pop() },
            right = { if (existing != null) CircleBtn(Ic.Close, "Delete entry") { vm.deleteItem(l.id, existing); nav.pop() } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Cap("HOW DO YOU FEEL?", Modifier.padding(start = 4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Faces.forEachIndexed { i, f ->
                    val shape = RoundedCornerShape(20.dp)
                    Box(
                        Modifier.width(58.dp).height(62.dp).clip(shape).background(P.surface)
                            .border(2.dp, if (i == level) P.fg else androidx.compose.ui.graphics.Color.Transparent, shape)
                            .clickable { level = i; if (!touched) rating = defaultRating(i) },
                        contentAlignment = Alignment.Center,
                    ) { Txt(f, 30) }
                }
            }
            Txt(Words[level], 14, P.mute, Modifier.fillMaxWidth().padding(top = 8.dp), align = TextAlign.Center)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Cap("RATING", Modifier.padding(start = 4.dp))
                Box(Modifier.padding(bottom = 8.dp, end = 4.dp)) { Rate(rating.toFloat()) }
            }
            TenSlider(rating) { rating = it; touched = true }
            Cap("NOTE", Modifier.padding(start = 4.dp))
            Field("Optional · what is going on?", note) { note = it }
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Save entry", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val item = (existing ?: Item(title = "")).copy(title = Words[level], stage = level, rating = rating.toFloat(), note = note.trim())
            vm.saveItem(l.id, item)
            nav.pop()
        }
    }
}

/** 1 to 10. The thumb sits right over its number; tap or drag anywhere on the track. */
@Composable
private fun TenSlider(value: Int, onChange: (Int) -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val toValue = { x: Float -> 1 + (((x - w / 20f) / (w * 0.9f)) * 9f).coerceIn(0f, 9f).roundToInt() }
    val centre = w / 20f + (value - 1) / 9f * (w * 0.9f)
    Column(Modifier.padding(top = 8.dp)) {
        Box(
            Modifier.fillMaxWidth().height(28.dp).onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
                .pointerInput(Unit) { detectTapGestures { onChange(toValue(it.x)) } }
                .pointerInput(Unit) { detectHorizontalDragGestures { c, _ -> c.consume(); onChange(toValue(c.position.x)) } }
        ) {
            Box(Modifier.fillMaxWidth().padding(top = 10.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(P.line))
            Box(Modifier.padding(top = 10.dp).width(with(androidx.compose.ui.platform.LocalDensity.current) { centre.toDp() }).height(8.dp).clip(RoundedCornerShape(4.dp)).background(Coral))
            Box(
                Modifier.offset { IntOffset((centre - 14.dp.toPx()).roundToInt(), 0) }
                    .size(28.dp).clip(CircleShape).background(P.fg)
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            (1..10).forEach { Txt("$it", 11, P.mute, Modifier.weight(1f), align = TextAlign.Center) }
        }
    }
}
