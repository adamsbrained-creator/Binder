package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// The look of a bind: the colour behind its card on Home and the icon it wears there.
// A bind saves them as two optional keys ("tint" = a place in Tints, "emoji" = the icon). Without them a bind looks as it always did.

/** A background colour for a bind's card. Soft in light mode, deep in dark mode, so the text on top stays readable. */
class Tint(val name: String, val light: Color, val dark: Color)

val Tints = listOf(
    Tint("Butter", Color(0xFFFFEFB8), Color(0xFF4A4020)),
    Tint("Rose", Color(0xFFFFD9E2), Color(0xFF4A2630)),
    Tint("Peach", Color(0xFFFFDCC2), Color(0xFF4A3322)),
    Tint("Lavender", Color(0xFFDDD6FF), Color(0xFF30294F)),
    Tint("Sky", Color(0xFFCFE6FF), Color(0xFF203548)),
    Tint("Aqua", Color(0xFFD3F1EE), Color(0xFF1F4140)),
    Tint("Mint", Color(0xFFD6F3D9), Color(0xFF244230)),
    Tint("Lime", Color(0xFFE6F4C8), Color(0xFF38421F)),
    Tint("Orchid", Color(0xFFF7D6FF), Color(0xFF462A4F)),
    Tint("Coral", Color(0xFFFFD6D6), Color(0xFF4A2525)),
    Tint("Sand", Color(0xFFF0E4D0), Color(0xFF3F3626)),
    Tint("Slate", Color(0xFFE2E6EC), Color(0xFF2A2F38)),
)

@Composable
fun Tint.color(): Color = if (P.bg == DarkPal.bg) dark else light

/** The background of a bind's card on Home: its colour if it has one, otherwise the usual grey. */
@Composable
fun BinderList.cardBg(): Color = Tints.getOrNull(tint)?.color() ?: P.surface

/** The emoji a template wears on its tile in New bind. */
val Kind.emoji: String
    get() = when (this) {
        Kind.BOOKS -> "📒"; Kind.MANGA -> "📖"; Kind.COMICS -> "💥"; Kind.MOVIES -> "🎬"; Kind.SERIES -> "📺"
        Kind.ALBUMS -> "💿"; Kind.GAMES -> "🎮"; Kind.PLACES -> "🗺️"; Kind.HEARD -> "🎧"; Kind.ANYTHING -> "✨"
        Kind.CHECKLIST -> "✅"; Kind.TRACKER -> "📊"; Kind.TIME -> "⏳"; Kind.HABITS -> "🌱"; Kind.PRODUCTIVITY -> "🎯"; Kind.TASKS -> "🗓️"
    }

/** The colour a template starts with (a place in [Tints]). */
val Kind.defaultTint: Int
    get() = when (this) {
        Kind.BOOKS -> 0; Kind.MANGA -> 1; Kind.COMICS -> 2; Kind.MOVIES -> 3; Kind.SERIES -> 4
        Kind.ALBUMS -> 5; Kind.GAMES -> 6; Kind.PLACES -> 7; Kind.HEARD -> 8; Kind.ANYTHING -> 11
        Kind.CHECKLIST -> 10; Kind.TRACKER -> 9; Kind.TIME -> 4; Kind.HABITS -> 7; Kind.PRODUCTIVITY -> 2; Kind.TASKS -> 6
    }

/** How New bind groups the templates. Every kind appears exactly once. */
val KindGroups: List<Pair<String, List<Kind>>> = listOf(
    "Media" to listOf(Kind.BOOKS, Kind.MANGA, Kind.COMICS, Kind.MOVIES, Kind.SERIES, Kind.ALBUMS, Kind.GAMES, Kind.PLACES, Kind.HEARD),
    "Tracking and planning" to listOf(Kind.CHECKLIST, Kind.TASKS, Kind.TRACKER, Kind.TIME, Kind.HABITS, Kind.PRODUCTIVITY),
    "From scratch" to listOf(Kind.ANYTHING),
)

/** The icons offered in New bind. Anything else can be typed in. */
val LookEmojis = listOf(
    "📒", "📚", "📖", "💥", "🎬", "📺", "💿", "🎮", "🗺️", "🎧",
    "✨", "✅", "📊", "⏳", "🌱", "🎯", "🔥", "⭐", "❤️", "🍿",
    "🎵", "🎨", "🏋️", "🍳", "✈️", "🏠", "💡", "🧠", "💰", "🛒",
    "📝", "🌍", "🎲", "🧩", "☕", "🐶", "🌙", "💪", "🎸", "📷",
)

/** The first symbol of what was typed (one emoji, even one made of several parts); "" for blank text. */
fun firstEmoji(s: String): String {
    val t = s.trim()
    if (t.isEmpty()) return ""
    val bi = java.text.BreakIterator.getCharacterInstance()
    bi.setText(t)
    val end = bi.next()
    return if (end == java.text.BreakIterator.DONE) t else t.substring(0, end)
}

@Composable
private fun Swatch(color: Color, label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(color)
            .border(2.dp, if (selected) Coral else P.line, CircleShape)
            .semantics { contentDescription = label; this.selected = selected }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { if (label == "None") Txt("–", 18, P.mute) }
}

@Composable
private fun EmojiCell(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier.size(48.dp).clip(shape).background(P.surface)
            .border(2.dp, if (selected) Coral else Color.Transparent, shape)
            .semantics { this.selected = selected }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { if (label == "Auto") Txt("Auto", 12, P.mute) else Txt(label, 24) }
}

/**
 * The Look part of the New bind page: a preview of the Home card, a row of background colours and the icons.
 * [emoji] "" means the bind's usual mark (the progress ring, a tracker's face ...); [tint] -1 means the plain grey card.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LookPicker(
    name: String, emoji: String, tint: Int, custom: String,
    onEmoji: (String) -> Unit, onTint: (Int) -> Unit, onCustom: (String) -> Unit,
    showPreview: Boolean = true,   // false where the page has a preview of its own
) {
    val soft = if (P.bg == DarkPal.bg) P.mute else Color(0xFF505050)
    Cap("LOOK")
    if (showPreview) {
        Row(Modifier.fillMaxWidth()) {
            Box(
                Modifier.weight(1f).height(128.dp).clip(RoundedCornerShape(28.dp))
                    .background(Tints.getOrNull(tint)?.color() ?: P.surface)
            ) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    if (emoji.isEmpty()) ProgressRing(0f, 44.dp)
                    else Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) { Txt(emoji, 32) }
                    Column {
                        Txt(name, 18, weight = FontWeight.Medium, maxLines = 1)
                        Txt("0 of 0 done", 13, soft, Modifier.padding(top = 2.dp), maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
        }
    }
    Txt("Background", 13, P.mute, Modifier.padding(top = 16.dp, bottom = 8.dp))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Swatch(P.surface, "None", tint == -1) { onTint(-1) }
        Tints.forEachIndexed { i, t -> Swatch(t.color(), t.name, tint == i) { onTint(i) } }
    }
    Txt("Icon", 13, P.mute, Modifier.padding(top = 16.dp, bottom = 8.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        EmojiCell("Auto", emoji.isEmpty()) { onEmoji("") }
        LookEmojis.forEach { e -> EmojiCell(e, emoji == e) { onEmoji(e) } }
    }
    Field("Or type your own emoji", custom, Modifier.padding(top = 12.dp)) { onCustom(it) }
}
