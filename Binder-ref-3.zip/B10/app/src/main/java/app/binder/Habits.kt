package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// A Habits bind (Kind.HABITS) is a list of habits you tick off day by day. Pages: the bind (Habits cards / Week table),
// one habit (heat map, streak, month calendar) and the habit editor. The maths is in HabitLogic.kt.
// Each habit is a plain Item; only `marks`, `target` and `streakGoal` are new in the saved file, all optional.

/** The 21 colours a habit can wear (cover = the index; -1 = the accent). */
val HabitColors = listOf(
    Color(0xFFF87171), Color(0xFFFB923C), Color(0xFFFBBF24), Color(0xFFFACC15), Color(0xFFA3E635), Color(0xFF4ADE80), Color(0xFF34D399),
    Color(0xFF2DD4BF), Color(0xFF22D3EE), Color(0xFF38BDF8), Color(0xFF60A5FA), Color(0xFF818CF8), Color(0xFFA78BFA), Color(0xFFC084FC),
    Color(0xFFE879F9), Color(0xFFF472B6), Color(0xFFFB7185), Color(0xFF94A3B8), Color(0xFF9CA3AF), Color(0xFFA3A3A3), Color(0xFFA8A29E),
)

/** Icons to pick from. You can also type any emoji of your own. */
val HabitEmojis = listOf(
    "📚", "🏃", "💧", "🧘", "🛌", "🥗", "💪", "🚴",
    "✍️", "🎸", "🧹", "🪥", "💊", "🧠", "🙏", "🌅",
    "📵", "🎨", "🐕", "💰", "🌱", "☕", "🚭", "🎯",
)

private const val DEFAULT_HABIT_COLOR = 5
private val Ink = OnAccent

private fun Item.habitColor(): Color = if (cover in HabitColors.indices) HabitColors[cover] else Coral

private fun monthFirst(ms: Long): Long =
    Calendar.getInstance().apply { timeInMillis = startOfDay(ms); set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis

private fun monthShift(ms: Long, n: Int): Long =
    Calendar.getInstance().apply { timeInMillis = ms; add(Calendar.MONTH, n) }.timeInMillis

private fun habitMenu(vm: BinderViewModel, l: BinderList, h: Item): SheetData = SheetData(
    h.title,
    listOf(
        Act("Open") { vm.nav.push(Route.Habit(l.id, h.id)) },
        Act("Edit") { vm.nav.push(Route.ItemEdit(l.id, h.id)) },
        Act("Delete", danger = true) { vm.deleteItem(l.id, h) },
    ),
)

// ───────── small pieces ─────────

/** The habit's icon on a tile in its colour. */
@Composable
private fun HabitTile(h: Item, size: Int) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size * 0.3f).dp)).background(h.habitColor().copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center,
    ) { Txt(h.sub.ifBlank { "✨" }, (size * 0.5f).toInt()) }
}

/** The square check button: tap for today. A count habit shows "2/4" and goes up one at a time. */
@Composable
private fun CheckBtn(h: Item, today: Int, size: Int, onTap: () -> Unit) {
    val c = h.habitColor()
    val done = h.doneOn(today)
    val shape = RoundedCornerShape((size * 0.32f).dp)
    Box(
        Modifier.size(size.dp).clip(shape).background(if (done) c else P.bg)
            .border(2.dp, if (done) c else P.line, shape).clickable(onClick = onTap),
        contentAlignment = Alignment.Center,
    ) {
        if (h.isCount()) Txt("${h.countOn(today)}/${h.goal()}", 14, if (done) Ink else P.fg, weight = FontWeight.Medium, maxLines = 1)
        else Icon(Ic.Check, "Done", tint = if (done) Ink else P.mute, modifier = Modifier.size(24.dp))
    }
}

/** The heat map: [cols] weeks side by side, one square per day, the last column is this week. */
@Composable
private fun Heat(h: Item, today: Int, cols: Int, modifier: Modifier = Modifier) {
    val c = h.habitColor()
    val first = remember { Calendar.getInstance().firstDayOfWeek }
    Canvas(modifier.fillMaxWidth().aspectRatio(cols / 7f)) {
        val cell = size.width / cols
        val gap = cell * 0.18f
        val side = cell - gap
        for (col in 0 until cols) {
            for (row in 0 until 7) {
                val d = heatDay(today, first, cols, col, row)
                if (d > today) continue
                val f = h.fractionOn(d)
                val fill = if (f >= 1f) c else if (f > 0f) c.copy(alpha = 0.35f + 0.4f * f) else c.copy(alpha = 0.14f)
                drawRoundRect(fill, Offset(col * cell + gap / 2f, row * cell + gap / 2f), Size(side, side), CornerRadius(side * 0.3f))
            }
        }
    }
}

/** The "Each habit has" part of the New bind page, shown when Habits is picked. */
@Composable
fun HabitsHas(note: String) {
    Txt(note, 12, P.mute, Modifier.padding(start = 4.dp, top = 10.dp))
    Cap("EACH HABIT HAS")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Triple("✅", "Daily check", "done or count"), Triple("🔥", "Streak", "optional goal"), Triple("🎨", "Look", "colour + icon")).forEach { (icon, title, value) ->
            Row(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(Radius.lg)).background(P.surface).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { Txt(icon, 20) }
                Txt(title, 16, modifier = Modifier.weight(1f))
                Txt(value, 14, P.mute)
            }
        }
    }
}

// ───────── the bind page ─────────

@Composable
fun HabitsScreen(vm: BinderViewModel, id: String) {
    val nav = vm.nav
    val o = vm.opts
    var tab by rememberSaveable { mutableStateOf(0) }
    val l = vm.lists.firstOrNull { it.id == id }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val now = System.currentTimeMillis()
    val today = epochDay(now)
    val add = { nav.push(Route.ItemEdit(l.id, null)) }

    Box(Modifier.fillMaxSize()) {
        Screen {
            Header2(
                l.name, habitsLine(l.items, now), onBack = { nav.pop() },
                right = {
                    CircleBtn(Ic.Dots, "${o.list} options") {
                        vm.sheet = SheetData(
                            l.name,
                            listOf(
                                Act("Add habit") { add() },
                                Act(if (l.pinned) "Unpin" else "Pin to top") { vm.togglePin(l.id) },
                                Act("Rename") { vm.rename = l },
                                Act("Delete ${o.listLower}", danger = true) { vm.deleteList(l); nav.pop() },
                            ),
                        )
                    }
                },
            )
            if (l.items.isEmpty()) {
                EmptyBlock("No habits yet", "Add something you want to do every day and tick it off here.", "Add a habit") { add() }
            } else {
                Seg(listOf("Habits", "Week"), tab, Modifier.padding(top = 6.dp)) { tab = it }
                when (tab) {
                    0 -> HabitCards(vm, l, today)
                    else -> WeekTable(vm, l, today)
                }
            }
        }
        MenuFab(vm, onAdd = add, onAddHold = add, addLabel = "New habit")
    }
}

@Composable
private fun ColumnScope.HabitCards(vm: BinderViewModel, l: BinderList, today: Int) {
    LazyColumn(
        Modifier.weight(1f),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(l.items, key = { it.id }) { h ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(Radius.xl)).background(P.surface)
                    .tapHold({ vm.nav.push(Route.Habit(l.id, h.id)) }, { vm.sheet = habitMenu(vm, l, h) })
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    HabitTile(h, 52)
                    Column(Modifier.weight(1f)) {
                        Txt(h.title, 18, weight = FontWeight.Medium, maxLines = 1)
                        Txt(habitSubline(h, today), 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                    }
                    CheckBtn(h, today, 52) { vm.saveItem(l.id, h.tapped(today)) }
                }
                Heat(h, today, 26, Modifier.padding(top = 14.dp))
            }
        }
    }
}

/** The last five days, one row per habit: tap a square to tick that day. */
@Composable
private fun ColumnScope.WeekTable(vm: BinderViewModel, l: BinderList, today: Int) {
    val now = System.currentTimeMillis()
    val days = (4 downTo 0).map { today - it }
    val dayName = SimpleDateFormat("EEE", Locale.getDefault())
    val dayNumber = SimpleDateFormat("d", Locale.getDefault())
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 110.dp)) {
        Cap("LAST 5 DAYS", Modifier.padding(start = 4.dp))
        BinderCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Txt("${l.items.size} ${if (l.items.size == 1) "HABIT" else "HABITS"}", 11, P.mute, Modifier.weight(1f), ls = 0.08.em)
                    days.forEach { d ->
                        val ms = startOfDay(now, d - today)
                        Column(Modifier.width(36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Txt(dayName.format(Date(ms)).take(2), 11, P.mute, maxLines = 1)
                            Txt(dayNumber.format(Date(ms)), 14, if (d == today) P.fg else P.mute, weight = if (d == today) FontWeight.Medium else FontWeight.Normal, maxLines = 1)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                l.items.forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).clickable { vm.nav.push(Route.Habit(l.id, h.id)) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Txt(h.sub.ifBlank { "✨" }, 18)
                        Txt(h.title, 15, modifier = Modifier.weight(1f).padding(start = 8.dp), maxLines = 1)
                        days.forEach { d ->
                            Box(Modifier.width(36.dp), contentAlignment = Alignment.Center) {
                                DayCell(h, d, 32) { vm.saveItem(l.id, h.tapped(d)) }
                            }
                        }
                    }
                }
            }
        }
        Txt("Tap a square to tick a day. Tap a habit to open it.", 12, P.mute, Modifier.fillMaxWidth().padding(top = 12.dp), align = TextAlign.Center)
    }
}

@Composable
private fun DayCell(h: Item, day: Int, size: Int, onTap: () -> Unit) {
    val c = h.habitColor()
    val f = h.fractionOn(day)
    val shape = RoundedCornerShape((size * 0.3f).dp)
    Box(
        Modifier.size(size.dp).clip(shape)
            .background(if (f >= 1f) c else if (f > 0f) c.copy(alpha = 0.35f + 0.4f * f) else c.copy(alpha = 0.14f))
            .clickable(onClick = onTap),
        contentAlignment = Alignment.Center,
    ) {
        if (f >= 1f) Icon(Ic.Check, null, tint = Ink, modifier = Modifier.size((size * 0.5f).dp))
        else if (f > 0f) Txt("${h.countOn(day)}", 12, P.fg)
    }
}

// ───────── one habit ─────────

@Composable
private fun HabitChip(text: String, c: Color) {
    Box(Modifier.clip(CircleShape).background(c.copy(alpha = 0.18f)).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Txt(text, 13, c, weight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier) {
    BinderCard(modifier, Radius.lg) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), Arrangement.spacedBy(6.dp), Alignment.CenterHorizontally) {
            Txt(value, 26, weight = FontWeight.Medium, maxLines = 1)
            Txt(label, 10, P.mute, ls = 0.06.em, maxLines = 1)
        }
    }
}

@Composable
private fun Glyph(glyph: String, onClick: () -> Unit) =
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Txt(glyph, 20, P.mute) }

/** A month calendar for one habit: tap a day to tick it (a count goes up one at a time). Days to come cannot be ticked. */
@Composable
private fun HabitMonth(h: Item, shown: Long, setShown: (Long) -> Unit, today: Int, onTap: (Int) -> Unit) {
    val c = h.habitColor()
    val cal = Calendar.getInstance().apply { timeInMillis = shown }
    val first = cal.firstDayOfWeek
    val lead = (cal.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val rows = (lead + days + 6) / 7
    val names = DateFormatSymbols.getInstance().shortWeekdays
    val thisMonth = monthFirst(System.currentTimeMillis())

    BinderCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Glyph("‹") { setShown(monthShift(shown, -1)) }
                Txt(
                    SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(shown)), 16, weight = FontWeight.Medium,
                    modifier = Modifier.weight(1f), align = TextAlign.Center, maxLines = 1,
                )
                Glyph("›") { setShown(monthShift(shown, 1)) }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
                for (i in 0 until 7) {
                    Txt(names[(first - 1 + i) % 7 + 1].take(2), 11, P.mute, Modifier.weight(1f), align = TextAlign.Center, maxLines = 1)
                }
            }
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0 until 7) {
                        val d = r * 7 + col - lead + 1
                        if (d < 1 || d > days) {
                            Spacer(Modifier.weight(1f).height(44.dp))
                        } else {
                            val day = epochDay(startOfDay(shown, d - 1))
                            val f = h.fractionOn(day)
                            val future = day > today
                            val shape = RoundedCornerShape(Radius.sm)
                            Box(
                                Modifier.weight(1f).height(44.dp).padding(2.dp).clip(shape)
                                    .background(if (f >= 1f) c else if (f > 0f) c.copy(alpha = 0.35f + 0.4f * f) else Color.Transparent)
                                    .border(2.dp, if (day == today) c else Color.Transparent, shape)
                                    .clickable(enabled = !future) { onTap(day) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Txt(
                                    "$d", 14,
                                    if (f >= 1f) Ink else if (future) P.mute.copy(alpha = 0.5f) else P.fg,
                                    weight = if (f >= 1f) FontWeight.Medium else FontWeight.Normal,
                                )
                            }
                        }
                    }
                }
            }
            if (shown != thisMonth) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
                    Pill("Today") { setShown(thisMonth) }
                }
            }
        }
    }
}

@Composable
fun HabitDetailScreen(vm: BinderViewModel, listId: String, itemId: String) {
    val nav = vm.nav
    var shown by rememberSaveable { mutableStateOf(monthFirst(System.currentTimeMillis())) }
    val l = vm.lists.firstOrNull { it.id == listId }
    val h = l?.items?.firstOrNull { it.id == itemId }
    if (l == null || h == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val today = epochDay(System.currentTimeMillis())
    val c = h.habitColor()
    val streak = h.currentStreak(today)
    val goalText = when {
        h.streakGoal <= 0 -> "No streak goal"
        streak >= h.streakGoal -> "Goal of ${h.streakGoal} days reached"
        else -> "Goal ${h.streakGoal} days · ${h.streakGoal - streak} to go"
    }

    Screen {
        Header2(
            l.name, "", onBack = { nav.pop() },
            right = { CircleBtn(Ic.Edit, "Edit habit") { nav.push(Route.ItemEdit(l.id, h.id)) } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                HabitTile(h, 64)
                Column(Modifier.weight(1f)) {
                    Txt(h.title, 26, weight = FontWeight.Medium, ls = (-0.02).em)
                    if (h.note.isNotBlank()) Txt(h.note, 14, P.mute, Modifier.padding(top = 2.dp))
                }
            }
            BinderCard(Modifier.fillMaxWidth().padding(top = 16.dp)) { Heat(h, today, 26, Modifier.padding(14.dp)) }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HabitChip(if (streak == 1) "1 day streak" else "$streak day streak", c)
                HabitChip(goalText, c)
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("${h.bestStreak()}", "BEST STREAK", Modifier.weight(1f))
                StatCard("${h.daysDone()}", "DAYS DONE", Modifier.weight(1f))
                StatCard("${(h.completionRate(today) * 100).roundToInt()}%", "COMPLETION", Modifier.weight(1f))
            }
            Cap("CALENDAR", Modifier.padding(start = 4.dp))
            HabitMonth(h, shown, { shown = it }, today) { day -> vm.saveItem(l.id, h.tapped(day)) }
            Txt(
                if (h.isCount()) "Tap a day to add one. It is done at ${h.goal()}." else "Tap a day to tick it or untick it.",
                12, P.mute, Modifier.fillMaxWidth().padding(top = 12.dp), align = TextAlign.Center,
            )
        }
    }
}

// ───────── new / edit habit ─────────

@Composable
private fun StepBtn(glyph: String, onClick: () -> Unit) =
    Box(Modifier.size(36.dp).clip(CircleShape).background(P.line).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Txt(glyph, 20) }

@Composable
fun HabitEditScreen(vm: BinderViewModel, listId: String, itemId: String?) {
    val nav = vm.nav
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.items?.firstOrNull { it.id == itemId }
    var name by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var desc by rememberSaveable { mutableStateOf(existing?.note ?: "") }
    var icon by rememberSaveable { mutableStateOf(existing?.sub ?: HabitEmojis.first()) }
    var color by rememberSaveable { mutableStateOf(existing?.cover?.takeIf { it in HabitColors.indices } ?: DEFAULT_HABIT_COLOR) }
    var count by rememberSaveable { mutableStateOf(existing?.isCount() ?: false) }
    var goal by rememberSaveable { mutableStateOf(existing?.goal()?.takeIf { it > 1 } ?: 2) }
    var streak by rememberSaveable { mutableStateOf(existing?.streakGoal ?: 0) }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val c = HabitColors[color]

    Screen {
        Header2(
            if (existing == null) "New habit" else "Edit habit", l.name, onBack = { nav.pop() },
            right = { if (existing != null) CircleBtn(Ic.Close, "Delete habit") { vm.deleteItem(l.id, existing); nav.pop() } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Field("Name · Read, Run, Drink water…", name, Modifier.padding(top = 6.dp)) { name = it }
            Spacer(Modifier.height(10.dp))
            Field("Description · optional", desc) { desc = it }

            Cap("ICON", Modifier.padding(start = 4.dp))
            Field("Icon · pick one or type your own emoji", icon) { icon = it }
            HabitEmojis.chunked(8).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { e ->
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(Radius.sm))
                                .background(if (e == icon.trim()) c.copy(alpha = 0.3f) else P.surface)
                                .clickable { icon = e },
                            contentAlignment = Alignment.Center,
                        ) { Txt(e, 20) }
                    }
                    repeat(8 - row.size) { Spacer(Modifier.size(38.dp)) }
                }
            }

            Cap("COLOR", Modifier.padding(start = 4.dp))
            HabitColors.chunked(7).forEachIndexed { r, row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEachIndexed { k, col ->
                        val i = r * 7 + k
                        val shape = RoundedCornerShape(Radius.sm)
                        Box(
                            Modifier.size(40.dp).clip(shape).background(col)
                                .border(3.dp, if (i == color) P.fg else Color.Transparent, shape)
                                .clickable { color = i },
                        )
                    }
                }
            }

            Cap("TRACKING", Modifier.padding(start = 4.dp))
            Seg(listOf("Yes / No", "Count"), if (count) 1 else 0) { count = it == 1 }
            Txt(
                if (count) "Tap to add one. The day is done when you reach the goal." else "Check the day off: done or not done.",
                12, P.mute, Modifier.padding(start = 4.dp, top = 8.dp),
            )
            if (count) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp).height(56.dp).clip(RoundedCornerShape(Radius.lg)).background(P.surface).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Txt("Times a day", 16, modifier = Modifier.weight(1f))
                    StepBtn("−") { goal = (goal - 1).coerceAtLeast(2) }
                    Txt("$goal", 18, weight = FontWeight.Medium, modifier = Modifier.width(44.dp), align = TextAlign.Center)
                    StepBtn("+") { goal = (goal + 1).coerceAtMost(99) }
                }
            }

            Cap("STREAK GOAL", Modifier.padding(start = 4.dp))
            FlowChips(StreakGoals.map { streakGoalLabel(it) }, StreakGoals.indexOf(streak)) { streak = StreakGoals[it] }
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Save habit", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val item = (existing ?: Item(title = "")).copy(
                title = name.trim().ifBlank { "Habit" }, note = desc.trim(), sub = icon.trim(), cover = color,
                target = if (count) goal else 1, streakGoal = streak,
            )
            vm.saveItem(l.id, item)
            nav.pop()
        }
    }
}
