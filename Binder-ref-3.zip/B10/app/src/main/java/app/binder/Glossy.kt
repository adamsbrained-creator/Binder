package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.graphics.vector.toPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ───────── glossy icons ─────────
// Soft 3D objects with a vertical gradient, a shine on top and a little shadow, drawn on a 48 x 48 grid.
// (The look comes from the Showcase mockup; the shapes are Binder's own.)

private val pathCache = HashMap<String, Path>()
private fun pth(d: String): Path = pathCache.getOrPut(d) { addPathNodes(d).toPath() }

private fun vg(top: Long, bottom: Long, y0: Float, y1: Float): Brush =
    Brush.verticalGradient(listOf(Color(top), Color(bottom)), startY = y0, endY = y1)

private fun DrawScope.fillP(d: String, b: Brush) = drawPath(pth(d), b)
private fun DrawScope.fillC(d: String, c: Color) = drawPath(pth(d), c)
private fun DrawScope.strokeP(d: String, c: Color, w: Float) =
    drawPath(pth(d), c, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))

private fun DrawScope.rr(x: Float, y: Float, w: Float, h: Float, r: Float, b: Brush) =
    drawRoundRect(b, Offset(x, y), Size(w, h), CornerRadius(r, r))

private fun DrawScope.rrc(x: Float, y: Float, w: Float, h: Float, r: Float, c: Color) =
    drawRoundRect(c, Offset(x, y), Size(w, h), CornerRadius(r, r))

private fun DrawScope.shine(cx: Float, cy: Float, rx: Float, ry: Float, a: Float = 0.4f) =
    drawOval(Color.White.copy(alpha = a), Offset(cx - rx, cy - ry), Size(rx * 2f, ry * 2f))

private fun DrawScope.ground() {
    drawOval(Color.Black.copy(alpha = 0.22f), Offset(9f, 41f), Size(30f, 5f))
}

private val PaperTop = 0xFFFFFFFF
private val PaperBottom = 0xFFD5DBE6
private val Line = Color(0xFFAEB9C9)

private fun DrawScope.media(top: Long, bottom: Long, back: Color) {
    ground()
    rotate(8f, Offset(27f, 20f)) { rrc(13f, 5f, 28f, 30f, 7f, back.copy(alpha = 0.75f)) }
    rr(6f, 11f, 31f, 31f, 8f, vg(top, bottom, 11f, 42f))
    fillC("M18 20 l12 6.5 l-12 6.5 z", Color.White)
    shine(17f, 16f, 7f, 2.5f, 0.35f)
}

private fun DrawScope.book(top: Long, bottom: Long) {
    ground()
    fillP("M3 13 c7 -3 15 -2 21 2 c6 -4 14 -5 21 -2 v26 c-7 -3 -15 -2 -21 2 c-6 -4 -14 -5 -21 -2 z", vg(top, bottom, 12f, 41f))
    fillP("M7 12 c6 -2 12 -1 17 2.5 v22 c-5 -3.5 -11 -4 -17 -2 z", vg(PaperTop, PaperBottom, 12f, 36f))
    fillP("M41 12 c-6 -2 -12 -1 -17 2.5 v22 c5 -3.5 11 -4 17 -2 z", vg(PaperTop, PaperBottom, 12f, 36f))
    strokeP("M11 20 c3 -1 6 -1 9 1 M37 20 c-3 -1 -6 -1 -9 1 M11 26 c3 -1 6 -1 9 1 M37 26 c-3 -1 -6 -1 -9 1", Line, 2f)
}

private fun DrawScope.drawGloss(g: Gloss) {
    when (g) {
        Gloss.SUN -> {
            ground()
            strokeP("M24 4 v4 M24 40 v4 M4 24 h4 M40 24 h4 M9.9 9.9 l2.8 2.8 M35.3 35.3 l2.8 2.8 M9.9 38.1 l2.8 -2.8 M35.3 12.7 l2.8 -2.8", Color(0xFFFFC24A), 3.5f)
            drawCircle(vg(0xFFFFE17A, 0xFFF59A0B, 12f, 36f), 12f, Offset(24f, 24f))
            shine(20.5f, 18.5f, 5.5f, 3f, 0.45f)
        }
        Gloss.CHECK -> {
            ground()
            rr(9f, 6f, 30f, 37f, 7f, vg(0xFF5EEAD4, 0xFF0E8F85, 6f, 43f))
            rr(13f, 12f, 22f, 27f, 4f, vg(PaperTop, PaperBottom, 12f, 39f))
            rrc(17f, 3f, 14f, 8f, 4f, Color(0xFF0B6F66))
            strokeP("M18 24 l4 4 l8 -9", Color(0xFF0E8F85), 3.5f)
            rrc(18f, 32f, 12f, 2.5f, 1.2f, Color(0xFFA3AEBD))
        }
        Gloss.MEDIA -> media(0xFFB79CFF, 0xFF5B3BD0, Color(0xFF6B4BE0))
        Gloss.MEDIAB -> media(0xFF7DC4FF, 0xFF2E6BE0, Color(0xFF2E6BE0))
        Gloss.BOOK -> book(0xFF5BE3A0, 0xFF0E8A5A)
        Gloss.BOOKB -> book(0xFF7DC4FF, 0xFF2E6BE0)
        Gloss.BOOKR -> book(0xFFFF7B8A, 0xFFD01C42)
        Gloss.DISC -> {
            ground()
            drawCircle(vg(0xFF3A3F4B, 0xFF0F1117, 5f, 43f), 19f, Offset(24f, 24f))
            drawCircle(Color.White.copy(alpha = 0.12f), 14f, Offset(24f, 24f), style = Stroke(0.8f))
            drawCircle(Color.White.copy(alpha = 0.12f), 11f, Offset(24f, 24f), style = Stroke(0.8f))
            drawCircle(vg(0xFFFF9A4D, 0xFFE4431B, 17f, 31f), 7f, Offset(24f, 24f))
            drawCircle(OnAccent, 1.8f, Offset(24f, 24f))
            rotate(-35f, Offset(17f, 14f)) { shine(17f, 14f, 7f, 2.5f, 0.22f) }
        }
        Gloss.PAD -> {
            ground()
            fillP(
                "M13 15 h22 c5 0 8 4 9 10 l1.5 8 c0.7 4 -2 6.5 -5.5 6 c-2.5 -0.4 -4 -2 -5.5 -4 h-21 " +
                    "c-1.5 2 -3 3.6 -5.5 4 c-3.5 0.5 -6.2 -2 -5.5 -6 L4 25 c1 -6 4 -10 9 -10 z",
                vg(0xFF7DC4FF, 0xFF2E6BE0, 15f, 40f),
            )
            rrc(11f, 20f, 10f, 3f, 1.5f, Color.White)
            rrc(14.5f, 16.5f, 3f, 10f, 1.5f, Color.White)
            drawCircle(Color(0xFFFFE17A), 2.2f, Offset(33f, 21f))
            drawCircle(Color(0xFFFF7B8A), 2.2f, Offset(37f, 25f))
            shine(18f, 17.5f, 8f, 1.8f, 0.3f)
        }
        Gloss.PIN -> {
            ground()
            fillP("M24 4 c-7.5 0 -13 5.5 -13 12.5 c0 9 13 27 13 27 s13 -18 13 -27 C37 9.5 31.5 4 24 4 z", vg(0xFFFF7B8A, 0xFFD01C42, 4f, 44f))
            drawCircle(vg(PaperTop, PaperBottom, 11f, 22f), 5f, Offset(24f, 16.5f))
            shine(18.5f, 12f, 2.5f, 5f, 0.35f)
        }
        Gloss.SPARK -> {
            ground()
            fillP("M24 4 C25.5 15 33 22.5 44 24 C33 25.5 25.5 33 24 44 C22.5 33 15 25.5 4 24 C15 22.5 22.5 15 24 4 z", vg(0xFFC7B2FF, 0xFF6B4BE0, 4f, 44f))
            fillC("M38 4 C38.5 7 40 8.5 43 9 C40 9.5 38.5 11 38 14 C37.5 11 36 9.5 33 9 C36 8.5 37.5 7 38 4 z", Color(0xFFFFE17A))
            shine(20f, 19f, 3f, 1.6f, 0.45f)
        }
        Gloss.FACE -> {
            ground()
            drawCircle(vg(0xFFFFE17A, 0xFFF59A0B, 6f, 42f), 18f, Offset(24f, 24f))
            drawCircle(Color(0xFF4A2E00), 2.2f, Offset(18f, 21f))
            drawCircle(Color(0xFF4A2E00), 2.2f, Offset(30f, 21f))
            strokeP("M17 29 C20 32 28 32 31 29", Color(0xFF4A2E00), 2.5f)
            shine(19f, 14f, 6f, 2.5f, 0.4f)
        }
        Gloss.MIC -> {
            strokeP("M12 24 a12 12 0 0 0 24 0", Color(0xFFE2E4EC), 3f)
            strokeP("M24 36 v6 M18 42 h12", Color(0xFFE2E4EC), 3f)
            rr(17f, 5f, 14f, 24f, 7f, vg(0xFFFF9FC4, 0xFFD6336C, 5f, 29f))
            strokeP("M21 12 h6 M21 17 h6", Color.White.copy(alpha = 0.5f), 1.8f)
            shine(21f, 10f, 2f, 4f, 0.4f)
        }
        Gloss.FLAME -> {
            ground()
            fillP("M25 4 c1 8 12 12 12 25 a13 13 0 0 1 -26 0 c0 -5 2 -8 5 -11 c1 3 2 4.5 4 5 c-1 -6 -1 -12 5 -19 z", vg(0xFFFFC247, 0xFFEA4A1A, 4f, 42f))
            fillC("M24 42 a7 7 0 0 1 -7 -7 c0 -4 4 -6.5 7 -11 c3 4.5 7 7 7 11 a7 7 0 0 1 -7 7 z", Color(0xFFFFE08A))
            shine(17f, 26f, 2f, 4f, 0.3f)
        }
        Gloss.TASKS -> {
            ground()
            rr(6f, 6f, 36f, 37f, 8f, vg(0xFFFFE17A, 0xFFF59A0B, 6f, 43f))
            rr(11f, 12f, 26f, 9f, 4.5f, vg(PaperTop, PaperBottom, 12f, 21f))
            strokeP("M15 16.5 l2 2 l3.5 -4", Color(0xFFF59A0B), 2.2f)
            rrc(24f, 15f, 9f, 2.5f, 1.2f, Color(0xFFA3AEBD))
            rr(11f, 24f, 18f, 9f, 4.5f, vg(PaperTop, PaperBottom, 24f, 33f))
            rrc(21f, 27f, 5f, 2.5f, 1.2f, Color(0xFFA3AEBD))
            rrc(11f, 36f, 14f, 3f, 1.5f, Color.White.copy(alpha = 0.55f))
            shine(17f, 9f, 8f, 2f, 0.35f)
        }
        Gloss.CAL -> {
            ground()
            rr(6f, 9f, 36f, 34f, 8f, vg(PaperTop, PaperBottom, 9f, 43f))
            fillP("M6 17 a8 8 0 0 1 8 -8 h20 a8 8 0 0 1 8 8 v4 H6 z", vg(0xFFFF9A4D, 0xFFE4431B, 9f, 21f))
            rrc(14f, 4f, 4.5f, 9f, 2.2f, Color(0xFFB33A12))
            rrc(29.5f, 4f, 4.5f, 9f, 2.2f, Color(0xFFB33A12))
            val dot = Color(0xFFF08A3C)
            drawCircle(dot, 2.2f, Offset(15f, 29f))
            drawCircle(dot, 2.2f, Offset(24f, 29f))
            drawCircle(dot, 2.2f, Offset(33f, 29f))
            drawCircle(dot, 2.2f, Offset(15f, 37f))
            drawCircle(vg(0xFFFF9A4D, 0xFFE4431B, 33f, 41f), 3.5f, Offset(24f, 37f))
            drawCircle(Color(0xFFC9D0DC), 2.2f, Offset(33f, 37f))
        }
    }
}

@Composable
fun GlossIcon(g: Gloss, size: Dp) {
    Canvas(Modifier.size(size)) {
        scale(this.size.width / 48f, Offset.Zero) { drawGloss(g) }
    }
}

/** The icon at the start of a bind on the Showcase home: its own emoji if it has one, otherwise the glossy icon of its kind. */
@Composable
fun GlossMark(l: BinderList, size: Dp = 46.dp) {
    val own = l.emoji.trim()
    if (own.isNotEmpty()) Box(Modifier.size(size), contentAlignment = Alignment.Center) { Txt(own, (size.value * 0.72f).toInt()) }
    else GlossIcon(l.kind.gloss(), size)
}
