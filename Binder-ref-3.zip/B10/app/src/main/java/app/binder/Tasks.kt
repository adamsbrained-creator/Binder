package app.binder

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// The Tasks bind (Kind.TASKS): Day (a timeline of the day, with a week strip) and List (overdue, today, later, done).
// The rules live in TasksLogic.kt. Every task is a plain Item, so backups and older files need nothing new.

/** The day to start a new task on, set by the page before it opens the New task screen. */
object TasksState {
    var newDay: Long = 0L
}

private const val Pitch = 78          // dp for one hour on the timeline
private const val FirstHour = 6       // the timeline starts at 6 AM, or earlier if a task is earlier

private fun fd(p: String, ms: Long) = SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))

private fun minuteNow(ms: Long): Int = Calendar.getInstance().apply { timeInMillis = ms }.let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }

/** "9:30 AM" for 570. */
fun clock(minute: Int): String {
    val h = (minute / 60) % 24
    val m = minute % 60
    return "${if (h % 12 == 0) 12 else h % 12}:${m.toString().padStart(2, '0')} ${if (h < 12) "AM" else "PM"}"
}

private fun hourLabel(h: Int): String = "${if (h % 12 == 0) 12 else h % 12} ${if (h % 24 < 12) "AM" else "PM"}"

private fun dayWord(d: Long, now: Long): String = when (d) {
    startOfDay(now) -> "Today"
    startOfDay(now, 1) -> "Tomorrow"
    startOfDay(now, -1) -> "Yesterday"
    else -> fd("EEE, MMM d", d)
}

private fun taskMeta(t: Item, now: Long, showDate: Boolean): String {
    val parts = ArrayList<String>()
    if (showDate && t.isDated && !t.repeats) parts.add(dayWord(startOfDay(t.due), now))
    if (t.isTimed) parts.add(clock(t.minuteOfDay()))
    if (t.repeats) parts.add(t.repeatKind.label)
    return parts.joinToString(" · ")
}

/** The "Each task has" part of the New bind page, shown when Tasks is picked. */
@Composable
fun TasksHas(note: String) {
    Txt(note, 12, P.mute, Modifier.padding(start = 4.dp, top = 10.dp))
    Cap("EACH TASK HAS")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
            Triple("🗓️", "A day and a time", "or just a day"), Triple("⏱️", "A length", "shown on the timeline"),
            Triple("🔁", "A repeat", "daily, weekly, monthly"), Triple("⭐", "A priority", "normal or high"),
        ).forEach { (icon, title, value) ->
            Row(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(Radius.lg)).background(P.surface).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { Txt(icon, 20) }
                Txt(title, 16, modifier = Modifier.weight(1f))
                Txt(value, 14, P.mute)
            }
        }
    }
}

// ───────── small pieces ─────────

@Composable
private fun PriorityDot() = Box(Modifier.padding(start = 6.dp).size(7.dp).clip(CircleShape).background(Coral))

@Composable
private fun TaskCheck(done: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).then(if (done) Modifier.background(Coral) else Modifier.border(2.dp, P.mute, CircleShape)),
            contentAlignment = Alignment.Center,
        ) { if (done) Icon(Ic.Check, "Done", tint = OnAccent, modifier = Modifier.size(16.dp)) }
    }
}

@Composable
private fun TaskRow(vm: BinderViewModel, l: BinderList, t: Item, day: Long, now: Long, showDate: Boolean) {
    val done = t.doneOn(day)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(Radius.lg)).background(P.surface)
            .clickable { vm.nav.push(Route.ItemEdit(l.id, t.id)) }.padding(start = 8.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        TaskCheck(done) { vm.saveItem(l.id, t.withDone(day, !done)) }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(t.title, 16, if (done) P.mute else P.fg, Modifier.weight(1f, fill = false), maxLines = 1, strike = done)
                if (t.isHigh) PriorityDot()
            }
            val meta = taskMeta(t, now, showDate)
            if (meta.isNotEmpty()) Txt(meta, 12, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
        }
    }
}

@Composable
private fun TimelinePill(modifier: Modifier, vm: BinderViewModel, l: BinderList, t: Item, day: Long, tall: Boolean) {
    val done = t.doneOn(day)
    val bg = if (done) Brush.horizontalGradient(listOf(Coral.copy(alpha = 0.28f), Coral.copy(alpha = 0.10f)))
    else Brush.horizontalGradient(listOf(P.surface, P.surface))
    Row(
        modifier.clip(RoundedCornerShape(Radius.sm)).background(bg).clickable { vm.nav.push(Route.ItemEdit(l.id, t.id)) }.padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(t.title, 15, if (done) P.mute else P.fg, Modifier.weight(1f, fill = false), maxLines = 1)
                if (t.isHigh) PriorityDot()
            }
            if (tall) {
                val end = t.minuteOfDay() + t.minutes()
                Txt("${clock(t.minuteOfDay())} – ${clock(end % (24 * 60))}" + (if (t.repeats) " · ${t.repeatKind.label}" else ""), 12, P.mute, maxLines = 1)
            }
        }
        TaskCheck(done) { vm.saveItem(l.id, t.withDone(day, !done)) }
    }
}

// ───────── the page ─────────

@Composable
fun TasksScreen(vm: BinderViewModel, id: String) {
    val nav = vm.nav
    val o = vm.opts
    val l = vm.lists.firstOrNull { it.id == id }
    var day by rememberSaveable { mutableStateOf(startOfDay(System.currentTimeMillis())) }
    var view by rememberSaveable { mutableStateOf(0) }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val now = System.currentTimeMillis()
    val todayStart = startOfDay(now)
    val add = {
        TasksState.newDay = if (view == 0) day else todayStart
        nav.push(Route.ItemEdit(l.id, null))
    }
    val left = tasksOn(l.items, todayStart).count { !it.doneOn(todayStart) }
    val sub = when {
        l.items.isEmpty() -> ""
        view == 1 -> "${l.items.size} ${if (l.items.size == 1) "task" else "tasks"}"
        day == todayStart -> if (left == 0) "All clear today" else "$left left today"
        else -> dayWord(day, now)
    }

    Box(Modifier.fillMaxSize()) {
        Screen {
            Header2(
                l.name, sub, onBack = { nav.pop() },
                right = {
                    if (l.items.isNotEmpty()) CircleBtn(if (view == 0) Ic.List else Ic.CalendarEvent, if (view == 0) "List view" else "Day view") { view = 1 - view }
                    CircleBtn(Ic.Dots, "${o.list} options") {
                        vm.sheet = SheetData(
                            l.name,
                            listOf(
                                Act("Add task") { add() },
                                Act(if (l.pinned) "Unpin" else "Pin to top") { vm.togglePin(l.id) },
                                Act("Rename") { vm.rename = l },
                                Act("Delete ${o.listLower}", danger = true) { vm.deleteList(l); nav.pop() },
                            ),
                        )
                    }
                },
            )
            if (l.items.isEmpty()) {
                EmptyBlock("No tasks yet", "Add what you need to do and see your day as a timeline.", "Add a task") { add() }
            } else if (view == 0) {
                DayView(vm, l, day, now) { day = it }
            } else {
                ListView(vm, l, now)
            }
        }
        MenuFab(vm, onAdd = add, onAddHold = add, addLabel = "New task")
    }
}

@Composable
private fun ColumnScope.DayView(vm: BinderViewModel, l: BinderList, day: Long, now: Long, onPick: (Long) -> Unit) {
    val todayStart = startOfDay(now)
    val first = remember { Calendar.getInstance().firstDayOfWeek }
    val weekStart = startOfDay(day, -rowInWeek(epochDay(day), first))
    val days = (0..6).map { startOfDay(weekStart, it) }
    val dayTasks = tasksOn(l.items, day)
    val frac = if (dayTasks.isEmpty()) 0f else dayTasks.count { it.doneOn(day) }.toFloat() / dayTasks.size
    var drag by remember { mutableStateOf(0f) }

    // week strip: tap a day, or swipe it to change week
    Row(
        Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(Radius.lg)).background(P.surface)
            .pointerInput(day) {
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag > 80f) onPick(startOfDay(day, -7)) else if (drag < -80f) onPick(startOfDay(day, 7)) },
                ) { c, dx -> c.consume(); drag += dx }
            }.padding(start = 6.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(Modifier.weight(1f)) {
            days.forEach { d ->
                val sel = d == day
                val has = tasksOn(l.items, d).isNotEmpty()
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(Radius.md)).background(if (sel) P.primary else Color.Transparent)
                        .clickable { onPick(d) }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Txt(fd("EEE", d).take(1), 11, if (sel) P.onPrimary else P.mute)
                    Txt(fd("d", d), 16, if (sel) P.onPrimary else if (d == todayStart) Coral else P.fg, Modifier.padding(top = 2.dp), weight = FontWeight.Medium)
                    Box(Modifier.padding(top = 4.dp).size(4.dp).clip(CircleShape).background(if (has) (if (sel) P.onPrimary else Coral) else Color.Transparent))
                }
            }
        }
        ProgressRing(frac, 44.dp)
    }

    val timed = dayTasks.filter { it.isTimed }
    val anytime = dayTasks.filter { !it.isTimed }
    if (anytime.isNotEmpty()) {
        Cap("ANYTIME", Modifier.padding(start = 4.dp))
        Column(Modifier.heightIn(max = 168.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            anytime.forEach { t -> key(t.id) { TaskRow(vm, l, t, day, now, false) } }
        }
    }
    if (dayTasks.isEmpty()) {
        Txt("Nothing planned for ${dayWord(day, now).lowercase()}. Tap + to add a task.", 14, P.mute, Modifier.fillMaxWidth().padding(top = 28.dp), align = TextAlign.Center)
        return
    }

    // the timeline
    val startH = minOf(FirstHour, (timed.minOfOrNull { it.minuteOfDay() } ?: FirstHour * 60) / 60)
    val total = (24 - startH) * Pitch
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    LaunchedEffect(day) {
        val focus = if (day == todayStart) minuteNow(now) - 60 else (timed.firstOrNull()?.minuteOfDay() ?: 8 * 60) - 30
        val y = ((focus / 60f - startH) * Pitch).coerceAtLeast(0f)
        scroll.scrollTo(with(density) { y.dp.toPx() }.toInt())
    }
    Box(Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp).verticalScroll(scroll)) {
        BoxWithConstraints(Modifier.fillMaxWidth().height((total + 140).dp)) {
            val pad = 12
            val labelW = 52.dp
            val area = maxWidth - labelW - 2.dp
            for (h in startH until 24) {
                Row(
                    Modifier.offset(y = (pad + (h - startH) * Pitch - 8).dp).fillMaxWidth().height(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Txt(hourLabel(h), 11, P.mute, Modifier.width(44.dp), align = TextAlign.End, maxLines = 1)
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f).height(1.dp).background(P.line))
                }
            }
            if (day == todayStart) {
                val ny = pad + (minuteNow(now) - startH * 60) * Pitch / 60f
                Row(Modifier.offset(y = (ny - 4).dp).fillMaxWidth().height(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(44.dp))
                    Spacer(Modifier.width(4.dp))
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Coral))
                    Box(Modifier.weight(1f).height(2.dp).background(Coral.copy(alpha = 0.6f)))
                }
            }
            layoutSlots(timed).forEach { s ->
                val y = pad + (s.start - startH * 60) * Pitch / 60f
                val h = maxOf((s.end - s.start) * Pitch / 60f, 36f)
                val laneW = area / s.lanes
                key(s.item.id) {
                    TimelinePill(
                        Modifier.offset(x = labelW + laneW * s.lane, y = y.dp).width(laneW - 4.dp).height((h - 3f).dp),
                        vm, l, s.item, day, tall = h >= 52f,
                    )
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.ListView(vm: BinderViewModel, l: BinderList, now: Long) {
    var filt by rememberSaveable { mutableStateOf(0) }
    val today = startOfDay(now)
    val g = groupTasks(l.items, now)
    Chips(listOf("All · ${l.items.size}", "Today · ${g.today.size}", "Later · ${g.later.size}", "Done · ${g.done.size}"), filt) { filt = it }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 110.dp)) {
        if (filt == 0) TaskSection("OVERDUE", g.overdue, vm, l, today, now)
        if (filt <= 1) TaskSection("TODAY", g.today, vm, l, today, now)
        if (filt == 0 || filt == 2) TaskSection("LATER", g.later, vm, l, today, now)
        if (filt == 0 || filt == 3) TaskSection("DONE", g.done, vm, l, today, now)
        val shown = when (filt) { 0 -> l.items.size; 1 -> g.today.size; 2 -> g.later.size; else -> g.done.size }
        if (shown == 0) Txt("Nothing here", 14, P.mute, Modifier.fillMaxWidth().padding(top = 28.dp), align = TextAlign.Center)
        else Txt("Swipe left on a task to delete it", 12, P.mute, Modifier.fillMaxWidth().padding(top = 12.dp), align = TextAlign.Center)
    }
}

@Composable
private fun TaskSection(title: String, list: List<Item>, vm: BinderViewModel, l: BinderList, today: Long, now: Long) {
    if (list.isEmpty()) return
    Cap(title, Modifier.padding(start = 4.dp))
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { t ->
            key(t.id) {
                SwipeRow(true, "Edit", "Delete", onRight = { vm.nav.push(Route.ItemEdit(l.id, t.id)) }, onLeft = { vm.deleteItem(l.id, t) }) {
                    TaskRow(vm, l, t, today, now, true)
                }
            }
        }
    }
}

// ───────── new / edit task ─────────

private val Lengths = listOf(15, 30, 45, 60, 90, 120)
private val LengthLabels = listOf("15 min", "30 min", "45 min", "1 h", "1.5 h", "2 h")

@Composable
fun TaskEditScreen(vm: BinderViewModel, listId: String, itemId: String?) {
    val nav = vm.nav
    val ctx = LocalContext.current
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.items?.firstOrNull { it.id == itemId }
    val today = startOfDay(System.currentTimeMillis())
    var title by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var note by rememberSaveable { mutableStateOf(existing?.note ?: "") }
    var dayMs by rememberSaveable {
        mutableStateOf(if (existing != null) (if (existing.due == 0L) 0L else startOfDay(existing.due)) else (TasksState.newDay.takeIf { it != 0L } ?: today))
    }
    var minute by rememberSaveable { mutableStateOf(if (existing != null && existing.isTimed) existing.minuteOfDay() else -1) }
    var len by rememberSaveable { mutableStateOf(existing?.minutes() ?: DefaultMinutes) }
    var rep by rememberSaveable { mutableStateOf(existing?.repeatKind?.ordinal ?: 0) }
    var high by rememberSaveable { mutableStateOf(existing?.isHigh ?: false) }
    var tried by rememberSaveable { mutableStateOf(false) }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val pickDate = {
        val c = Calendar.getInstance().apply { if (dayMs != 0L) timeInMillis = dayMs }
        DatePickerDialog(
            ctx,
            { _, y, m, d -> dayMs = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis },
            c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH),
        ).show()
    }
    val pickTime = {
        TimePickerDialog(
            ctx, { _, h, m -> minute = maxOf(1, h * 60 + m) },
            if (minute >= 0) minute / 60 else 9, if (minute >= 0) minute % 60 else 0, DateFormat.is24HourFormat(ctx),
        ).show()
    }
    val dateSel = when (dayMs) { 0L -> 3; today -> 0; startOfDay(today, 1) -> 1; else -> 2 }

    Screen {
        Header2(
            if (existing == null) "New task" else "Edit task", l.name, onBack = { nav.pop() },
            right = { if (existing != null) CircleBtn(Ic.Close, "Delete task") { vm.deleteItem(l.id, existing); nav.pop() } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Cap("TASK", Modifier.padding(start = 4.dp))
            Field("What needs doing?", title) { title = it; tried = false }
            if (tried && title.isBlank()) Txt("Give the task a name first", 12, Coral, Modifier.padding(start = 4.dp, top = 6.dp))
            Cap("DAY", Modifier.padding(start = 4.dp))
            FlowChips(
                if (dayMs != 0L && dateSel == 2) listOf("Today", "Tomorrow", fd("EEE, MMM d", dayMs), "No date") else listOf("Today", "Tomorrow", "Pick a day", "No date"),
                dateSel,
            ) { i ->
                when (i) {
                    0 -> dayMs = today
                    1 -> dayMs = startOfDay(today, 1)
                    2 -> pickDate()
                    else -> { dayMs = 0L; minute = -1; rep = 0 }
                }
            }
            if (dayMs != 0L) {
                Cap("TIME", Modifier.padding(start = 4.dp))
                FlowChips(listOf("Anytime", if (minute >= 0) clock(minute) else "Set a time"), if (minute < 0) 0 else 1) { i ->
                    if (i == 0) minute = -1 else pickTime()
                }
                if (minute >= 0) {
                    Cap("LENGTH", Modifier.padding(start = 4.dp))
                    FlowChips(LengthLabels, Lengths.indexOf(len)) { len = Lengths[it] }
                }
                Cap("REPEAT", Modifier.padding(start = 4.dp))
                FlowChips(Repeat.entries.map { it.label }, rep) { rep = it }
            }
            Cap("PRIORITY", Modifier.padding(start = 4.dp))
            FlowChips(listOf("Normal", "High"), if (high) 1 else 0) { high = it == 1 }
            Cap("NOTE", Modifier.padding(start = 4.dp))
            Field("Optional", note, singleLine = false) { note = it }
            Spacer(Modifier.height(16.dp))
        }
        BigButton(if (existing == null) "Add task" else "Save task", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            if (title.isBlank()) {
                tried = true
            } else {
                val due = if (dayMs == 0L) 0L else if (minute < 0) dayMs else atMinute(dayMs, minute)
                val kind = if (dayMs == 0L) Repeat.NEVER else Repeat.entries[rep]
                val base = existing ?: Item(title = "")
                val changed = existing != null && existing.repeatKind != kind
                vm.saveItem(
                    l.id,
                    base.copy(
                        title = title.trim(), note = note.trim(), due = due, sub = kind.key,
                        extra = if (due != 0L && minute >= 0) len.toString() else "", rating = if (high) 1f else 0f,
                        stage = if (changed) 0 else base.stage, marks = if (changed) emptyMap() else base.marks,
                    ),
                )
                nav.pop()
            }
        }
    }
}
