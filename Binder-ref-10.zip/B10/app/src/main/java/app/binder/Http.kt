package app.binder

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Something went wrong talking to a source. The message is safe to show in the sheet. */
class FetchFailure(message: String, val offline: Boolean = false) : Exception(message)

/** A tiny HTTP helper: GET only, timeouts, a User-Agent, size limit. Always call it off the main thread. */
object Http {
    const val USER_AGENT = "Binder/1.0.0 (Android; personal list app)"

    fun getBytes(url: String, maxBytes: Int = 8_000_000): ByteArray = request("GET", url, null, emptyMap(), maxBytes)

    /** Like [get], with extra request headers (an Authorization header, for instance). */
    fun getWith(url: String, headers: Map<String, String>): String =
        String(request("GET", url, null, headers, 8_000_000), Charsets.UTF_8)

    /** POSTs [json] and returns the answer as text. Same timeouts, size limit and messages as [get]. */
    fun postJson(url: String, json: String, headers: Map<String, String> = emptyMap(), maxBytes: Int = 8_000_000): String =
        String(request("POST", url, json.toByteArray(Charsets.UTF_8), headers + ("Content-Type" to "application/json"), maxBytes), Charsets.UTF_8)

    /**
     * POSTs a multipart form with text [fields] and one file (a WAV clip, for song recognition) and returns the answer as text.
     * Same timeouts, size limit and messages as the other calls.
     */
    fun postMultipart(
        url: String, fields: Map<String, String>, fileField: String, fileName: String, file: ByteArray,
        mime: String = "audio/wav", maxBytes: Int = 1_000_000,
    ): String {
        val boundary = "----binder" + java.util.UUID.randomUUID().toString().replace("-", "")
        val out = ByteArrayOutputStream()
        fun text(s: String) = out.write(s.toByteArray(Charsets.UTF_8))
        for ((k, v) in fields) text("--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n")
        text("--$boundary\r\nContent-Disposition: form-data; name=\"$fileField\"; filename=\"$fileName\"\r\nContent-Type: $mime\r\n\r\n")
        out.write(file)
        text("\r\n--$boundary--\r\n")
        val headers = mapOf("Content-Type" to "multipart/form-data; boundary=$boundary")
        return String(request("POST", url, out.toByteArray(), headers, maxBytes), Charsets.UTF_8)
    }

    private fun request(method: String, url: String, body: ByteArray?, headers: Map<String, String>, maxBytes: Int): ByteArray {
        val c = try {
            URL(url).openConnection() as HttpURLConnection
        } catch (e: Exception) {
            throw FetchFailure("That link doesn't look right.")
        }
        val host = c.url.host.removePrefix("www.")
        c.connectTimeout = 8_000
        c.readTimeout = 10_000
        c.requestMethod = method
        c.setRequestProperty("User-Agent", USER_AGENT)
        c.setRequestProperty("Accept", "*/*")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        try {
            if (body != null) {
                c.doOutput = true
                c.setFixedLengthStreamingMode(body.size)
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            if (code == 429) throw FetchFailure("$host is busy. Try again in a minute.")
            if (code == 403) throw FetchFailure("$host refused the request (403). It may be busy or blocking this connection. Try again in a minute.")
            if (code == 401) throw FetchFailure("$host rejected the API key (401). Check the key in this build.")
            if (code == 404) throw FetchFailure("$host has no answer for that (404).")
            if (code !in 200..299) throw FetchFailure("$host answered with error $code.")
            val out = ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(8192)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > maxBytes) throw FetchFailure("The answer was too big.")
                }
            }
            return out.toByteArray()
        } catch (e: FetchFailure) {
            throw e
        } catch (e: javax.net.ssl.SSLException) {
            // this one host's secure connection failed (certificate, blocked or intercepted): not "offline", so a backup source may still answer
            throw FetchFailure("Couldn't make a secure connection to $host.")
        } catch (e: java.net.SocketTimeoutException) {
            throw FetchFailure("$host took too long to answer.", offline = true)
        } catch (e: java.io.IOException) {
            // no connection, DNS problem …
            throw FetchFailure("Couldn't reach $host. Check your connection.", offline = true)
        } finally {
            c.disconnect()
        }
    }

    fun get(url: String): String = String(getBytes(url), Charsets.UTF_8)
}

/** Keeps us under a source's request limit: at most [max] calls in any [windowMs]. */
class RateGate(private val max: Int, private val windowMs: Long, private val now: () -> Long = System::currentTimeMillis) {
    private val times = ArrayDeque<Long>()

    @Synchronized
    fun check() {
        val t = now()
        while (times.isNotEmpty() && t - times.first() >= windowMs) times.removeFirst()
        if (times.size >= max) throw FetchFailure("Too many searches in a row. Wait a moment and try again.")
        times.addLast(t)
    }
}
