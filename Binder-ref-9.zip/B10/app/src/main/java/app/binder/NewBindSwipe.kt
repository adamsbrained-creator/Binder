package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import kotlin.math.absoluteValue
import kotlinx.coroutines.launch

// The "Swipe cards" way to make a new bind: one big card for each template that you swipe through, with its neighbours peeking in
// at the sides. The card in the middle is the template, and it wears the colour and icon you choose. Picked in Settings > New bind.

/** The order of the cards: the same as the other pages, group by group. */
val SwipeOrder: List<Kind> = KindGroups.flatMap { it.second }

/** One line on a card saying what the template is for. */
val Kind.blurb: String
    get() = when (this) {
        Kind.BOOKS -> "Everything you read"
        Kind.MANGA -> "Volumes and series you follow"
        Kind.COMICS -> "Issues, runs and graphic novels"
        Kind.MOVIES -> "Films you want to see or have seen"
        Kind.SERIES -> "Shows, seasons and where you are"
        Kind.ALBUMS -> "Records to hear and records you love"
        Kind.GAMES -> "Your backlog and what you have played"
        Kind.PLACES -> "Cities and spots to visit"
        Kind.HEARD -> "Names songs by listening"
        Kind.CHECKLIST -> "Things to do, ticked off"
        Kind.TRACKER -> "Log how you feel, day by day"
        Kind.TIME -> "Time as dots: the year so far and your countdowns"
        Kind.HABITS -> "Small things you do every day"
        Kind.PRODUCTIVITY -> "A daily log of work and mood"
        Kind.TASKS -> "Your day as a timeline of tasks"
        Kind.ANYTHING -> "A bind for whatever you like"
    }

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SwipeCard(kd: Kind, tint: Int, face: String, modifier: Modifier) {
    val dark = P.bg == DarkPal.bg
    val chip = if (dark) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.7f)
    val soft = softInk(tint)
    Column(
        modifier.fillMaxSize().clip(RoundedCornerShape(Radius.xl)).background(Tints.getOrNull(tint)?.color() ?: P.surface).padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Txt(face, 84)
        Column {
            Txt(kd.label, 30, weight = FontWeight.Medium, maxLines = 1)
            Txt(kd.blurb, 15, soft, Modifier.padding(top = 4.dp, bottom = 12.dp), maxLines = 2)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                previewFields(kd).forEach { f ->
                    Box(Modifier.clip(RoundedCornerShape(Radius.sm)).background(chip).padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Txt(f, 13, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun NewListSwipe(vm: BinderViewModel) {
    val o = vm.opts
    var name by rememberSaveable { mutableStateOf("") }
    var tintPick by rememberSaveable { mutableStateOf<Int?>(null) }   // null = not touched: the template's own colour
    var emoji by rememberSaveable { mutableStateOf("") }              // "" = the template's emoji on the card, the usual mark on Home
    var custom by rememberSaveable { mutableStateOf("") }
    val start = remember { SwipeOrder.indexOf(vm.newListKind ?: SwipeOrder[0]).coerceAtLeast(0) }
    LaunchedEffect(Unit) { vm.newListKind = null }
    val pager = rememberPagerState(initialPage = start) { SwipeOrder.size }
    val scope = rememberCoroutineScope()
    val kind = SwipeOrder[pager.currentPage]
    val tint = tintPick ?: kind.defaultTint
    val shown = name.trim().ifBlank { kind.label }
    val screenW = LocalConfiguration.current.screenWidthDp - 32     // the page has 16 dp on each side
    val cardW = (screenW * 0.76f).dp

    Screen {
        Header2("New ${o.listLower}", onBack = { vm.nav.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            HorizontalPager(
                pager,
                Modifier.fillMaxWidth().padding(top = 6.dp).height(340.dp),
                contentPadding = PaddingValues(horizontal = ((screenW.dp - cardW) / 2)),
                pageSize = PageSize.Fixed(cardW),
                pageSpacing = 14.dp,
            ) { page ->
                val kd = SwipeOrder[page]
                val far = ((pager.currentPage - page) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                val on = page == pager.currentPage
                SwipeCard(
                    kd, if (on) tint else kd.defaultTint, if (on) emoji.ifEmpty { kd.emoji } else kd.emoji,
                    Modifier.graphicsLayer {
                        val s = lerp(1f, 0.92f, far)
                        scaleX = s; scaleY = s; alpha = lerp(1f, 0.6f, far)
                    }.clickable { if (!on) scope.launch { pager.animateScrollToPage(page) } },
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                SwipeOrder.indices.forEach { i ->
                    val on = i == pager.currentPage
                    Box(Modifier.height(8.dp).width(if (on) 24.dp else 8.dp).clip(CircleShape).background(if (on) P.fg else P.line))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
                Txt("Swipe to browse · ${pager.currentPage + 1} of ${SwipeOrder.size}", 13, P.mute)
            }
            Field("${o.list} name", name, Modifier.padding(top = 16.dp)) { name = it }
            KindHas(kind)
            LookPicker(
                name = shown, emoji = emoji, tint = tint, custom = custom,
                onEmoji = { emoji = it; custom = "" },
                onTint = { tintPick = it },
                onCustom = { custom = firstEmoji(it); emoji = custom },
                showPreview = false,
            )
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Create ${o.listLower}", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val id = vm.addList(shown, kind, emoji, tint)
            vm.nav.replaceTop(Route.Lst(id))
        }
    }
}
