package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Groups: folders inside a bind (for example "The Beatles" inside Music Albums).

/** "14 albums" / "1 album" for a group. */
private fun BinderList.countIn(n: Int): String = "$n ${if (n == 1) kind.single else kind.noun}"

/** What the "Group…" sheet offers for these items: a new group, an existing group, or back to the main list. */
fun groupActs(vm: BinderViewModel, l: BinderList, ids: Set<String>, then: () -> Unit = {}): List<Act> = buildList {
    add(Act("New group…") { vm.groupDialog = GroupEdit(l.id, null, l.commonSub(ids), ids) })
    l.groups.forEach { g -> add(Act(g.name) { vm.moveToGroup(l.id, ids, g.id); then() }) }
    if (l.items.any { it.id in ids && l.groupIdOf(it).isNotEmpty() }) {
        add(Act("Back to the main list") { vm.moveToGroup(l.id, ids, ""); then() })
    }
}

/** The picture of a group: up to four of its covers in a 2 × 2 grid, or a folder when it is empty. */
@Composable
fun FolderCollage(items: List<Item>, square: Boolean, modifier: Modifier = Modifier, px: Int = 200, radius: Dp = 12.dp) {
    val shape = RoundedCornerShape(radius)
    Box(modifier.aspectRatio(if (square) 1f else 2f / 3f).clip(shape).background(P.surface).border(1.dp, P.line, shape).padding(6.dp)) {
        if (items.isEmpty()) {
            Icon(Ic.Folder, null, tint = P.mute, modifier = Modifier.align(Alignment.Center).size(28.dp))
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (r in 0..1) {
                    Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (c in 0..1) {
                            val a = items.getOrNull(r * 2 + c)
                            Box(
                                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                                    .background(if (a == null) Color.Transparent else P.line)
                            ) {
                                if (a != null) ArtBox(a.art(), Modifier.fillMaxSize(), 6.dp, px)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** A group in the cover grid: its collage, name and how many are inside. */
@Composable
fun FolderTile(l: BinderList, g: Group, px: Int, open: () -> Unit, hold: () -> Unit) {
    val inside = l.itemsIn(g.id)
    Column(Modifier.tapHold(open, hold)) {
        FolderCollage(inside.take(4), l.kind.square, Modifier.fillMaxWidth(), px)
        Txt(g.name, 13, modifier = Modifier.padding(top = 6.dp), weight = FontWeight.Medium, maxLines = 2, lh = 15.sp)
        Txt(l.countIn(inside.size), 12, P.mute, maxLines = 1)
    }
}

/** A group in the Cards layout. */
@Composable
fun FolderCard(l: BinderList, g: Group, open: () -> Unit, hold: () -> Unit) {
    val inside = l.itemsIn(g.id)
    Column(Modifier.clip(RoundedCornerShape(Radius.lg)).background(P.surface).tapHold(open, hold).padding(10.dp)) {
        FolderCollage(inside.take(4), l.kind.square, Modifier.fillMaxWidth(), 400)
        Txt(g.name, 15, weight = FontWeight.Medium, modifier = Modifier.padding(top = 10.dp), maxLines = 2)
        Txt(l.countIn(inside.size), 12, P.mute, maxLines = 1)
    }
}

/** A group in the row layouts (List, Sections, Shelf, Carousel, Timeline). */
@Composable
fun FolderRow(l: BinderList, g: Group, open: () -> Unit, hold: () -> Unit) {
    val inside = l.itemsIn(g.id)
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).tapHold(open, hold),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        FolderCollage(inside.take(4), l.kind.square, Modifier.width(56.dp), 120, 10.dp)
        Column(Modifier.weight(1f)) {
            Txt(g.name, 16, weight = FontWeight.Medium, maxLines = 1)
            Txt(l.countIn(inside.size), 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
        }
    }
}

/** Puts the groups above a layout that has no place of its own for them (Carousel, Timeline). */
@Composable
fun WithFolders(l: BinderList, folders: List<Group>, open: (Group) -> Unit, hold: (Group) -> Unit, content: @Composable () -> Unit) {
    if (folders.isEmpty()) {
        content()
    } else {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                folders.forEach { g -> FolderRow(l, g, { open(g) }, { hold(g) }) }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) { content() }
        }
    }
}
