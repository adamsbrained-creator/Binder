package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// The "Popular + list" way to make a new bind: a row of the templates you reach for most, then every template as a row with
// a coloured emoji and a radio. Picked in Settings > New bind (Opts.newBind). Does the same job as the Grid, including the look.

/** The four templates for the Popular row: the kinds of the binds you already have, most used first, then the usual favourites. */
fun popularKinds(lists: List<BinderList>): List<Kind> {
    val favourites = listOf(Kind.BOOKS, Kind.MOVIES, Kind.GAMES, Kind.CHECKLIST)
    val used = lists.groupingBy { it.kind }.eachCount().entries
        .sortedWith(compareByDescending<Map.Entry<Kind, Int>> { it.value }.thenBy { it.key.ordinal })
        .map { it.key }
    return (used + favourites).distinct().take(4)
}

/** A big square card in the Popular row. The picked one shows the look you have chosen. */
@Composable
private fun PopularCard(kd: Kind, selected: Boolean, tint: Int, face: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(Radius.xl)
    Box(
        Modifier.size(136.dp).clip(shape).background(Tints.getOrNull(tint)?.color() ?: P.surface)
            .border(3.dp, if (selected) Coral else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(14.dp)
    ) {
        Txt(face, 40, modifier = Modifier.align(Alignment.TopStart))
        Txt(kd.label, 16, weight = FontWeight.Medium, maxLines = 1, modifier = Modifier.align(Alignment.BottomStart))
    }
}

/** One template in the list: a coloured emoji square, its name and what it keeps, and a radio. */
@Composable
private fun TemplateRow(kd: Kind, selected: Boolean, tint: Int, face: String, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(Radius.sm)).background(Tints.getOrNull(tint)?.color() ?: P.surface),
                contentAlignment = Alignment.Center,
            ) { Txt(face, 24) }
            Column(Modifier.weight(1f)) {
                Txt(kd.label, 16, weight = if (selected) FontWeight.Medium else FontWeight.Normal, maxLines = 1)
                Txt(kd.hint, 13, P.mute, maxLines = 1)
            }
            Box(
                Modifier.size(24.dp).border(if (selected) 7.dp else 2.dp, if (selected) Coral else P.mute, CircleShape)
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(P.line))
    }
}

@Composable
fun NewListPopular(vm: BinderViewModel) {
    val o = vm.opts
    var name by rememberSaveable { mutableStateOf("") }
    var k by rememberSaveable { mutableStateOf(vm.newListKind?.ordinal ?: 0) }
    var tintPick by rememberSaveable { mutableStateOf<Int?>(null) }   // null = not touched: the template's own colour
    var emoji by rememberSaveable { mutableStateOf("") }              // "" = the bind's usual mark
    var custom by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.newListKind = null }
    val kind = Kind.entries[k]
    val tint = tintPick ?: kind.defaultTint
    val popular = popularKinds(vm.lists)

    Screen {
        Header2("New ${o.listLower}", onBack = { vm.nav.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Field("${o.list} name", name, Modifier.padding(top = 6.dp)) { name = it }
            Cap(if (vm.lists.isEmpty()) "POPULAR" else "MOST USED")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                popular.forEach { kd ->
                    val on = kd == kind
                    PopularCard(kd, on, if (on) tint else kd.defaultTint, if (on) emoji.ifEmpty { kd.emoji } else kd.emoji) { k = kd.ordinal }
                }
            }
            Cap("ALL TEMPLATES")
            KindGroups.flatMap { it.second }.forEach { kd ->
                val on = kd == kind
                TemplateRow(kd, on, if (on) tint else kd.defaultTint, if (on) emoji.ifEmpty { kd.emoji } else kd.emoji) { k = kd.ordinal }
            }
            KindHas(kind)
            LookPicker(
                name = name.trim().ifBlank { kind.label }, emoji = emoji, tint = tint, custom = custom,
                onEmoji = { emoji = it; custom = "" },
                onTint = { tintPick = it },
                onCustom = { custom = firstEmoji(it); emoji = custom },
            )
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Create ${o.listLower}", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val id = vm.addList(name.trim().ifBlank { kind.label }, kind, emoji, tint)
            vm.nav.replaceTop(Route.Lst(id))
        }
    }
}
