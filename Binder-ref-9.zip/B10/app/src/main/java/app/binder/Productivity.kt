package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// A Productivity bind is a normal bind (Kind.PRODUCTIVITY) with its own page: Today / Workflow / All, a "New entry" screen and a project editor.
// A project is a Group of the bind with its own workflow (Group.stages); an entry belongs to a project through Item.group ("" = General).
// Every entry is a plain Item (see Kind.PRODUCTIVITY and ProductivityLogic.kt), so old files and backups need nothing new.

private val MoodColors = listOf(Color(0xFF5CCB8A), Color(0xFF4C9BF0), Color(0xFFF5B83D), Color(0xFF9B8CFF), Color(0xFFF2874E))
private val StreakYellow = Color(0xFFF5B301)
private val CheckInk = DarkInk

private fun moodColor(i: Int): Color = MoodColors.getOrElse(i) { Color(0xFF9A9A9A) }

/** Which stage is which colour: the last one (done) is green, the others run violet, blue, amber, orange, pink. Dark ink (CheckInk) reads well on every one. */
private val StagePalette = listOf(Color(0xFF9B8CFF), Color(0xFF4C9BF0), Color(0xFFF5B83D), Color(0xFFF2874E), Color(0xFFFF8FB1))
private val DoneColor = Color(0xFF5CCB8A)

private fun stageColor(i: Int, n: Int): Color = if (i >= n - 1) DoneColor else StagePalette[i % StagePalette.size]

private val ProjectColors = listOf(
    Color(0xFF5CCB8A), Color(0xFF4C9BF0), Color(0xFFF5B83D), Color(0xFF9B8CFF), Color(0xFFF2874E), Color(0xFFFF8FB1), Color(0xFF3DD9D3),
)

/** A project keeps one colour for good (it comes from its id); General is grey. */
private fun projectColor(gid: String): Color =
    if (gid.isEmpty()) Color(0xFF9A9A9A) else ProjectColors[(gid.hashCode() and 0x7fffffff) % ProjectColors.size]

/** The project the page was last showing (a project id, "" for General, or ALL_PROJECTS), so New entry starts in it and coming back finds it again. */
object ProductivityState {
    var project by mutableStateOf(ALL_PROJECTS)
}

/** How much room the lists leave at the bottom for the corner button (and, in the glass look, the tabs). */
private val LocalProdBottom = compositionLocalOf { 110.dp }

/** The same colour with its hue turned by [deg] degrees: the far end of the streak card's gradient. */
private fun hueShift(c: Color, deg: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    hsv[0] = (hsv[0] + deg) % 360f
    return Color(android.graphics.Color.HSVToColor(hsv))
}


private fun pfmt(p: String, ms: Long) = SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))

private fun pTime(ms: Long) = pfmt("hh:mm a", ms)

private fun pDayTitle(start: Long, now: Long): String = when (start) {
    startOfDay(now) -> "Today"
    startOfDay(now, -1) -> "Yesterday"
    else -> pfmt("EEE, MMM d", start)
}

/** Three letters of a weekday, from a day number. */
private fun pWeekday(day: Int): String = DateFormatSymbols.getInstance(Locale.getDefault()).shortWeekdays[dowOf(day)].take(3)

private fun Item.pLine(): String = note.ifBlank { sub.ifBlank { "No description" } }

// ───────── small pieces ─────────

/** The square with a mood's emoji on a wash of its colour. */
@Composable
private fun MoodTile(e: Item, size: Int = 40) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size * 0.35f).dp)).background(moodColor(e.moodIndex()).copy(alpha = 0.34f)),
        contentAlignment = Alignment.Center,
    ) { Txt(e.faceEmoji(), (size * 0.55f).toInt()) }
}

/** A small rounded label, like "Doing": a solid colour with dark ink on it, or neutral when [color] is null. */
@Composable
private fun PTag(text: String, color: Color? = null) {
    Box(Modifier.clip(RoundedCornerShape(Radius.sm)).background(color ?: P.line).padding(horizontal = 9.dp, vertical = 4.dp)) {
        Txt(text, 12, if (color != null) CheckInk else P.fg, weight = FontWeight.Medium, maxLines = 1)
    }
}

/** The "Each entry has" part of the New bind page, shown when Productivity is picked. */
@Composable
fun ProductivityHas(note: String) {
    Txt(note, 12, P.mute, Modifier.padding(start = 4.dp, top = 10.dp))
    Cap("EACH ENTRY HAS")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
            Triple("🎯", "A mood", "5 moods"), Triple("✍️", "A description", "what you did"),
            Triple("📁", "A project", "its own workflow"), Triple("🔁", "A workflow stage", "Plan to Done"),
        ).forEach { (icon, title, value) ->
            Row(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(Radius.lg)).background(P.surface).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { Txt(icon, 20) }
                Txt(title, 16, modifier = Modifier.weight(1f))
                Txt(value, 14, P.mute)
            }
        }
    }
}

// ───────── the bind page ─────────

@Composable
fun ProductivityScreen(vm: BinderViewModel, id: String) {
    val nav = vm.nav
    val o = vm.opts
    val dark = P === DarkPal
    val g = remember(o.prodLook, o.prodBg, dark) { if (o.prodLook == ProdLook.GLASS) GlassLook(glassBgAt(o.prodBg), dark) else null }
    var tab by rememberSaveable { mutableStateOf(0) }
    var q by rememberSaveable { mutableStateOf("") }
    var mood by rememberSaveable { mutableStateOf(-1) }
    var arrange by rememberSaveable { mutableStateOf(false) }    // the cards of the Today tab can be dragged into a new order
    val l = vm.lists.firstOrNull { it.id == id }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    // a project that was deleted (or belongs to another bind) falls back to showing everything
    val sel = ProductivityState.project.let { if (it == ALL_PROJECTS || it == "" || l.groups.any { x -> x.id == it }) it else ALL_PROJECTS }
    val now = System.currentTimeMillis()
    val entries = l.inProject(sel).sortedByDescending { it.added }
    val today = todaysEntries(entries, now)
    val add = { nav.push(Route.ItemEdit(l.id, null)) }
    val newProject = { nav.push(Route.Project(l.id, null)) }
    val pick = { p: String -> ProductivityState.project = p }
    val sub = when {
        entries.isEmpty() -> if (sel == ALL_PROJECTS) "" else l.projectName(sel)
        sel == ALL_PROJECTS -> "${today.size} today"
        else -> "${l.projectName(sel)} · ${today.size} today"
    }

    // the menu behind the three dots (the same for the classic and the glass header)
    val menu = {
        val acts = mutableListOf(Act("Add entry") { add() }, Act("New project") { newProject() })
        if (sel != ALL_PROJECTS && sel != "") {
            acts += Act("Edit project") { nav.push(Route.Project(l.id, sel)) }
            acts += Act("Delete project", danger = true) { vm.deleteProject(l.id, sel); pick(ALL_PROJECTS) }
        }
        acts += Act("Rearrange cards") { tab = 0; arrange = true }
        if (l.blocks.isNotEmpty()) acts += Act("Reset card order") { vm.resetBlocks(l.id) }
        if (g != null) {
            acts += Act("Background: ${g.bg.name}") {
                vm.sheet = SheetData(
                    "Background",
                    GlassBgs.mapIndexed { i, b -> Act(if (b === g.bg) "${b.name} (now)" else b.name) { vm.change { it.copy(prodBg = i) } } },
                )
            }
        }
        acts += Act(if (g != null) "Use the classic look" else "Use the glass look") {
            vm.change { it.copy(prodLook = if (g != null) ProdLook.CLASSIC else ProdLook.GLASS) }
        }
        acts += Act(if (l.pinned) "Unpin" else "Pin to top") { vm.togglePin(l.id) }
        acts += Act("Rename") { vm.rename = l }
        acts += Act("Customize look") { vm.lookFor = l.id }
        acts += Act("Delete ${o.listLower}", danger = true) { vm.deleteList(l); nav.pop() }
        vm.sheet = SheetData(l.name, acts)
    }
    val tabs = listOf("Today", "Workflow", "All")
    val liftDock = o.addButton == AddButton.LABEL    // the labelled + pill is wide, so the glass tabs ride a row above it

    CompositionLocalProvider(LocalGlass provides g, LocalProdBottom provides (if (g != null && liftDock) 184.dp else 110.dp)) {
        Box(Modifier.fillMaxSize()) {
            if (g != null) GlassBackdrop(g.bg, g.dark)
            Screen {
                if (g == null) {
                    Header2(l.name, sub, onBack = { nav.pop() }, right = { CircleBtn(Ic.Dots, "${o.list} options") { menu() } })
                } else {
                    GlassHeader(g, l.name, onBack = { nav.pop() }) { GlassCircle(g, Ic.Dots, "${o.list} options") { menu() } }
                }
                ProjectBar(l, sel, pick, newProject)
                if (g == null) Seg(tabs, tab, Modifier.padding(top = 6.dp)) { tab = it; arrange = false }
                when (tab) {
                    0 -> TodayTab(vm, l, sel, sub, entries, today, now, add, arrange, { arrange = it }) { tab = 2 }
                    1 -> WorkflowTab(vm, l, sel, entries, add, pick, newProject)
                    else -> AllTab(vm, l, entries, now, q, mood, add, { q = it }) { mood = it }
                }
            }
            if (g != null) {
                GlassDock(g, tabs, tab, endPad = if (liftDock) 16.dp else 84.dp, lift = if (liftDock) 72.dp else 0.dp) { tab = it; arrange = false }
            }
            MenuFab(vm, onAdd = add, onAddHold = add, addLabel = "New entry")
        }
    }
}

/** A pill for a project (or All / General): filled with the project's colour when chosen. */
@Composable
private fun ProjChip(label: String, color: Color?, on: Boolean, onClick: () -> Unit) {
    val g = LocalGlass.current
    Row(
        Modifier.height(40.dp).clip(CircleShape).background(if (on) (color ?: P.primary) else (g?.fill() ?: P.surface))
            .then(if (g != null && !on) Modifier.border(1.dp, g.edge(), CircleShape) else Modifier)
            .clickable(onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (color != null && !on) Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Txt(label, 14, if (on) (if (color != null) CheckInk else P.onPrimary) else P.fg, weight = if (on) FontWeight.Medium else FontWeight.Normal, maxLines = 1)
    }
}

/** All, then each project, then General (when there are projects), then "+ Project". */
@Composable
private fun ProjectBar(l: BinderList, sel: String, onSelect: (String) -> Unit, onNew: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 10.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        ProjChip("All", null, sel == ALL_PROJECTS) { onSelect(ALL_PROJECTS) }
        l.groups.forEach { g -> ProjChip(g.name.ifBlank { "Project" }, projectColor(g.id), sel == g.id) { onSelect(g.id) } }
        if (l.groups.isNotEmpty()) ProjChip("General", projectColor(""), sel == "") { onSelect("") }
        ProjChip("+ Project", null, false) { onNew() }
    }
}

private fun entryMenu(vm: BinderViewModel, l: BinderList, e: Item): SheetData {
    val flow = l.flowFor(e)
    val next = nextStageIn(flow, e.stage)
    return SheetData(
        e.title.ifBlank { "Entry" },
        listOf(
            Act("Edit") { vm.nav.push(Route.ItemEdit(l.id, e.id)) },
            Act("Move to ${flow[next]}") { vm.saveItem(l.id, e.copy(stage = next)) },
            Act("Delete", danger = true) { vm.deleteItem(l.id, e) },
        ),
    )
}

// ───────── Today ─────────

@Composable
private fun WeekStrip(days: Set<Int>, today: Int) {
    val first = remember { Calendar.getInstance().firstDayOfWeek }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        weekOf(today, first).forEach { d ->
            val st = dayState(d, today, days)
            val isToday = d == today
            val shape = RoundedCornerShape(Radius.md)
            Column(
                Modifier.weight(1f).height(66.dp).pSurface(shape)
                    .background(if (isToday) Coral.copy(alpha = 0.22f) else if (st == DayState.DONE) StreakYellow.copy(alpha = 0.18f) else Color.Transparent)
                    .border(2.dp, if (isToday) Coral else Color.Transparent, shape),
                verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Txt(pWeekday(d), 12, if (isToday) P.fg else P.mute, maxLines = 1, weight = if (isToday) FontWeight.Medium else FontWeight.Normal)
                val dot = Modifier.size(26.dp).clip(CircleShape)
                when (st) {
                    DayState.DONE -> Box(dot.background(StreakYellow), contentAlignment = Alignment.Center) {
                        Icon(Ic.Check, "Logged", tint = CheckInk, modifier = Modifier.size(15.dp))
                    }
                    DayState.TODAY -> Box(dot.border(2.dp, Coral, CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Coral))
                    }
                    DayState.MISSED -> Box(dot.background(P.line), contentAlignment = Alignment.Center) { Txt("–", 14, P.mute) }
                    DayState.UPCOMING -> Box(dot.border(2.dp, P.mute.copy(alpha = 0.45f), CircleShape))
                }
            }
        }
    }
}

@Composable
private fun StreakCard(streak: Int, best: Int) {
    val (title, line) = streakText(streak)
    val frac = streakFraction(streak, best)
    val ink = CheckInk
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(Radius.xl))
            .background(Brush.linearGradient(listOf(Coral, hueShift(Coral, 32f)))),
    ) {
        Row(
            Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = 9.dp.toPx()
                    val box = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w)
                    val tl = androidx.compose.ui.geometry.Offset(w / 2f, w / 2f)
                    drawArc(ink.copy(alpha = 0.16f), 0f, 360f, false, tl, box, style = Stroke(w))
                    if (frac > 0f) drawArc(ink, -90f, 360f * frac, false, tl, box, style = Stroke(w, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Txt("$streak", 32, ink, weight = FontWeight.Medium)
                    Txt(if (streak == 1) "Day" else "Days", 12, ink.copy(alpha = 0.7f))
                }
                if (streak > 0) Txt("🔥", 20, modifier = Modifier.align(Alignment.BottomCenter).offset(y = 6.dp))
            }
            Column(Modifier.weight(1f)) {
                Txt(title, 18, ink, weight = FontWeight.Bold, maxLines = 2)
                Txt(line, 13, ink.copy(alpha = 0.78f), Modifier.padding(top = 4.dp), maxLines = 3)
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.clip(RoundedCornerShape(Radius.sm)).background(ink.copy(alpha = 0.14f)).padding(horizontal = 9.dp, vertical = 4.dp)) {
                        Txt("Longest streak", 12, ink, weight = FontWeight.Medium, maxLines = 1)
                    }
                    Box(Modifier.clip(RoundedCornerShape(Radius.sm)).background(ink).padding(horizontal = 9.dp, vertical = 4.dp)) {
                        Txt("$best ${if (best == 1) "day" else "days"}", 12, Color.White, weight = FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.TodayTab(
    vm: BinderViewModel, l: BinderList, sel: String, sub: String, entries: List<Item>, today: List<Item>, now: Long,
    add: () -> Unit, arrange: Boolean, onArrange: (Boolean) -> Unit, viewAll: () -> Unit,
) {
    if (arrange) {
        ArrangeBlocks(vm, l, entries, today, now) { onArrange(false) }
        return
    }
    val g = LocalGlass.current
    val days = loggedDays(entries)
    val day = epochDay(now)
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = LocalProdBottom.current), verticalArrangement = Arrangement.spacedBy(24.dp)) {
        Spacer(Modifier.height(6.dp))
        if (g != null) GlassHeadline(sub)
        // the cards come in the order saved on the bind; holding the week or the streak card starts rearranging them
        todayOrder(l.blocks, g != null).forEach { code ->
            when (code) {
                BLOCK_WEEK -> Box(Modifier.tapHold({}, { onArrange(true) })) { if (g != null) GlassWeek(days, day) else WeekStrip(days, day) }
                BLOCK_STREAK -> Box(Modifier.tapHold({}, { onArrange(true) })) {
                    if (g != null) GlassStreakCard(entryStreak(days, day), bestEntryStreak(days)) else StreakCard(entryStreak(days, day), bestEntryStreak(days))
                }
                else -> if (g != null) GlassEntries(g, vm, l, sel, entries, today, now, add, viewAll) else EntriesBlock(vm, l, sel, today, add, viewAll)
            }
        }
    }
}

// ───────── glass look: the Today tab as frosted cards ─────────

/** The headline: a soft first line over a sharp second one. The blur needs Android 12; older phones just show it faded. */
@Composable
private fun GlassHeadline(sub: String) {
    Column(Modifier.padding(start = 4.dp)) {
        Txt(
            "Your day,", 40, P.fg.copy(alpha = 0.45f), Modifier.blur(3.dp, BlurredEdgeTreatment.Unbounded),
            font = TitleFont, weight = FontWeight.Medium, maxLines = 1, lh = 44.sp, ls = (-0.03).em,
        )
        Txt("in focus.", 40, P.fg, font = TitleFont, weight = FontWeight.Medium, maxLines = 1, lh = 44.sp, ls = (-0.03).em)
        if (sub.isNotEmpty()) Txt(sub, 14, P.mute, Modifier.padding(top = 8.dp), maxLines = 1)
    }
}

/** A small quiet label on a glass card, like "Calm". */
@Composable
private fun GlassTag(text: String) {
    Box(Modifier.clip(RoundedCornerShape(Radius.sm)).background(P.fg.copy(alpha = 0.08f)).padding(horizontal = 9.dp, vertical = 4.dp)) {
        Txt(text, 12, P.fg, weight = FontWeight.Medium, maxLines = 1)
    }
}

/** The week as one glass card: a day name over a dot for each day. */
@Composable
private fun GlassWeek(days: Set<Int>, today: Int) {
    val first = remember { Calendar.getInstance().firstDayOfWeek }
    val week = weekOf(today, first)
    val logged = week.count { it in days }
    Column(
        Modifier.fillMaxWidth().pSurface(RoundedCornerShape(Radius.xl)).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Txt("This week", 16, weight = FontWeight.Medium)
            Txt("$logged ${if (logged == 1) "day" else "days"} logged", 13, P.mute)
        }
        Row(Modifier.fillMaxWidth()) {
            week.forEach { d ->
                val st = dayState(d, today, days)
                val isToday = d == today
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Txt(pWeekday(d), 12, if (isToday) P.fg else P.mute, maxLines = 1, weight = if (isToday) FontWeight.Medium else FontWeight.Normal)
                    val dot = Modifier.size(28.dp).clip(CircleShape)
                    when (st) {
                        DayState.DONE -> Box(dot.background(StreakYellow), contentAlignment = Alignment.Center) {
                            Icon(Ic.Check, "Logged", tint = CheckInk, modifier = Modifier.size(16.dp))
                        }
                        DayState.TODAY -> Box(dot.border(2.dp, Coral, CircleShape), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(9.dp).clip(CircleShape).background(Coral))
                        }
                        DayState.MISSED -> Box(dot.background(P.fg.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) { Txt("–", 14, P.mute) }
                        DayState.UPCOMING -> Box(dot.border(2.dp, P.mute.copy(alpha = 0.4f), CircleShape))
                    }
                }
            }
        }
    }
}

/** The streak as a glass card: the ring, what it says, and the longest streak. */
@Composable
private fun GlassStreakCard(streak: Int, best: Int) {
    val (title, line) = streakText(streak)
    val frac = streakFraction(streak, best)
    val track = P.fg.copy(alpha = 0.12f)
    val arc = Coral
    Row(
        Modifier.fillMaxWidth().pSurface(RoundedCornerShape(Radius.xl)).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = 8.dp.toPx()
                val box = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w)
                val tl = androidx.compose.ui.geometry.Offset(w / 2f, w / 2f)
                drawArc(track, 0f, 360f, false, tl, box, style = Stroke(w))
                if (frac > 0f) {
                    drawArc(arc, -90f, 360f * frac, false, tl, box, style = Stroke(w, cap = StrokeCap.Round))
                } else {
                    drawCircle(arc, 4.5.dp.toPx(), androidx.compose.ui.geometry.Offset(this.size.width / 2f, w / 2f))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Txt("$streak", 30, weight = FontWeight.Medium)
                Txt(if (streak == 1) "Day" else "Days", 12, P.mute)
            }
        }
        Column(Modifier.weight(1f)) {
            Txt(title, 18, weight = FontWeight.Medium, maxLines = 2)
            Txt(line, 13, P.mute, Modifier.padding(top = 4.dp), maxLines = 3)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GlassTag("Longest streak")
                GlassTag("$best ${if (best == 1) "day" else "days"}")
            }
        }
    }
}

/**
 * Today's entries as a stack of glass cards: the newest in front, the next two peeking out behind it.
 * With nothing logged today it shows your latest entries instead, so the page is never an empty box. The arrows turn the stack.
 */
@Composable
private fun GlassEntries(
    g: GlassLook, vm: BinderViewModel, l: BinderList, sel: String, entries: List<Item>, today: List<Item>, now: Long,
    add: () -> Unit, viewAll: () -> Unit,
) {
    val pile = today.ifEmpty { entries.take(8) }
    val n = pile.size
    var top by rememberSaveable { mutableStateOf(0) }
    val i = if (n == 0) 0 else top.mod(n)
    val showProject = sel == ALL_PROJECTS && l.groups.isNotEmpty()
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Txt(if (today.isEmpty() && n > 0) "Latest entries" else "Today’s entries", 16, weight = FontWeight.Medium)
            Txt("All entries", 13, Coral, Modifier.clickable { viewAll() })
        }
        if (n == 0) {
            Column(
                Modifier.fillMaxWidth().pSurface(RoundedCornerShape(Radius.xl)).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Txt("Nothing logged yet", 18, font = TitleFont, align = TextAlign.Center)
                Txt("How’s today going? A quick note takes under a minute.", 13, P.mute, align = TextAlign.Center)
            }
        } else {
            val peeks = minOf(2, n - 1)
            Box(Modifier.fillMaxWidth()) {
                // the cards behind, furthest first: each one narrower, and showing only a strip with its title
                for (k in peeks downTo 1) {
                    val back = pile[(i + k) % n]
                    Box(
                        Modifier.fillMaxWidth().padding(top = (22 * (peeks - k)).dp, start = (13 * k).dp, end = (13 * k).dp)
                            .height(70.dp).glassCard(g, RoundedCornerShape(Radius.xl)),
                    ) { Txt(back.title, 12, P.mute, Modifier.padding(start = 18.dp, end = 18.dp, top = 4.dp), maxLines = 1) }
                }
                val e = pile[i]
                val flow = l.flowFor(e)
                val st = e.stageIn(flow)
                Column(
                    Modifier.fillMaxWidth().padding(top = (22 * peeks).dp).heightIn(min = 200.dp)
                        .glassCard(g, RoundedCornerShape(Radius.xl), 2)
                        .clickable { vm.nav.push(Route.ItemEdit(l.id, e.id)) }.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MoodTile(e, 44)
                        Column(Modifier.weight(1f)) {
                            Txt(e.title, 16, weight = FontWeight.Medium, maxLines = 1)
                            Txt("${pDayTitle(startOfDay(e.added), now)} · ${pTime(e.added)}", 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                        }
                        PTag(flow[st], stageColor(st, flow.size))
                    }
                    Txt(e.pLine(), 15, P.mute, maxLines = 5, lh = 22.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassTag(e.sub.ifBlank { "No mood" })
                        if (showProject) GlassTag(l.projectName(l.groupIdOf(e)))
                        Spacer(Modifier.weight(1f))
                        IconBtn(Ic.Dots, "Entry options") { vm.sheet = entryMenu(vm, l, e) }
                    }
                }
            }
            if (n > 1) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    GlassCircle(g, Ic.Back, "Previous entry", 40.dp) { top = i - 1 }
                    Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        pile.indices.forEach { j ->
                            Box(Modifier.size(if (j == i) 10.dp else 7.dp).clip(CircleShape).background(if (j == i) Coral else P.fg.copy(alpha = 0.2f)))
                        }
                    }
                    GlassCircle(g, Ic.Chevron, "Next entry", 40.dp) { top = i + 1 }
                }
            }
        }
        if (today.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(52.dp).clip(CircleShape).background(Coral).clickable { add() }, contentAlignment = Alignment.Center) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Txt("Add an entry", 15, CheckInk, weight = FontWeight.Medium)
                    Icon(Ic.Plus, null, tint = CheckInk, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

/** "Today's entries" with its link to All, and the card with the timeline (or the empty note) and the add button. */
@Composable
private fun EntriesBlock(vm: BinderViewModel, l: BinderList, sel: String, today: List<Item>, add: () -> Unit, viewAll: () -> Unit) {
    val showProject = sel == ALL_PROJECTS && l.groups.isNotEmpty()
    Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Txt("Today’s entries", 16, weight = FontWeight.Medium)
            Txt("All entries", 13, Coral, Modifier.clickable { viewAll() })
        }
        BinderCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                if (today.isEmpty()) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Txt("Nothing logged yet", 18, font = TitleFont, align = TextAlign.Center)
                        Txt("How’s today going? A quick note takes under a minute.", 13, P.mute, align = TextAlign.Center)
                    }
                } else {
                    today.forEachIndexed { i, e -> TimelineRow(vm, l, e, last = i == today.lastIndex, showProject = showProject) }
                }
                Box(
                    Modifier.fillMaxWidth().height(52.dp).clip(CircleShape).background(Coral).clickable { add() },
                    contentAlignment = Alignment.Center,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Txt("Add an entry", 15, CheckInk, weight = FontWeight.Medium)
                        Icon(Ic.Plus, null, tint = CheckInk, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

private const val ArrangeRowDp = 84
private const val ArrangeGapDp = 12

/** The cards as three plain rows. Drag a row up or down (anywhere on it) to move it; the order is saved when you let go. */
@Composable
private fun ColumnScope.ArrangeBlocks(vm: BinderViewModel, l: BinderList, entries: List<Item>, today: List<Item>, now: Long, done: () -> Unit) {
    val saved = todayOrder(l.blocks, LocalGlass.current != null)
    var cur by remember(saved) { mutableStateOf(saved) }               // the order while a row is being dragged
    var dragging by remember { mutableStateOf<String?>(null) }
    var offset by remember { mutableFloatStateOf(0f) }                 // how far the dragged row is from where its slot is, in px
    val step = with(LocalDensity.current) { (ArrangeRowDp + ArrangeGapDp).dp.toPx() }
    val streak = entryStreak(loggedDays(entries), epochDay(now))
    Column(Modifier.weight(1f).padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(ArrangeGapDp.dp)) {
        Txt("Drag a card up or down to move it. The page keeps this order.", 13, P.mute, Modifier.padding(start = 4.dp, end = 4.dp, bottom = 4.dp))
        cur.forEach { code ->
            key(code) {
                val on = dragging == code
                val (icon, title, line) = when (code) {
                    BLOCK_WEEK -> Triple("🗓️", "Week", "A tick for each day you logged")
                    BLOCK_STREAK -> Triple("🔥", "Streak", "$streak ${if (streak == 1) "day" else "days"} in a row")
                    else -> Triple("📝", "Today’s entries", "${today.size} ${if (today.size == 1) "entry" else "entries"} today")
                }
                Row(
                    Modifier.fillMaxWidth().height(ArrangeRowDp.dp)
                        .zIndex(if (on) 1f else 0f)
                        .graphicsLayer {
                            translationY = if (on) offset else 0f
                            scaleX = if (on) 1.03f else 1f
                            scaleY = if (on) 1.03f else 1f
                        }
                        .pointerInput(code) {
                            detectDragGestures(
                                onDragStart = {
                                    dragging = code
                                    offset = 0f
                                },
                                onDragEnd = {
                                    dragging = null
                                    offset = 0f
                                    vm.setBlocks(l.id, cur)
                                },
                                onDragCancel = {
                                    dragging = null
                                    offset = 0f
                                    vm.setBlocks(l.id, cur)
                                },
                                onDrag = { change, amount ->
                                    change.consume()
                                    offset += amount.y
                                    val i = cur.indexOf(code)
                                    if (offset > step / 2 && i in 0 until cur.lastIndex) {
                                        cur = movedBlock(cur, code, cur[i + 1])    // swapped with the one below: its slot is now ours
                                        offset -= step
                                    } else if (offset < -step / 2 && i > 0) {
                                        cur = movedBlock(cur, code, cur[i - 1])
                                        offset += step
                                    }
                                },
                            )
                        }
                        .pSurface(RoundedCornerShape(Radius.lg)).padding(start = 18.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(Radius.sm)).background(Coral.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) { Txt(icon, 22) }
                    Column(Modifier.weight(1f)) {
                        Txt(title, 16, weight = FontWeight.Medium, maxLines = 1)
                        Txt(line, 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                    }
                    Grip()
                }
            }
        }
        Box(Modifier.fillMaxWidth().padding(top = 8.dp).height(52.dp).clip(CircleShape).background(Coral).clickable { done() }, contentAlignment = Alignment.Center) {
            Txt("Done", 15, CheckInk, weight = FontWeight.Medium)
        }
    }
}

/** One of today's entries: the mood tile on a line that runs down to the next one, then what you did and when. */
@Composable
private fun TimelineRow(vm: BinderViewModel, l: BinderList, e: Item, last: Boolean, showProject: Boolean) {
    val flow = l.flowFor(e)
    val st = e.stageIn(flow)
    val where = if (showProject) " · ${l.projectName(l.groupIdOf(e))}" else ""
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            MoodTile(e)
            if (!last) Box(Modifier.padding(top = 6.dp).weight(1f).width(2.dp).background(moodColor(e.moodIndex()).copy(alpha = 0.6f)))
        }
        Column(Modifier.weight(1f).padding(bottom = if (last) 0.dp else 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { vm.nav.push(Route.ItemEdit(l.id, e.id)) }) {
                    Txt(e.title, 16, weight = FontWeight.Medium, maxLines = 1)
                    Txt(e.pLine(), 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 2)
                }
                IconBtn(Ic.Dots, "Entry options") { vm.sheet = entryMenu(vm, l, e) }
            }
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Txt("${pTime(e.added)} · ${e.sub.ifBlank { "No mood" }}$where", 12, P.mute, Modifier.weight(1f, fill = false), maxLines = 1)
                PTag(flow[st], stageColor(st, flow.size))
            }
        }
    }
}

// ───────── Workflow ─────────

/** One project's workflow when a project (or General) is chosen; a card per project when All is chosen and there are projects. */
@Composable
private fun ColumnScope.WorkflowTab(
    vm: BinderViewModel, l: BinderList, sel: String, entries: List<Item>,
    add: () -> Unit, pick: (String) -> Unit, newProject: () -> Unit,
) {
    if (l.items.isEmpty()) {
        EmptyBlock("No entries yet", "Entries you log show up here, grouped by workflow stage.", "Add an entry") { add() }
    } else if (sel == ALL_PROJECTS && l.groups.isNotEmpty()) {
        WorkflowOverview(l, pick, newProject)
    } else {
        WorkflowDetail(vm, l, if (sel == ALL_PROJECTS) "" else sel, entries, add)
    }
}

@Composable
private fun ColumnScope.WorkflowOverview(l: BinderList, pick: (String) -> Unit, newProject: () -> Unit) {
    val shown = l.groups.map { it.id } + (if (l.items.any { l.groupIdOf(it) == "" }) listOf("") else emptyList())
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(top = 16.dp, bottom = LocalProdBottom.current)) {
        item(key = "summary") {
            BinderCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Txt("All projects", 16, weight = FontWeight.Medium)
                        val done = l.items.count { it.isFinishedIn(l.flowFor(it)) }
                        PTag("$done of ${l.items.size} done", Coral)
                    }
                    Progress(l.finishedShare(l.items))
                }
            }
        }
        items(shown, key = { it.ifEmpty { "general" } }) { gid ->
            val mine = l.inProject(gid)
            val flow = l.flowOf(gid)
            val counts = stageCountsIn(mine, flow)
            BinderCard(Modifier.fillMaxWidth().clickable { pick(gid) }) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(projectColor(gid)))
                        Txt(l.projectName(gid), 16, weight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
                        Txt("${mine.size} ${if (mine.size == 1) "entry" else "entries"}", 12, P.mute)
                    }
                    Progress(l.finishedShare(mine))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        flow.forEachIndexed { s, name ->
                            Box(Modifier.clip(RoundedCornerShape(Radius.sm)).background(stageColor(s, flow.size)).padding(horizontal = 9.dp, vertical = 4.dp)) {
                                Txt("${counts[s]} $name", 11, CheckInk, weight = FontWeight.Medium, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        item(key = "new") {
            Box(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(Radius.lg)).border(2.dp, P.line, RoundedCornerShape(Radius.lg)).clickable { newProject() },
                contentAlignment = Alignment.Center,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Ic.Plus, null, tint = P.mute, modifier = Modifier.size(18.dp))
                    Txt("New project", 14, P.mute)
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.WorkflowDetail(vm: BinderViewModel, l: BinderList, gid: String, entries: List<Item>, add: () -> Unit) {
    val flow = l.flowOf(gid)
    if (entries.isEmpty()) {
        EmptyBlock("No entries yet", "Entries you log in ${l.projectName(gid)} show up here, grouped by stage.", "Add an entry") { add() }
        return
    }
    val counts = stageCountsIn(entries, flow)
    val done = counts.last()
    val box = if (flow.size > 4) 44.dp else 56.dp
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 16.dp, bottom = LocalProdBottom.current)) {
        item(key = "summary") {
            BinderCard(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Txt(if (gid.isEmpty() && l.groups.isEmpty()) "Workflow" else l.projectName(gid), 16, weight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
                        PTag("$done of ${entries.size} done", Coral)
                    }
                    Progress(l.finishedShare(entries))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        flow.forEachIndexed { s, name ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(Modifier.width(box).height(40.dp).clip(RoundedCornerShape(Radius.sm)).background(stageColor(s, flow.size)), contentAlignment = Alignment.Center) {
                                    Txt("${counts[s]}", 20, CheckInk, weight = FontWeight.Medium)
                                }
                                Txt(name, 11, P.mute, Modifier.widthIn(max = box + 8.dp), maxLines = 1, align = TextAlign.Center)
                            }
                        }
                    }
                }
            }
        }
        flow.indices.forEach { s ->
            val here = entries.filter { it.stageIn(flow) == s }
            if (here.isNotEmpty()) {
                item(key = "stage$s") { Cap("${flow[s].uppercase()} · ${here.size}", Modifier.padding(start = 4.dp)) }
                items(here, key = { it.id }) { e ->
                    val finished = e.isFinishedIn(flow)
                    val next = nextStageIn(flow, e.stage)
                    Row(
                        Modifier.padding(bottom = 12.dp).fillMaxWidth().height(64.dp).pSurface(RoundedCornerShape(Radius.lg))
                            .clickable { vm.nav.push(Route.ItemEdit(l.id, e.id)) }.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        // tap the circle to move the entry on to the next stage (after the last one it starts over at the first)
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).background(if (finished) Coral else Color.Transparent)
                                .border(2.dp, if (finished) Coral else P.line, CircleShape)
                                .clickable { vm.saveItem(l.id, e.copy(stage = next)) },
                            contentAlignment = Alignment.Center,
                        ) { if (finished) Icon(Ic.Check, "Done", tint = CheckInk, modifier = Modifier.size(16.dp)) }
                        Column(Modifier.weight(1f)) {
                            Txt(e.title, 16, if (finished) P.mute else P.fg, maxLines = 1, strike = finished)
                            Txt("${e.faceEmoji()} ${e.sub.ifBlank { "No mood" }} · ${pTime(e.added)}", 12, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                        }
                        PTag("→ ${flow[next]}", stageColor(next, flow.size))
                    }
                }
            }
        }
        item(key = "hint") { Txt("Tap the circle to move an entry to its next stage", 12, P.mute, Modifier.fillMaxWidth().padding(top = 12.dp), align = TextAlign.Center) }
    }
}

// ───────── All entries ─────────

@Composable
private fun ColumnScope.AllTab(
    vm: BinderViewModel, l: BinderList, entries: List<Item>, now: Long, q: String, mood: Int,
    add: () -> Unit, onQuery: (String) -> Unit, onMood: (Int) -> Unit,
) {
    if (entries.isEmpty()) {
        EmptyBlock("Nothing logged yet", "Log what you worked on and how you felt and it builds up here.", "Add an entry") { add() }
        return
    }
    val shown = entries.filtered(mood, q)
    val groups = shown.groupBy { startOfDay(it.added) }.toList()
    Field("Search entries", q, Modifier.padding(top = 12.dp)) { onQuery(it) }
    Chips(listOf("All") + Moods.map { it.name }, mood + 1) { onMood(it - 1) }
    if (shown.isEmpty()) {
        EmptyBlock("No matches", "No entry fits this search and mood.")
        return
    }
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = LocalProdBottom.current)) {
        groups.forEach { (day, list) ->
            item(key = "day$day") { Cap(pDayTitle(day, now).uppercase(), Modifier.padding(start = 4.dp)) }
            items(list, key = { it.id }) { e ->
                val edit = { vm.nav.push(Route.ItemEdit(l.id, e.id)) }
                val flow = l.flowFor(e)
                val st = e.stageIn(flow)
                Box(Modifier.padding(bottom = 12.dp)) {
                    SwipeRow(true, "Edit", "Delete", onRight = { edit() }, onLeft = { vm.deleteItem(l.id, e) }) {
                        Row(
                            Modifier.fillMaxWidth().height(72.dp).pSurface(RoundedCornerShape(Radius.lg))
                                .clickable { edit() }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            MoodTile(e, 44)
                            Column(Modifier.weight(1f)) {
                                Txt(e.title, 16, maxLines = 1)
                                Txt(e.pLine(), 12, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Txt(pTime(e.added), 13, P.mute)
                                PTag(flow[st], stageColor(st, flow.size))
                            }
                        }
                    }
                }
            }
        }
        item { Txt("Swipe left on an entry to delete it", 12, P.mute, Modifier.fillMaxWidth().padding(top = 12.dp), align = TextAlign.Center) }
    }
}

/** Five mood tiles in a row; the chosen one fills with the mood's colour. */
@Composable
private fun MoodPicker(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Moods.forEachIndexed { i, m ->
            val on = i == selected
            Column(
                Modifier.weight(1f).height(78.dp).clip(RoundedCornerShape(Radius.md)).background(if (on) moodColor(i) else P.surface).clickable { onSelect(i) },
                verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Txt(m.emoji, 26)
                Txt(m.name, 11, if (on) CheckInk else P.fg, weight = if (on) FontWeight.Medium else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}

/** Any emoji for an entry: type or paste one (the keyboard's emoji picker works), or tap one below. The first tile goes back to the mood's own. */
@Composable
private fun EmojiPicker(current: String, moodEmoji: String, onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Field("Type or paste any emoji", current) { onPick(it) }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val own = current.isEmpty()
            Row(
                Modifier.height(48.dp).clip(RoundedCornerShape(Radius.sm)).background(if (own) Coral.copy(alpha = 0.3f) else P.surface)
                    .border(2.dp, if (own) Coral else Color.Transparent, RoundedCornerShape(Radius.sm)).clickable { onPick("") }.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Txt(moodEmoji, 22)
                Txt("Mood’s own", 13, maxLines = 1)
            }
            LookEmojis.forEach { em ->
                val on = current == em
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(Radius.sm)).background(if (on) Coral.copy(alpha = 0.3f) else P.surface)
                        .border(2.dp, if (on) Coral else Color.Transparent, RoundedCornerShape(Radius.sm)).clickable { onPick(em) },
                    contentAlignment = Alignment.Center,
                ) { Txt(em, 24) }
            }
        }
    }
}

/** The stages of a workflow as pills (they scroll when there are many); the chosen one fills with its colour. */
@Composable
private fun StagePicker(flow: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val scroll = flow.size > 4
    Row(
        if (scroll) Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()) else Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        flow.forEachIndexed { s, name ->
            val on = s == selected
            val pill = Modifier.height(48.dp).clip(CircleShape).background(if (on) stageColor(s, flow.size) else P.surface).clickable { onSelect(s) }
            Box(if (scroll) pill.padding(horizontal = 18.dp) else pill.weight(1f), contentAlignment = Alignment.Center) {
                Txt(name, 14, if (on) CheckInk else P.fg, weight = if (on) FontWeight.Medium else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}

@Composable
fun ProductivityEntryScreen(vm: BinderViewModel, listId: String, itemId: String?) {
    val nav = vm.nav
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.items?.firstOrNull { it.id == itemId }
    val startProject = when {
        l == null -> ""
        existing != null -> l.groupIdOf(existing)
        else -> ProductivityState.project.takeIf { p -> l.groups.any { it.id == p } } ?: ""    // a new entry starts in the project you were looking at
    }
    var title by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var note by rememberSaveable { mutableStateOf(existing?.note ?: "") }
    var mood by rememberSaveable { mutableStateOf(existing?.moodIndex()?.takeIf { it >= 0 } ?: 0) }
    var emoji by rememberSaveable { mutableStateOf(existing?.emoji ?: "") }    // "" = the mood's own emoji
    var project by rememberSaveable { mutableStateOf(startProject) }
    var stage by rememberSaveable { mutableStateOf(existing?.stage ?: -1) }    // -1 = not chosen: a new entry starts in the second stage (the first of a two-stage workflow)
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val flow = l.flowOf(project)
    val st = if (stage < 0) minOf(1, flow.lastIndex - 1) else stage.coerceIn(0, flow.lastIndex)
    Screen {
        Header2(
            if (existing == null) "New entry" else "Edit entry", l.name, onBack = { nav.pop() },
            right = { if (existing != null) CircleBtn(Ic.Close, "Delete entry") { vm.deleteItem(l.id, existing); nav.pop() } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Cap("WHAT DID YOU WORK ON?", Modifier.padding(start = 4.dp))
            Field("Title", title) { title = it }
            Cap("DESCRIPTION", Modifier.padding(start = 4.dp))
            Field("Optional · how did it go?", note, singleLine = false) { note = it }
            Cap("MOOD", Modifier.padding(start = 4.dp))
            MoodPicker(mood) { mood = it }
            Cap("EMOJI", Modifier.padding(start = 4.dp))
            EmojiPicker(emoji, Moods[mood].emoji) { emoji = cleanEmoji(it) }
            if (l.groups.isNotEmpty()) {
                Cap("PROJECT", Modifier.padding(start = 4.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    l.groups.forEach { g -> ProjChip(g.name.ifBlank { "Project" }, projectColor(g.id), project == g.id) { project = g.id } }
                    ProjChip("General", projectColor(""), project == "") { project = "" }
                }
            }
            Cap("WORKFLOW STAGE", Modifier.padding(start = 4.dp))
            StagePicker(flow, st) { stage = it }
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Save entry", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val m = Moods[mood]
            val item = (existing ?: Item(title = "")).copy(title = title.trim().ifBlank { m.name }, sub = m.name, stage = st, note = note.trim(), group = project, emoji = emoji)
            vm.saveItem(l.id, item)
            nav.pop()
        }
    }
}

// ───────── projects ─────────

private const val SEP = "\u001F"    // between the stage names in the editor's saved state

/** Name a project and give it a workflow: start from a template, then rename, add or remove stages (2 to 6, the last one means done). */
@Composable
fun ProjectEditScreen(vm: BinderViewModel, listId: String, projectId: String?) {
    val nav = vm.nav
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.groups?.firstOrNull { it.id == projectId }
    var name by rememberSaveable { mutableStateOf(existing?.name ?: "") }
    var raw by rememberSaveable { mutableStateOf((existing?.stages?.takeIf { it.size >= MinStages } ?: WorkStages).joinToString(SEP)) }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val stages = raw.split(SEP)
    Screen {
        Header2(
            if (existing == null) "New project" else "Edit project", l.name, onBack = { nav.pop() },
            right = {
                if (existing != null) CircleBtn(Ic.Close, "Delete project") {
                    vm.deleteProject(l.id, existing.id)
                    if (ProductivityState.project == existing.id) ProductivityState.project = ALL_PROJECTS
                    nav.pop()
                }
            },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Cap("NAME", Modifier.padding(start = 4.dp))
            Field("Project name", name) { name = it }
            Cap("START FROM A WORKFLOW", Modifier.padding(start = 4.dp))
            Chips(FlowTemplates.map { it.name }, FlowTemplates.indexOfFirst { it.stages == stages }) { raw = FlowTemplates[it].stages.joinToString(SEP) }
            Cap("STAGES, FIRST TO LAST", Modifier.padding(start = 4.dp))
            stages.forEachIndexed { i, st ->
                Row(Modifier.padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(14.dp).clip(CircleShape).background(stageColor(i, stages.size)))
                    Field(
                        if (i == stages.lastIndex) "Last stage · counts as done" else if (i == 0) "First stage" else "Stage ${i + 1}",
                        st, Modifier.weight(1f),
                    ) { v -> raw = stages.mapIndexed { j, x -> if (j == i) v else x }.joinToString(SEP) }
                    if (stages.size > MinStages) IconBtn(Ic.Close, "Remove stage") { raw = stages.filterIndexed { j, _ -> j != i }.joinToString(SEP) }
                }
            }
            if (stages.size < MaxStages) {
                Box(
                    Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(Radius.md)).border(2.dp, P.line, RoundedCornerShape(Radius.md))
                        .clickable { raw = (stages.dropLast(1) + "" + stages.last()).joinToString(SEP) },
                    contentAlignment = Alignment.Center,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Ic.Plus, null, tint = P.mute, modifier = Modifier.size(18.dp))
                        Txt("Add a stage", 14, P.mute)
                    }
                }
            }
            Txt(
                "The last stage means done. Move entries along from the Workflow tab. If you make a workflow shorter, entries past its end show in the last stage.",
                12, P.mute, Modifier.padding(start = 4.dp, top = 12.dp, bottom = 16.dp),
            )
        }
        BigButton("Save project", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val g = (existing ?: Group(name = "")).copy(name = name.trim().ifBlank { "Project" }, stages = flowToStore(stages))
            ProductivityState.project = vm.saveProject(l.id, g)
            nav.pop()
        }
    }
}
