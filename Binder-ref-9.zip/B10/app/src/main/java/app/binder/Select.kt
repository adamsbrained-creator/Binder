package app.binder

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/** Whether the list is in select mode, and which items are picked. Read by [selectMark]. */
class SelectState(val on: Boolean, val ids: Set<String>)

val LocalSelect = staticCompositionLocalOf { SelectState(false, emptySet()) }

/**
 * In select mode, draws a round tick in the top right corner of an item and an accent outline when it is picked.
 * Does nothing outside select mode, so it can sit on every item layout.
 */
@Composable
fun Modifier.selectMark(id: String): Modifier {
    val s = LocalSelect.current
    if (!s.on) return this
    val picked = id in s.ids
    val accent = Coral
    return this.drawWithContent {
        drawContent()
        val r = 12.dp.toPx()
        val edge = 6.dp.toPx()
        val c = Offset(size.width - r - edge, r + edge)
        if (picked) {
            drawRoundRect(accent, cornerRadius = CornerRadius(12.dp.toPx()), style = Stroke(2.dp.toPx()))
            drawCircle(accent, r, c)
            val tick = Path().apply {
                moveTo(c.x - r * 0.42f, c.y + r * 0.02f)
                lineTo(c.x - r * 0.10f, c.y + r * 0.34f)
                lineTo(c.x + r * 0.45f, c.y - r * 0.30f)
            }
            drawPath(tick, OnAccent, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        } else {
            drawCircle(Color.Black.copy(alpha = 0.25f), r, c)
            drawCircle(Color.White.copy(alpha = 0.8f), r, c, style = Stroke(2.dp.toPx()))
        }
    }
}

/** The floating bar at the bottom in select mode: Status, Move, Copy, Delete. */
@Composable
fun SelectBar(vm: BinderViewModel, l: BinderList, modifier: Modifier = Modifier) {
    val ids = (vm.selected ?: emptySet()).filter { id -> l.items.any { it.id == id } }.toSet()
    val none = ids.isEmpty()
    val fits = vm.lists.filter { it.kind.isChecklist == l.kind.isChecklist && !it.kind.hasOwnPage }
    val moveTo = fits.filter { it.id != l.id }
    val shape = RoundedCornerShape(Radius.xl)
    Row(
        modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp)
            .clip(shape).background(P.surface).border(1.dp, P.line, shape).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        BarBtn(Ic.Layers, "Status", P.fg, !none) {
            vm.sheet = SheetData(
                "Set status for ${ids.size}",
                l.liveStages.map { i -> Act(l.stageLabel(i)) { vm.setStageFor(l.id, ids, i); vm.selected = null } },
            )
        }
        BarBtn(Ic.Move, "Move", P.fg, !none && moveTo.isNotEmpty()) {
            vm.sheet = SheetData(
                "Move ${ids.size} to",
                moveTo.map { t -> Act(t.name) { vm.moveItems(l.id, t.id, ids, false); vm.selected = null } },
            )
        }
        BarBtn(Ic.Folder, "Group", P.fg, !none) {
            vm.sheet = SheetData("Group ${ids.size}", groupActs(vm, l, ids) { vm.selected = null })
        }
        BarBtn(Ic.Copy, "Copy", P.fg, !none) {
            vm.sheet = SheetData(
                "Copy ${ids.size} to",
                fits.map { t ->
                    Act(if (t.id == l.id) "${t.name} (this one)" else t.name) { vm.moveItems(l.id, t.id, ids, true); vm.selected = null }
                },
            )
        }
        BarBtn(Ic.Trash, "Delete", Danger, !none) { vm.deleteItems(l.id, ids); vm.selected = null }
    }
}

@Composable
private fun BarBtn(icon: ImageVector, label: String, tint: Color, enabled: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(Radius.sm)).alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(22.dp))
        Txt(label, 12, tint)
    }
}
