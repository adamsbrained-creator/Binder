package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

// ───────── Showcase: the home with shortcut cards on top and a list of glossy-icon rows ─────────
// Today (opens the Productivity or Habits bind), Checklists and Media (turn that filter on), then "Your Binds":
// the chips and the view button, and one row per bind with its glossy icon, its line and a small progress ring.

@Composable
fun ColumnScope.ShowcaseHome(
    vm: BinderViewModel, shown: List<BinderList>, all: Int, media: Int, checklists: Int,
    pad: Int, open: (BinderList) -> Unit, hold: (BinderList) -> Unit,
) {
    val o = vm.opts
    val dark = P === DarkPal
    val today = vm.lists.firstOrNull { it.kind.isProductivity } ?: vm.lists.firstOrNull { it.kind.isHabits }
    val rows = shown.sortedByDescending { it.pinned }
    val noun = { n: Int -> if (n == 1) o.listLower else o.listsLower }
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 6.dp, bottom = pad.dp)) {
        item(key = "~hero") {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (today != null) {
                    Shortcut(
                        Gloss.SUN, "Today", today.entryLine() ?: today.name,
                        if (dark) 0xFF6B4A0C else 0xFFFFE2A8, if (dark) 0xFF1C1608 else 0xFFFFF4DA,
                    ) { open(today) }
                }
                if (checklists > 0) {
                    Shortcut(
                        Gloss.CHECK, "Checklists", "$checklists ${noun(checklists)}",
                        if (dark) 0xFF0F4A4A else 0xFFBDEFE9, if (dark) 0xFF081A1A else 0xFFE8F9F6,
                    ) { vm.homeFilter = if (vm.homeFilter == 2) 0 else 2 }
                }
                if (media > 0) {
                    Shortcut(
                        Gloss.MEDIA, "Media", "$media ${noun(media)}",
                        if (dark) 0xFF3E2A78 else 0xFFD9CEFF, if (dark) 0xFF120D26 else 0xFFF0EBFF,
                    ) { vm.homeFilter = if (vm.homeFilter == 1) 0 else 1 }
                }
            }
        }
        item(key = "~head") {
            Txt("Your ${o.lists}", 20, weight = FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 24.dp, bottom = 2.dp))
        }
        item(key = "~bar") { HomeViewBar(vm, all, media, checklists, titled = true) }
        items(rows, key = { it.id }) { l -> ShowcaseRow(l, { open(l) }, { hold(l) }) }
    }
}

@Composable
private fun Shortcut(g: Gloss, title: String, sub: String, from: Long, to: Long, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(76.dp).clip(RoundedCornerShape(Radius.lg))
            .background(Brush.horizontalGradient(listOf(Color(from), Color(to))))
            .tapHold(onClick)
            .semantics { role = Role.Button }
            .padding(start = 16.dp, end = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        GlossIcon(g, 52.dp)
        Column(Modifier.weight(1f)) {
            Txt(title, 16, weight = FontWeight.Medium, maxLines = 1)
            Txt(sub, 13, P.fg.copy(alpha = 0.72f), Modifier.padding(top = 2.dp), maxLines = 1)
        }
        Icon(Ic.Chevron, null, tint = P.fg.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ShowcaseRow(l: BinderList, open: () -> Unit, hold: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 62.dp).tapHold(open, hold).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        GlossMark(l, 46.dp)
        Column(Modifier.weight(1f)) {
            Txt(l.name, 16, weight = FontWeight.Medium, maxLines = 1)
            Txt(l.entryLine() ?: "${l.doneCount()} of ${l.items.size} done", 14, P.mute, maxLines = 1)
        }
        if (l.kind.hasOwnPage) Icon(Ic.Chevron, null, tint = P.mute, modifier = Modifier.size(16.dp))
        else MiniRing(l.progress(), 34.dp)
    }
}

/** A small progress ring with no number: the share done. */
@Composable
private fun MiniRing(frac: Float, size: Dp) {
    val track = P.line
    val accent = Coral
    val f = frac.coerceIn(0f, 1f)
    Canvas(Modifier.size(size).semantics { contentDescription = "${(f * 100).roundToInt()} percent" }) {
        val w = 4.dp.toPx()
        val box = Size(this.size.width - w, this.size.height - w)
        val tl = Offset(w / 2f, w / 2f)
        drawArc(track, 0f, 360f, false, tl, box, style = Stroke(w))
        if (f > 0f) drawArc(accent, -90f, 360f * f, false, tl, box, style = Stroke(w, cap = StrokeCap.Round))
    }
}
