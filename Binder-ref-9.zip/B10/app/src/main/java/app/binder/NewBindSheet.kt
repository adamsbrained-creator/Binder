package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

// The "Emoji sheet" way to make a new bind: a sheet that slides up over the screen you are on, with a round emoji for every
// template. It is picked in Settings > New bind (Opts.newBind) and does the same job as NewListScreen, including the look.

/** One template as a round, coloured emoji with its name under it. The picked one shows the look you have chosen. */
@Composable
private fun EmojiTile(kd: Kind, selected: Boolean, tint: Int, face: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            Modifier.size(60.dp).clip(CircleShape).background(Tints.getOrNull(tint)?.color() ?: P.surface)
                .border(3.dp, if (selected) Coral else androidx.compose.ui.graphics.Color.Transparent, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Txt(face, 28) }
        Txt(
            kd.label, 12, if (selected) P.fg else P.mute,
            weight = if (selected) FontWeight.Medium else FontWeight.Normal, maxLines = 1, align = TextAlign.Center,
        )
    }
}

@Composable
fun BoxScope.NewBindSheet(vm: BinderViewModel) {
    val o = vm.opts
    var name by rememberSaveable { mutableStateOf("") }
    var k by rememberSaveable { mutableStateOf(vm.newListKind?.ordinal ?: 0) }
    var tintPick by rememberSaveable { mutableStateOf<Int?>(null) }   // null = not touched: the template's own colour
    var emoji by rememberSaveable { mutableStateOf("") }              // "" = the bind's usual mark
    var custom by rememberSaveable { mutableStateOf("") }
    var look by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.newListKind = null }
    val kind = Kind.entries[k]
    val tint = tintPick ?: kind.defaultTint
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.5f).dp

    SheetFrame({ vm.newBindSheet = false }) {
        Txt("New ${o.listLower}", 22, weight = FontWeight.Medium)
        Field("${o.list} name", name, Modifier.padding(top = 12.dp)) { name = it }
        Column(Modifier.heightIn(max = maxH).verticalScroll(rememberScrollState())) {
            Cap("START FROM")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                KindGroups.flatMap { it.second }.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { kd ->
                            val on = kd == kind
                            EmojiTile(
                                kd, on, if (on) tint else kd.defaultTint, if (on) emoji.ifEmpty { kd.emoji } else kd.emoji,
                                Modifier.weight(1f),
                            ) { k = kd.ordinal }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Txt("${kind.label} · ${kind.hint}", 13, P.mute, Modifier.padding(start = 4.dp, top = 12.dp))
            KindHas(kind)
            Row(
                Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(Radius.md)).background(P.surface)
                    .clickable { look = !look }.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Txt("Customize look", 15, weight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Icon(Ic.Chevron, null, tint = P.mute, modifier = Modifier.size(18.dp).rotate(if (look) 90f else 0f))
            }
            if (look) {
                LookPicker(
                    name = name.trim().ifBlank { kind.label }, emoji = emoji, tint = tint, custom = custom,
                    onEmoji = { emoji = it; custom = "" },
                    onTint = { tintPick = it },
                    onCustom = { custom = firstEmoji(it); emoji = custom },
                )
            }
            Spacer(Modifier.height(8.dp))
        }
        BigButton("Create ${o.listLower}", Modifier.padding(top = 12.dp)) {
            val id = vm.addList(name.trim().ifBlank { kind.label }, kind, emoji, tint)
            vm.newBindSheet = false
            vm.nav.push(Route.Lst(id))
        }
    }
}
