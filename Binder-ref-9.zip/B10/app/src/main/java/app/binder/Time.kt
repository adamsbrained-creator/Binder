package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import kotlinx.coroutines.delay
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.sqrt

// A Span bind (Kind.TIME) always shows how much of today, this week, this month and this year has passed, and counts down to any
// date you add. Each date is a plain Item: title = its name, added = the day counting starts, due = the day it ends, note = the note.
// Only `due` is new in the saved file, and it is optional, so older files and backups load as they are.
// The first half of this file is plain maths (no Compose) so it can be tested on a normal JVM; the second half is the screens.

private const val DAY_MS = 24L * 60 * 60 * 1000

/** What one dot stands for. */
enum class Step(val single: String, val plural: String) {
    HOUR("hour", "hours"), DAY("day", "days"), WEEK("week", "weeks"), MONTH("month", "months"), YEAR("year", "years")
}

/** A stretch of time to show: from [start] up to (not including) [end], one dot per [step]. */
class Span(val title: String, val caption: String, val start: Long, val end: Long, val step: Step)

/**
 * Where [now] is inside a span. [done] whole steps are over; when [live] the next one is running right now (the orange dot).
 * [passed] counts the running step too, so passed + remaining = total, like "288 passed, 77 remaining" for 15 October.
 */
class Gauge(val total: Int, val done: Int, val live: Boolean, val fraction: Float, val step: Step) {
    val passed: Int get() = if (live) done + 1 else done
    val remaining: Int get() = total - passed
}

private fun plus(ms: Long, step: Step, n: Int): Long = Calendar.getInstance().apply {
    timeInMillis = ms
    when (step) {
        Step.HOUR -> add(Calendar.HOUR_OF_DAY, n)
        Step.DAY -> add(Calendar.DAY_OF_MONTH, n)
        Step.WEEK -> add(Calendar.DAY_OF_MONTH, 7 * n)
        Step.MONTH -> add(Calendar.MONTH, n)
        Step.YEAR -> add(Calendar.YEAR, n)
    }
}.timeInMillis

/** How many whole steps fit between [start] and [end]. Counted from [start] each time, so months do not drift. */
fun stepsIn(start: Long, end: Long, step: Step): Int {
    var n = 0
    while (n < 20_000 && plus(start, step, n + 1) <= end) n++
    return n
}

/** The size of dot that keeps a span to about 400 dots: hours for a day or two, up to years for a lifetime. */
fun stepFor(start: Long, end: Long): Step {
    val days = (end - start) / DAY_MS
    return when {
        days <= 2 -> Step.HOUR
        days <= 400 -> Step.DAY
        days <= 2800 -> Step.WEEK
        days <= 12000 -> Step.MONTH
        else -> Step.YEAR
    }
}

/** How much of the span is gone, 0..1 (cheap: no dots are counted). */
fun fractionOf(s: Span, now: Long): Float =
    ((now - s.start).toDouble() / (s.end - s.start).coerceAtLeast(1L)).coerceIn(0.0, 1.0).toFloat()

fun gaugeOf(s: Span, now: Long): Gauge {
    val whole = stepsIn(s.start, s.end, s.step)
    val total = (if (plus(s.start, s.step, whole) < s.end) whole + 1 else whole).coerceAtLeast(1)
    val len = (s.end - s.start).coerceAtLeast(1L)
    val frac = ((now - s.start).toDouble() / len).coerceIn(0.0, 1.0).toFloat()
    return when {
        now < s.start -> Gauge(total, 0, false, 0f, s.step)
        now >= s.end -> Gauge(total, total, false, 1f, s.step)
        else -> Gauge(total, stepsIn(s.start, now, s.step).coerceAtMost(total - 1), true, frac, s.step)
    }
}

/** The four built-in views: "day", "week" (starts on the locale's first day), "month" and "year". */
fun periodSpan(key: String, now: Long): Span {
    val day = startOfDay(now)
    fun cal(ms: Long) = Calendar.getInstance().apply { timeInMillis = ms }
    return when (key) {
        "day" -> Span("Today", "Until midnight", day, startOfDay(now, 1), Step.HOUR)
        "week" -> {
            val s = cal(day).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }.timeInMillis
            val e = plus(s, Step.WEEK, 1)
            Span("This week", "Until ${dateLabel(e - 1)}", s, e, Step.DAY)
        }
        "month" -> {
            val s = cal(day).apply { set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
            val e = plus(s, Step.MONTH, 1)
            Span(SimpleDateFormat("MMMM", Locale.getDefault()).format(Date(now)), "Until ${dateLabel(e - 1)}", s, e, Step.DAY)
        }
        else -> {
            val s = cal(day).apply { set(Calendar.DAY_OF_YEAR, 1) }.timeInMillis
            val e = plus(s, Step.YEAR, 1)
            Span(SimpleDateFormat("yyyy", Locale.getDefault()).format(Date(now)), "Until ${dateLabel(e - 1)}", s, e, Step.DAY)
        }
    }
}

/** A date you added: it counts from the day it starts to the end of the day it is due (so "51 days left" means 51 calendar days). */
fun Item.span(): Span {
    val s = startOfDay(added)
    val e = startOfDay(maxOf(due, s), 1)
    return Span(title, "Until ${dateLabel(e - 1)}", s, e, stepFor(s, e))
}

fun yearFraction(now: Long): Float {
    val y = periodSpan("year", now)
    return ((now - y.start).toDouble() / (y.end - y.start)).coerceIn(0.0, 1.0).toFloat()
}

/** "77 days left", "9h 41m left", "12 min left", or "Done". */
fun leftText(ms: Long): String {
    if (ms <= 0) return "Done"
    val m = ms / 60_000
    val h = m / 60
    return when {
        h >= 48 -> "${h / 24} days left"
        h >= 1 -> "${h}h ${m % 60}m left"
        else -> "${m.coerceAtLeast(1)} min left"
    }
}

/** The big line on the Overview. */
fun heroText(s: Span, now: Long): String = when {
    now < s.start -> "Starts in " + leftText(s.start - now).removeSuffix(" left")
    now >= s.end -> "Done"
    else -> leftText(s.end - now)
}

/** The short version for a row ("51 days", "Done"). */
fun leftShort(s: Span, now: Long): String = if (now >= s.end) "Done" else leftText(s.end - now).removeSuffix(" left")

/** The line under a Span bind's name on Home: "77 days left in 2026 · 2 dates". */
fun timeLine(now: Long, dates: Int): String {
    val y = periodSpan("year", now)
    val tail = if (dates == 0) "" else " · $dates ${if (dates == 1) "date" else "dates"}"
    return leftText(y.end - now) + " in " + SimpleDateFormat("yyyy", Locale.getDefault()).format(Date(now)) + tail
}

/** What is left of this year in short form for Home: "77 days", "9h 41m", "12 min", or "Done". */
fun yearLeftShort(now: Long): String = leftText(periodSpan("year", now).end - now).removeSuffix(" left")

/** Just the number part of that, for a big numeral: "77", "9h", "12". */
fun yearLeftBig(now: Long): String = yearLeftShort(now).substringBefore(' ')

/** The small word under that number: "days", "min", or "left" for hours and minutes; empty once the year is over. */
fun yearLeftUnit(now: Long): String {
    val p = yearLeftShort(now).split(' ')
    return if (p.size < 2) "" else if (p[1] == "days") "days" else if (p[1] == "min") "min" else "left"
}

/** How many dots go in one row of the grid. A year of days (365) is 17 across and 22 down: bigger dots that fill more of the page, so the faint ones reach further down. */
fun dotColumns(n: Int): Int = when {
    n <= 7 -> n.coerceAtLeast(1)
    n <= 24 -> 6
    n <= 31 -> 7
    else -> ceil(sqrt(n * 0.75)).toInt().coerceIn(7, 30)
}

private fun oneDec(v: Float) = String.format(Locale.US, "%.1f", v)

private fun monthStart(ms: Long): Long =
    Calendar.getInstance().apply { timeInMillis = startOfDay(ms); set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis

private fun shiftMonths(ms: Long, n: Int): Long =
    Calendar.getInstance().apply { timeInMillis = ms; add(Calendar.MONTH, n) }.timeInMillis

// ───────── small pieces ─────────

/** One dot per step: passed (solid), the running one (accent, a little bigger), the rest (faint). Fills the page's width, no card around it. */
@Composable
private fun DotGrid(total: Int, done: Int, live: Boolean) {
    val cols = dotColumns(total)
    val rows = (total + cols - 1) / cols
    val past = P.fg
    val now = Coral
    val future = P.line
    val ratio = if (cols >= 20) 0.2f else if (cols >= 14) 0.22f else 0.26f // many columns = small dots; a short span keeps bigger ones
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopStart) {
        Canvas(Modifier.widthIn(max = (cols * 40).dp).fillMaxWidth().aspectRatio(cols.toFloat() / rows)) {
            val cell = size.width / cols
            val r = cell * ratio
            for (i in 0 until total) {
                val running = live && i == done
                val color = if (running) now else if (i < done) past else future
                drawCircle(color, if (running) r * 1.32f else r, Offset(cell * (i % cols + 0.5f), cell * (i / cols + 0.5f)))
            }
        }
    }
}

/** The "Each date has" part of the New bind page, shown when Time is picked. */
@Composable
fun TimeHas(note: String) {
    Txt(note, 12, P.mute, Modifier.padding(start = 4.dp, top = 10.dp))
    Cap("IT SHOWS")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Pair("⏳", "Today, week, month, year" to "dots and %"), Pair("📅", "Dates you add" to "counted down")).forEach { (icon, tv) ->
            Row(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(Radius.lg)).background(P.surface).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { Txt(icon, 24) }
                Txt(tv.first, 16, modifier = Modifier.weight(1f), maxLines = 1)
                Txt(tv.second, 14, P.mute, maxLines = 1)
            }
        }
    }
}

// ───────── the Time page ─────────

@Composable
fun TimeScreen(vm: BinderViewModel, id: String) {
    val nav = vm.nav
    val o = vm.opts
    var tab by rememberSaveable { mutableStateOf(0) }
    var view by rememberSaveable { mutableStateOf("year") } // "day", "week", "month", "year" or a date's id
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }
    val l = vm.lists.firstOrNull { it.id == id }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    // coming up first (soonest on top), then the ones already over (latest on top)
    val dates = l.items.filter { startOfDay(it.due, 1) > now }.sortedBy { it.due } +
        l.items.filter { startOfDay(it.due, 1) <= now }.sortedByDescending { it.due }
    val add = { nav.push(Route.ItemEdit(l.id, null)) }
    // the Dates list opens from the menu; back from it returns to the overview first
    androidx.activity.compose.BackHandler(enabled = tab == 1) { tab = 0 }

    Box(Modifier.fillMaxSize()) {
        Screen {
            Header2(
                if (tab == 0) "" else "Dates", if (tab == 0) "" else "${dates.size} ${if (dates.size == 1) "date" else "dates"}",
                onBack = { if (tab == 0) nav.pop() else tab = 0 },
                right = {
                    CircleBtn(Ic.Dots, "${o.list} options") {
                        vm.sheet = SheetData(
                            l.name,
                            listOf(
                                Act("Dates · ${dates.size}") { tab = 1 },
                                Act("Add date") { add() },
                                Act(if (l.pinned) "Unpin" else "Pin to top") { vm.togglePin(l.id) },
                                Act("Rename") { vm.rename = l },
                                Act("Customize look") { vm.lookFor = l.id },
                                Act("Change icon") { vm.iconFor = l.id },
                                Act("Delete ${o.listLower}", danger = true) { vm.deleteList(l); nav.pop() },
                            ),
                        )
                    }
                },
            )
            if (tab == 0) TimeOverview(vm, dates, now, view, { view = it }, add)
            else DatesTab(vm, l, dates, now, add) { picked -> view = picked.id; tab = 0 }
        }
        MenuFab(vm, onAdd = add, onAddHold = add, addLabel = "New date")
    }
}

/**
 * The Overview: one big number (percent, or time left) with a gray line under it, then the dots across the page.
 * Bottom left: a pill that picks what to show (Day / Week / Month / Year / a date) and a % button that swaps percent for time left.
 */
@Composable
private fun ColumnScope.TimeOverview(vm: BinderViewModel, dates: List<Item>, now: Long, view: String, setView: (String) -> Unit, add: () -> Unit) {
    val keys = listOf("day", "week", "month", "year") + dates.map { it.id }
    val labels = listOf("Day", "Week", "Month", "Year") + dates.map { it.title }
    val idx = keys.indexOf(view).let { if (it < 0) 3 else it }
    val custom = dates.getOrNull(idx - 4)
    val span = if (custom == null) periodSpan(keys[idx], now) else custom.span()
    val g = gaugeOf(span, now)
    val percent = oneDec(g.fraction * 100f)
    var asPercent by rememberSaveable { mutableStateOf(true) }

    Box(Modifier.weight(1f).fillMaxWidth()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 110.dp)) {
            Column(Modifier.padding(start = 2.dp, top = 16.dp)) {
                Txt(
                    if (asPercent) "$percent %" else heroText(span, now), 40, weight = FontWeight.Medium, ls = (-0.02).em, maxLines = 2,
                )
                Txt(
                    if (asPercent) "${span.title} · ${g.passed} passed · ${g.remaining} left" else "${span.title} · $percent % done",
                    17, P.mute, Modifier.padding(top = 2.dp), maxLines = 2,
                )
                if (custom != null && custom.note.isNotBlank()) {
                    Txt(custom.note, 13, P.mute, Modifier.padding(top = 6.dp), maxLines = 3)
                }
            }
            Box(Modifier.padding(top = 20.dp)) { DotGrid(g.total, g.done, g.live) }
            if (dates.isEmpty()) {
                Box(
                    Modifier.fillMaxWidth().padding(top = 20.dp).height(64.dp).dashedBorder(22.dp).clickable { add() },
                    contentAlignment = Alignment.Center,
                ) { Txt("Add a date to count down to", 14, P.mute) }
            }
        }
        Row(
            Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(bottom = 23.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                Modifier.height(48.dp).clip(CircleShape).background(P.surface)
                    .clickable {
                        vm.sheet = SheetData("Show", keys.mapIndexed { i, k -> Act(labels[i]) { setView(k) } } + Act("+ Date") { add() })
                    }.padding(start = 18.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Txt(labels[idx], 16, weight = FontWeight.Medium, modifier = Modifier.widthIn(max = 140.dp), maxLines = 1)
                Icon(Ic.ChevronDown, "Change what is shown", tint = P.fg, modifier = Modifier.size(18.dp))
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(P.surface).clickable { asPercent = !asPercent },
                contentAlignment = Alignment.Center,
            ) { Txt("%", 18, weight = FontWeight.Medium) }
        }
    }
}

@Composable
private fun ColumnScope.DatesTab(vm: BinderViewModel, l: BinderList, dates: List<Item>, now: Long, add: () -> Unit, show: (Item) -> Unit) {
    if (dates.isEmpty()) {
        EmptyBlock("No dates yet", "Add a date and see how much of its time has passed.", "Add a date") { add() }
        return
    }
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp)) {
        items(dates, key = { it.id }) { d ->
            val sp = d.span()
            val live = now >= sp.start && now < sp.end
            val edit = { vm.nav.push(Route.ItemEdit(l.id, d.id)) }
            Box(Modifier.padding(bottom = 8.dp)) {
                SwipeRow(true, "Edit", "Delete", onRight = { edit() }, onLeft = { vm.deleteItem(l.id, d) }) {
                    Row(
                        Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(Radius.lg)).background(P.surface)
                            .clickable { show(d) }.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        ProgressRing(fractionOf(sp, now), 44.dp)
                        Column(Modifier.weight(1f)) {
                            Txt(d.title, 16, maxLines = 1)
                            Txt(dateLabel(sp.end - 1), 12, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                        }
                        Txt(leftShort(sp, now), 14, if (live) Coral else P.mute, maxLines = 1)
                    }
                }
            }
        }
        item(key = "~add") {
            Box(
                Modifier.fillMaxWidth().height(64.dp).dashedBorder(22.dp).clickable { add() },
                contentAlignment = Alignment.Center,
            ) { Txt(if (dates.isEmpty()) "Add a date to count down to" else "Add a date", 14, P.mute) }
        }
        if (dates.isNotEmpty()) {
            item(key = "~hint") {
                Txt("Tap a date to see it · swipe right to edit · swipe left to delete", 12, P.mute, Modifier.fillMaxWidth().padding(top = 12.dp), align = TextAlign.Center)
            }
        }
    }
}

// ───────── add / edit a date ─────────

@Composable
private fun DateTile(label: String, ms: Long, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(Radius.md)
    Column(
        modifier.clip(shape).background(P.surface).border(2.dp, if (on) P.fg else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Txt(label.uppercase(), 11, P.mute, ls = 0.06.em, maxLines = 1)
        Txt(dateLabel(ms), 16, weight = FontWeight.Medium, modifier = Modifier.padding(top = 4.dp), maxLines = 1)
    }
}

@Composable
private fun NavGlyph(glyph: String, onClick: () -> Unit) =
    Box(Modifier.size(48.dp).clip(CircleShape).labeled(glyphLabel(glyph)).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Txt(glyph, 20, P.mute) }

/** A small month calendar. « » move a year, ‹ › a month; tap a day to pick it. */
@Composable
private fun MonthPicker(value: Long, onPick: (Long) -> Unit) {
    var shown by rememberSaveable { mutableStateOf(monthStart(value)) }
    LaunchedEffect(value) { shown = monthStart(value) }
    val cal = Calendar.getInstance().apply { timeInMillis = shown }
    val first = cal.firstDayOfWeek
    val lead = (cal.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val rows = (lead + days + 6) / 7
    val picked = startOfDay(value)
    val today = startOfDay(System.currentTimeMillis())
    val names = DateFormatSymbols.getInstance().shortWeekdays

    BinderCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                NavGlyph("«") { shown = shiftMonths(shown, -12) }
                NavGlyph("‹") { shown = shiftMonths(shown, -1) }
                Txt(
                    SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(shown)), 16, weight = FontWeight.Medium,
                    modifier = Modifier.weight(1f), align = TextAlign.Center, maxLines = 1,
                )
                NavGlyph("›") { shown = shiftMonths(shown, 1) }
                NavGlyph("»") { shown = shiftMonths(shown, 12) }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
                for (i in 0 until 7) {
                    Txt(names[(first - 1 + i) % 7 + 1].take(2), 11, P.mute, Modifier.weight(1f), align = TextAlign.Center, maxLines = 1)
                }
            }
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val d = r * 7 + c - lead + 1
                        if (d < 1 || d > days) {
                            Spacer(Modifier.weight(1f).height(42.dp))
                        } else {
                            val ms = startOfDay(shown, d - 1)
                            val on = ms == picked
                            Box(
                                Modifier.weight(1f).height(42.dp).padding(2.dp).clip(CircleShape)
                                    .background(if (on) Coral else Color.Transparent).clickable { onPick(ms) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Txt(
                                    "$d", 14, if (on) OnAccent else if (ms == today) Coral else P.fg,
                                    weight = if (on) FontWeight.Medium else FontWeight.Normal,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DateScreen(vm: BinderViewModel, listId: String, itemId: String?) {
    val nav = vm.nav
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.items?.firstOrNull { it.id == itemId }
    val today = startOfDay(System.currentTimeMillis())
    var name by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var until by rememberSaveable { mutableStateOf(existing?.due?.takeIf { it > 0L } ?: startOfDay(today, 30)) }
    var from by rememberSaveable { mutableStateOf(existing?.let { startOfDay(it.added) } ?: today) }
    var editing by rememberSaveable { mutableStateOf(0) } // 0 = the "Until" date is being picked, 1 = the "Counting from" date
    var note by rememberSaveable { mutableStateOf(existing?.note ?: "") }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    // the two dates never cross: moving one past the other drags the other along
    val pick: (Long) -> Unit = { ms ->
        if (editing == 0) {
            until = ms
            if (from > ms) from = ms
        } else {
            from = ms
            if (until < ms) until = ms
        }
    }
    Screen {
        Header2(
            if (existing == null) "New date" else "Edit date", l.name, onBack = { nav.pop() },
            right = { if (existing != null) CircleBtn(Ic.Close, "Delete date") { vm.deleteItem(l.id, existing); nav.pop() } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Field("Name · Trip, exam, birthday…", name, Modifier.padding(top = 6.dp)) { name = it }
            Cap("COUNT DOWN TO", Modifier.padding(start = 4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DateTile("Until", until, editing == 0, Modifier.weight(1f)) { editing = 0 }
                DateTile("Counting from", from, editing == 1, Modifier.weight(1f)) { editing = 1 }
            }
            Spacer(Modifier.height(12.dp))
            MonthPicker(if (editing == 0) until else from, pick)
            if (editing == 0) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("End of year") { editing = 0; pick(startOfDay(periodSpan("year", today).end, -1)) }
                    Pill("In 30 days") { editing = 0; pick(startOfDay(today, 30)) }
                    Pill("In 1 year") { editing = 0; pick(startOfDay(today, 365)) }
                }
            }
            Cap("NOTE", Modifier.padding(start = 4.dp))
            Field("Optional · what is it for?", note) { note = it }
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Save date", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val item = (existing ?: Item(title = "")).copy(
                title = name.trim().ifBlank { "Countdown" }, added = minOf(from, until), due = until, note = note.trim(),
            )
            vm.saveItem(l.id, item)
            nav.pop()
        }
    }
}

// ───────── picking a Span bind's icon ─────────

@Composable
fun BoxScope.TimeIconSheet(vm: BinderViewModel, l: BinderList) {
    SheetFrame({ vm.iconFor = null }) {
        Txt("Icon", 22, weight = FontWeight.Medium)
        Txt("What ${l.name} wears on the home screen.", 12, P.mute, Modifier.padding(top = 2.dp, bottom = 14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TimeIcon.entries.forEach { ic ->
                val on = ic == l.timeIcon
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(Radius.lg)).background(P.surface)
                        .border(2.dp, if (on) Coral else Color.Transparent, RoundedCornerShape(Radius.lg))
                        .clickable { vm.setTimeIcon(l.id, ic) }.padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    TimeMark(ic, l.progress(), 52.dp)
                    Txt(ic.label, 13, if (on) P.fg else P.mute, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        BigButton("Done") { vm.iconFor = null }
    }
}
