package app.binder

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Panel { MAIN, RATE, NOTE, MOVE }

/**
 * Press and hold on an item: cover and title, a status switch, four quick actions and a short list.
 * Rate, Note and Move open a small page inside the same sheet.
 */
@Composable
fun BoxScope.ItemSheet(vm: BinderViewModel, t: ItemTarget) {
    val l = vm.lists.firstOrNull { it.id == t.listId }
    val item = l?.items?.firstOrNull { it.id == t.itemId }
    if (l == null || item == null) {
        LaunchedEffect(Unit) { vm.itemSheet = null }
        return
    }
    val ctx = LocalContext.current
    var panel by remember { mutableStateOf(Panel.MAIN) }
    val close = { vm.itemSheet = null }
    val targets = vm.lists.filter { it.id != l.id && !it.kind.hasOwnPage && it.kind.isChecklist == l.kind.isChecklist }

    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            vm.importImages(listOf(uri)) { names ->
                val cur = vm.lists.firstOrNull { it.id == l.id }?.items?.firstOrNull { it.id == item.id }
                if (cur != null && names.isNotEmpty()) vm.saveItem(l.id, cur.copy(images = names + cur.images))
                close()
            }
        }
    }
    BackHandler(panel != Panel.MAIN) { panel = Panel.MAIN }

    SheetFrame(close) {
        when (panel) {
            Panel.MAIN -> Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CoverView(item.title, item.art(), Modifier.width(56.dp), px = 200, showTitle = false, square = l.kind.square)
                    Column(Modifier.weight(1f)) {
                        Txt(item.title, 20, font = TitleFont, maxLines = 2)
                        val line = listOf(item.sub, l.stageLabel(l.stageOf(item))).filter { it.isNotBlank() }.joinToString(" · ")
                        Txt(line, 14, P.mute, Modifier.padding(top = 4.dp), maxLines = 1)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Seg(l.stageLabels(), l.liveStages.indexOf(l.stageOf(item)).coerceAtLeast(0)) { vm.setStage(l.id, item, l.liveStages[it]) }
                Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (l.kind.hasRating) {
                        QuickTile(Ic.Star, formatRating(item.rating).ifEmpty { "Rate" }, Modifier.weight(1f)) { panel = Panel.RATE }
                    }
                    QuickTile(Ic.Note, "Note", Modifier.weight(1f)) { panel = Panel.NOTE }
                    QuickTile(Ic.Edit, "Edit", Modifier.weight(1f)) { close(); vm.nav.push(Route.ItemEdit(l.id, item.id)) }
                    QuickTile(Ic.Share, "Share", Modifier.weight(1f)) {
                        val text = buildString {
                            append(item.title)
                            if (item.sub.isNotBlank()) append(" · ").append(item.sub)
                            if (item.sourceUrl.isNotBlank()) append("\n").append(item.sourceUrl)
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        runCatching { ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        close()
                    }
                }
                SheetRow(Ic.Select, "Select") { vm.selected = setOf(item.id); close() }
                val sameSub = l.items.count { it.sub.isNotBlank() && it.sub.trim().equals(item.sub.trim(), ignoreCase = true) && l.groupIdOf(it).isEmpty() }
                val groupExists = l.groups.any { it.name.trim().equals(item.sub.trim(), ignoreCase = true) }
                if (item.sub.isNotBlank() && l.groupIdOf(item).isEmpty() && (sameSub >= 2 || groupExists)) {
                    SheetRow(Ic.Folder, "Group all by ${item.sub}") { vm.groupBySub(l.id, item.sub); close() }
                }
                SheetRow(Ic.Folder, "Group…", chevron = true) {
                    close()
                    vm.sheet = SheetData("Group “${item.title}”", groupActs(vm, l, setOf(item.id)))
                }
                if (targets.isNotEmpty()) SheetRow(Ic.Move, "Move to another list", chevron = true) { panel = Panel.MOVE }
                SheetRow(Ic.Copy, "Duplicate") { vm.moveItems(l.id, l.id, setOf(item.id), true); close() }
                SheetRow(Ic.Photo, "Change cover") {
                    pickCover.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                // [scrapbook hook 2] The item's own scrap in Scrapbook: write one about it, or open the one that is linked.
                if (item.scrap.isBlank()) SheetRow(Ic.Note, "Write about this") { writeAbout(ctx, vm, l, item); close() }
                else {
                    SheetRow(Ic.Note, "Open scrap") { openScrap(ctx, item.scrap); close() }
                    SheetRow(Ic.Close, "Unlink scrap") { vm.saveItem(l.id, item.copy(scrap = "")); close() }
                }
                if (item.sourceUrl.isNotBlank()) {
                    SheetRow(Ic.Out, "Open on ${item.sourceName.ifBlank { "the web" }}") { openLink(ctx, item.sourceUrl); close() }
                }
                SheetRow(Ic.Trash, "Delete", Danger) { vm.deleteItem(l.id, item); close() }
            }

            Panel.RATE -> Column {
                PanelTitle("Rating") { panel = Panel.MAIN }
                Row(Modifier.fillMaxWidth().padding(vertical = 22.dp), horizontalArrangement = Arrangement.Center) {
                    RatingInput(vm, item.rating) { v -> vm.saveItem(l.id, item.copy(rating = v)) }
                }
                BigButton("Done") { panel = Panel.MAIN }
            }

            Panel.NOTE -> Column {
                var note by remember { mutableStateOf(item.note) }
                PanelTitle("Note") { panel = Panel.MAIN }
                Box(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(Radius.md)).background(P.surface).padding(16.dp)) {
                    if (note.isEmpty()) Txt("Write a note…", 16, P.mute)
                    BasicTextField(
                        value = note,
                        onValueChange = { note = it },
                        minLines = 3,
                        maxLines = 8,
                        textStyle = TextStyle(color = P.fg, fontSize = 16.sp, fontFamily = BodyFont),
                        cursorBrush = SolidColor(Coral),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Spacer(Modifier.height(14.dp))
                BigButton("Save") { vm.saveItem(l.id, item.copy(note = note.trim())); panel = Panel.MAIN }
            }

            Panel.MOVE -> Column {
                PanelTitle("Move to") { panel = Panel.MAIN }
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    targets.forEach { dest ->
                        SheetRow(Ic.List, dest.name) { vm.moveItems(l.id, dest.id, setOf(item.id), false); close() }
                    }
                }
            }
        }
    }
}

@Composable
private fun PanelTitle(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBtn(Ic.Back, "Back") { onBack() }
        Txt(title, 20, font = TitleFont, modifier = Modifier.padding(start = 4.dp))
    }
}

@Composable
private fun QuickTile(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(76.dp).clip(RoundedCornerShape(Radius.md)).background(P.surface).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = P.fg, modifier = Modifier.size(22.dp))
        Txt(label, 13, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
    }
}

@Composable
private fun SheetRow(icon: ImageVector, label: String, color: Color = P.fg, chevron: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(Radius.sm)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (color == P.fg) P.mute else color, modifier = Modifier.size(20.dp))
        Txt(label, 16, color, Modifier.weight(1f), maxLines = 1)
        if (chevron) Icon(Ic.Chevron, null, tint = P.mute, modifier = Modifier.size(18.dp))
    }
}
