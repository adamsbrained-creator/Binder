package app.binder

import java.util.Calendar

// A Tasks bind (Kind.TASKS) is a normal bind with its own page: a day timeline and a list. Every task is a plain Item:
//   title = what to do, note = the note,
//   due   = when: a date and time (a time of exactly midnight means "anytime that day"); 0 = no date,
//   extra = how long it takes in minutes ("" = 30), sub = repeat ("", "d", "w", "m"), rating = 1 for High priority (0 = normal),
//   stage = 1 once a one-off task is done, marks = the days a repeating task was done (day number -> 1).
// Nothing new is saved in the file, so old files and backups need nothing. See Tasks.kt.

enum class Repeat(val key: String, val label: String) {
    NEVER("", "Never"), DAILY("d", "Daily"), WEEKLY("w", "Weekly"), MONTHLY("m", "Monthly")
}

const val DefaultMinutes = 30

val Item.repeatKind: Repeat get() = Repeat.entries.firstOrNull { it.key == sub } ?: Repeat.NEVER
val Item.repeats: Boolean get() = repeatKind != Repeat.NEVER
val Item.isHigh: Boolean get() = rating >= 1f
val Item.isDated: Boolean get() = due != 0L

/** Minutes after midnight that the task starts (0 for a task with no time). */
fun Item.minuteOfDay(): Int {
    if (due == 0L) return 0
    val c = Calendar.getInstance().apply { timeInMillis = due }
    return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
}

/** True when the task has a time of day, false for "anytime". */
val Item.isTimed: Boolean get() = due != 0L && minuteOfDay() != 0

fun Item.minutes(): Int = extra.trim().toIntOrNull()?.coerceIn(5, 720) ?: DefaultMinutes

/** The moment [minute] minutes after midnight on the day that starts at [dayStart]. */
fun atMinute(dayStart: Long, minute: Int): Long = Calendar.getInstance().apply {
    timeInMillis = dayStart
    set(Calendar.HOUR_OF_DAY, minute / 60); set(Calendar.MINUTE, minute % 60)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun dayOfMonth(ms: Long): Int = Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.DAY_OF_MONTH)

/** Does the task fall on the day that starts at [dayStart]? A repeating task never shows before its first day. */
fun Item.occursOn(dayStart: Long): Boolean {
    if (due == 0L) return false
    val first = startOfDay(due)
    if (dayStart < first) return false
    return when (repeatKind) {
        Repeat.NEVER -> dayStart == first
        Repeat.DAILY -> true
        Repeat.WEEKLY -> Math.floorMod(epochDay(dayStart) - epochDay(first), 7) == 0
        Repeat.MONTHLY -> dayOfMonth(dayStart) == dayOfMonth(first)
    }
}

/** A one-off task is done or not; a repeating one is done day by day. */
fun Item.doneOn(dayStart: Long): Boolean = if (repeats) (marks[epochDay(dayStart)] ?: 0) > 0 else stage == 1

fun Item.withDone(dayStart: Long, done: Boolean): Item =
    if (repeats) copy(marks = if (done) marks + (epochDay(dayStart) to 1) else marks - epochDay(dayStart))
    else copy(stage = if (done) 1 else 0)

/** The tasks of one day: the ones with a time first (earliest first), then the "anytime" ones. */
fun tasksOn(items: List<Item>, dayStart: Long): List<Item> =
    items.filter { it.occursOn(dayStart) }
        .sortedWith(compareBy<Item>({ !it.isTimed }, { it.minuteOfDay() }, { it.title.lowercase() }))

/** One-off tasks from an earlier day that are not done. */
fun overdueTasks(items: List<Item>, now: Long): List<Item> =
    items.filter { !it.repeats && it.isDated && it.stage != 1 && startOfDay(it.due) < startOfDay(now) }

class TaskGroups(val overdue: List<Item>, val today: List<Item>, val later: List<Item>, val done: List<Item>)

/** The list view's groups. A task sits in one of them: overdue, today, later (or no date), done. */
fun groupTasks(items: List<Item>, now: Long): TaskGroups {
    val today = startOfDay(now)
    val overdue = overdueTasks(items, now).sortedBy { it.due }
    val todays = tasksOn(items, today)
    val used = (todays + overdue).map { it.id }.toSet()
    val later = items.filter { it.id !in used && (it.repeats || it.stage != 1) }
        .sortedWith(compareBy<Item>({ it.due == 0L }, { it.due }))
    val done = items.filter { it.id !in used && !it.repeats && it.stage == 1 }.sortedByDescending { it.due }
    return TaskGroups(overdue, todays, later, done)
}

/** Share of today's tasks that are done (0 when there are none). */
fun tasksFraction(items: List<Item>, now: Long): Float {
    val day = startOfDay(now)
    val todays = tasksOn(items, day)
    return if (todays.isEmpty()) 0f else todays.count { it.doneOn(day) }.toFloat() / todays.size
}

/** The number on a small card: tasks still to do today. */
fun tasksFace(items: List<Item>, now: Long): String {
    val day = startOfDay(now)
    return "${tasksOn(items, day).count { !it.doneOn(day) }}"
}

/** The line under the bind's name on Home: "3 left today · 1 overdue". */
fun tasksLine(items: List<Item>, now: Long): String {
    if (items.isEmpty()) return "No tasks yet"
    val day = startOfDay(now)
    val todays = tasksOn(items, day)
    val left = todays.count { !it.doneOn(day) }
    val late = overdueTasks(items, now).size
    val head = when {
        todays.isEmpty() -> "Nothing today"
        left == 0 -> "All done today"
        else -> "$left left today"
    }
    return if (late > 0) "$head · $late overdue" else head
}

/** A task on the timeline: where it starts and ends (minutes after midnight) and which column it sits in when others overlap it. */
class TaskSlot(val item: Item, val start: Int, val end: Int, val lane: Int, val lanes: Int)

/** Tasks that overlap in time sit side by side. A task is treated as at least half an hour long, so a short one never covers the next. */
fun layoutSlots(timed: List<Item>): List<TaskSlot> {
    val out = ArrayList<TaskSlot>()
    var cluster = ArrayList<Pair<Item, Int>>()
    val laneEnds = ArrayList<Int>()
    var clusterEnd = -1
    fun flush() {
        val lanes = laneEnds.size.coerceAtLeast(1)
        for ((t, lane) in cluster) {
            val s = t.minuteOfDay()
            out.add(TaskSlot(t, s, s + maxOf(t.minutes(), DefaultMinutes), lane, lanes))
        }
        cluster = ArrayList(); laneEnds.clear(); clusterEnd = -1
    }
    for (t in timed.sortedBy { it.minuteOfDay() }) {
        val s = t.minuteOfDay()
        val e = s + maxOf(t.minutes(), DefaultMinutes)
        if (cluster.isNotEmpty() && s >= clusterEnd) flush()
        var lane = laneEnds.indexOfFirst { it <= s }
        if (lane < 0) { lane = laneEnds.size; laneEnds.add(0) }
        laneEnds[lane] = e
        cluster.add(t to lane)
        clusterEnd = maxOf(clusterEnd, e)
    }
    flush()
    return out
}
