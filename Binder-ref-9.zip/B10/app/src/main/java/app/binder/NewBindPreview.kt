package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// The "Preview first" way to make a new bind: tabs and chips pick the template, and a preview of the Home card changes as you
// choose the template, the name, the colour and the icon. Picked in Settings > New bind (Opts.newBind).

/** The tabs, one for each group in [KindGroups]. */
val PreviewTabs = listOf("Media", "Tracking", "Blank")

/** Which group (tab) a template sits in. */
fun groupIndexOf(kind: Kind): Int = KindGroups.indexOfFirst { kind in it.second }.coerceAtLeast(0)

/** The little field chips under the preview, taken from the template's hint: "Title, author" gives Title and Author. */
fun previewFields(kind: Kind): List<String> =
    kind.hint.replace("…", "").split(",").map { it.trim().replaceFirstChar { c -> c.uppercase() } }.filter { it.isNotEmpty() }

/** A round button for a tab or a template: dark when picked. */
@Composable
private fun PickPill(text: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(44.dp).clip(CircleShape).background(if (on) P.primary else P.surface)
            .clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) { Txt(text, 15, if (on) P.onPrimary else P.fg, maxLines = 1) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NewListPreview(vm: BinderViewModel) {
    val o = vm.opts
    var name by rememberSaveable { mutableStateOf("") }
    var k by rememberSaveable { mutableStateOf(vm.newListKind?.ordinal ?: 0) }
    var tab by rememberSaveable { mutableStateOf(groupIndexOf(vm.newListKind ?: Kind.entries[0])) }
    var tintPick by rememberSaveable { mutableStateOf<Int?>(null) }   // null = not touched: the template's own colour
    var emoji by rememberSaveable { mutableStateOf("") }              // "" = the bind's usual mark
    var custom by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.newListKind = null }
    val kind = Kind.entries[k]
    val tint = tintPick ?: kind.defaultTint
    val bg = Tints.getOrNull(tint)?.color() ?: P.surface
    val shown = name.trim().ifBlank { kind.label }
    val soft = softInk(tint)

    Screen {
        Header2("New ${o.listLower}", onBack = { vm.nav.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PreviewTabs.forEachIndexed { i, label ->
                    PickPill(label, i == tab) { tab = i; k = KindGroups[i].second.first().ordinal }
                }
            }
            FlowRow(
                Modifier.padding(top = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                KindGroups[tab].second.forEach { kd -> PickPill("${kd.emoji} ${kd.label}", kd == kind) { k = kd.ordinal } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Cap("PREVIEW ON HOME") }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Column(
                    Modifier.width(210.dp).clip(RoundedCornerShape(Radius.xl)).background(bg).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (emoji.isEmpty()) ProgressRing(0f, 48.dp)
                    else Box(Modifier.width(48.dp).height(48.dp), contentAlignment = Alignment.Center) { Txt(emoji, 32) }
                    Column {
                        Txt(shown, 22, weight = FontWeight.Medium, maxLines = 1)
                        Txt("0 of 0 done", 14, soft, Modifier.padding(top = 2.dp), maxLines = 1)
                    }
                }
            }
            FlowRow(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                previewFields(kind).forEach { f ->
                    Box(Modifier.clip(RoundedCornerShape(Radius.sm)).background(bg).padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Txt(f, 13, maxLines = 1)
                    }
                }
            }
            Field("${o.list} name", name, Modifier.padding(top = 18.dp)) { name = it }
            KindHas(kind)
            LookPicker(
                name = shown, emoji = emoji, tint = tint, custom = custom,
                onEmoji = { emoji = it; custom = "" },
                onTint = { tintPick = it },
                onCustom = { custom = firstEmoji(it); emoji = custom },
                showPreview = false,
            )
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Create ${o.listLower}", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val id = vm.addList(shown, kind, emoji, tint)
            vm.nav.replaceTop(Route.Lst(id))
        }
    }
}
