package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LookTest {
    @Test fun lookSurvivesSaveAndLoad() {
        val b = BinderList(name = "Reading", kind = Kind.BOOKS, emoji = "📒", tint = 3)
        val back = parseLists(listsToJson(listOf(b)).toString()).single()
        assertEquals("📒", back.emoji)
        assertEquals(3, back.tint)
    }

    @Test fun aPlainBindSavesNoLookKeys() {
        val json = listsToJson(listOf(BinderList(name = "Plain", kind = Kind.BOOKS))).toString()
        assertFalse(json.contains("\"emoji\""))
        assertFalse(json.contains("\"tint\""))
    }

    @Test fun anOldFileLoadsWithoutALook() {
        val old = """{"format":"binder","version":3,"lists":[{"id":"a","name":"Old","kind":"BOOKS","items":[]}]}"""
        val b = parseLists(old).single()
        assertEquals("", b.emoji)
        assertEquals(-1, b.tint)
    }

    @Test fun firstEmojiTakesOneSymbol() {
        assertEquals("📒", firstEmoji("📒📚"))
        assertEquals("a", firstEmoji("abc"))
        assertEquals("", firstEmoji("   "))
    }

    @Test fun everyTemplateIsOnExactlyOneTile() {
        val shown = KindGroups.flatMap { it.second }
        assertEquals(Kind.entries.size, shown.size)
        assertEquals(Kind.entries.toSet(), shown.toSet())
        assertTrue(Kind.entries.all { it.defaultTint in Tints.indices })
    }

    @Test fun accentPictureAndCaptionSurviveSaveAndLoad() {
        val b = BinderList(name = "Run", kind = Kind.TRACKER, accent = 0xFFF7D046.toInt(), image = "a.jpg", imageFill = true, caption = "Keep going")
        val back = parseLists(listsToJson(listOf(b)).toString()).single()
        assertEquals(0xFFF7D046.toInt(), back.accent)
        assertEquals("a.jpg", back.image)
        assertTrue(back.imageFill)
        assertEquals("Keep going", back.caption)
    }

    @Test fun aPlainBindSavesNoAccentPictureOrCaption() {
        val json = listsToJson(listOf(BinderList(name = "Plain", kind = Kind.BOOKS))).toString()
        assertFalse(json.contains("\"accent\""))
        assertFalse(json.contains("\"image\""))
        assertFalse(json.contains("\"caption\""))
    }

    @Test fun aCaptionReplacesTheUsualLine() {
        assertEquals("Mine", BinderList(name = "X", kind = Kind.TRACKER, caption = " Mine ").entryLine())
    }

    @Test fun hexColoursParse() {
        assertEquals(0xFFF5B83D.toInt(), parseHexColor("#F5B83D"))
        assertEquals(0xFFF5B83D.toInt(), parseHexColor("f5b83d"))
        assertEquals(null, parseHexColor("#F5B8"))
        assertEquals(null, parseHexColor("zzzzzz"))
    }
}
