package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class TasksTest {

    private fun at(y: Int, mo: Int, d: Int, h: Int = 0, mi: Int = 0): Long = Calendar.getInstance().apply {
        set(y, mo, d, h, mi, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private val sat = at(2026, Calendar.OCTOBER, 31)

    private fun task(due: Long, sub: String = "", minutes: Int = 0, title: String = "t") =
        Item(title = title, due = due, sub = sub, extra = if (minutes > 0) minutes.toString() else "")

    @Test fun aOneOffTaskOnlyShowsOnItsOwnDay() {
        val t = task(at(2026, Calendar.OCTOBER, 31, 9, 0))
        assertTrue(t.occursOn(sat))
        assertFalse(t.occursOn(startOfDay(sat, 1)))
        assertFalse(t.occursOn(startOfDay(sat, -1)))
    }

    @Test fun aTaskWithNoDateNeverShowsOnADay() {
        assertFalse(task(0L).occursOn(sat))
    }

    @Test fun midnightMeansAnytimeAndAnythingElseHasATime() {
        assertFalse(task(sat).isTimed)
        assertTrue(task(at(2026, Calendar.OCTOBER, 31, 9, 0)).isTimed)
        assertEquals(9 * 60 + 15, task(at(2026, Calendar.OCTOBER, 31, 9, 15)).minuteOfDay())
    }

    @Test fun dailyStartsOnItsFirstDayAndNeverBefore() {
        val t = task(sat, "d")
        assertTrue(t.occursOn(sat))
        assertTrue(t.occursOn(startOfDay(sat, 40)))
        assertFalse(t.occursOn(startOfDay(sat, -1)))
    }

    @Test fun weeklyComesBackOnTheSameWeekday() {
        val t = task(sat, "w")
        assertTrue(t.occursOn(startOfDay(sat, 7)))
        assertTrue(t.occursOn(startOfDay(sat, 14)))
        assertFalse(t.occursOn(startOfDay(sat, 1)))
        assertFalse(t.occursOn(startOfDay(sat, -7)))
    }

    @Test fun monthlyComesBackOnTheSameDayOfTheMonth() {
        val t = task(at(2026, Calendar.OCTOBER, 15), "m")
        assertTrue(t.occursOn(at(2026, Calendar.NOVEMBER, 15)))
        assertTrue(t.occursOn(at(2026, Calendar.DECEMBER, 15)))
        assertFalse(t.occursOn(at(2026, Calendar.NOVEMBER, 16)))
    }

    @Test fun aOneOffIsDoneOnceAndARepeatingOneDayByDay() {
        val one = task(sat)
        assertFalse(one.doneOn(sat))
        assertTrue(one.withDone(sat, true).doneOn(sat))
        assertFalse(one.withDone(sat, true).withDone(sat, false).doneOn(sat))

        val daily = task(sat, "d")
        val ticked = daily.withDone(sat, true)
        assertTrue(ticked.doneOn(sat))
        assertFalse(ticked.doneOn(startOfDay(sat, 1)))
        assertEquals(0, ticked.stage)
        assertFalse(ticked.withDone(sat, false).doneOn(sat))
    }

    @Test fun theDaysTasksAreTimedFirstThenAnytime() {
        val late = task(at(2026, Calendar.OCTOBER, 31, 15, 0), title = "late")
        val early = task(at(2026, Calendar.OCTOBER, 31, 8, 30), title = "early")
        val any = task(sat, title = "any")
        assertEquals(listOf("early", "late", "any"), tasksOn(listOf(any, late, early), sat).map { it.title })
    }

    @Test fun overlappingTasksShareColumnsAndOthersDoNot() {
        val a = task(at(2026, Calendar.OCTOBER, 31, 9, 0), minutes = 30, title = "a")
        val b = task(at(2026, Calendar.OCTOBER, 31, 9, 15), minutes = 30, title = "b")
        val c = task(at(2026, Calendar.OCTOBER, 31, 10, 0), minutes = 30, title = "c")
        val slots = layoutSlots(listOf(c, b, a)).associateBy { it.item.title }
        assertEquals(0, slots.getValue("a").lane)
        assertEquals(1, slots.getValue("b").lane)
        assertEquals(2, slots.getValue("a").lanes)
        assertEquals(1, slots.getValue("c").lanes)
        assertEquals(0, slots.getValue("c").lane)
    }

    @Test fun aShortTaskIsTreatedAsHalfAnHourSoItNeverCoversTheNext() {
        val a = task(at(2026, Calendar.OCTOBER, 31, 9, 0), minutes = 10, title = "a")
        val b = task(at(2026, Calendar.OCTOBER, 31, 9, 20), minutes = 30, title = "b")
        val slots = layoutSlots(listOf(a, b)).associateBy { it.item.title }
        assertEquals(2, slots.getValue("a").lanes)
        assertEquals(1, slots.getValue("b").lane)
    }

    @Test fun homeSaysWhatIsLeftAndWhatIsOverdue() {
        val now = at(2026, Calendar.OCTOBER, 31, 12, 0)
        assertEquals("No tasks yet", tasksLine(emptyList(), now))
        val done = task(at(2026, Calendar.OCTOBER, 31, 9, 0), title = "done").copy(stage = 1)
        val open = task(at(2026, Calendar.OCTOBER, 31, 15, 0), title = "open")
        val late = task(at(2026, Calendar.OCTOBER, 30, 9, 0), title = "late")
        assertEquals("1 left today", tasksLine(listOf(done, open), now))
        assertEquals("1 left today · 1 overdue", tasksLine(listOf(done, open, late), now))
        assertEquals("All done today", tasksLine(listOf(done), now))
        assertEquals("Nothing today · 1 overdue", tasksLine(listOf(late), now))
        assertEquals("1", tasksFace(listOf(done, open), now))
        assertEquals(0.5f, tasksFraction(listOf(done, open), now), 0.001f)
    }

    @Test fun theListGroupsEachTaskOnce() {
        val now = at(2026, Calendar.OCTOBER, 31, 12, 0)
        val today = task(at(2026, Calendar.OCTOBER, 31, 9, 0), title = "today")
        val late = task(at(2026, Calendar.OCTOBER, 29, 9, 0), title = "late")
        val soon = task(at(2026, Calendar.NOVEMBER, 3, 9, 0), title = "soon")
        val someday = task(0L, title = "someday")
        val finished = task(at(2026, Calendar.OCTOBER, 20, 9, 0), title = "finished").copy(stage = 1)
        val g = groupTasks(listOf(today, late, soon, someday, finished), now)
        assertEquals(listOf("late"), g.overdue.map { it.title })
        assertEquals(listOf("today"), g.today.map { it.title })
        assertEquals(listOf("soon", "someday"), g.later.map { it.title })
        assertEquals(listOf("finished"), g.done.map { it.title })
    }

    @Test fun tasksSurviveASaveAndLoad() {
        val t = Item(title = "Groceries", due = at(2026, Calendar.OCTOBER, 31, 13, 30), extra = "45", sub = "w", rating = 1f, marks = mapOf(epochDay(sat) to 1))
        val bind = BinderList(name = "Tasks", kind = Kind.TASKS, layout = Layout.LIST, items = listOf(t))
        val back = parseLists(listsToJson(listOf(bind)).toString()).first()
        assertEquals(Kind.TASKS, back.kind)
        assertEquals(t, back.items.first())
    }
}
