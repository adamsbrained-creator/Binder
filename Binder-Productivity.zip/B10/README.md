# Binder 1.0.0

A list app for Android (Kotlin + Jetpack Compose), in the family with Paperback and Scrapbook.

**Privacy:** your lists and pictures stay on the phone. Only the text you search for is sent, and only when
*Settings > Fetch details automatically* is on (it is off by default). With it off, Binder makes no network calls at all.

## Build it
Push this folder to GitHub. Use the **Binder (signed)** workflow for the APK you install: it signs every build with
your own key, so a new APK installs **over** the old one and keeps your lists (no uninstalling).

**One-time setup**
1. Actions > **Create signing key** > Run workflow.
2. Open that run, download the artifact `signing-secrets` and open the text file inside.
3. Settings > Secrets and variables > Actions: add the four secrets it lists (`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
   `KEY_ALIAS`, `KEY_PASSWORD`). Optional: `TMDB_KEY` and `RAWG_KEY`, and for song recognition `AUDD_KEY` (and, as a backup, `ACR_HOST`, `ACR_KEY` and `ACR_SECRET`).
4. Delete the artifact on the run page and keep the text file somewhere safe. Lose the key and you can only reinstall.
5. Actions > **Binder (signed)** > Run workflow. The APK is under Artifacts > `binder-apk`.

Every later push (or "Run workflow") makes a new signed APK. Its version code is the time in minutes, so it always rises and
Android accepts it as an update. The run's summary shows the key's SHA-256 fingerprint; it must be the same every time.
The **Binder** and **Android (backup)** workflows still make debug APKs, signed with a throwaway key: fine for a quick
test, but do not mix them with signed builds on the same phone.
The signed workflow runs the unit tests after saving the APK; if that last step is red, open it to see which test failed
(the APK is still there).

## Build from a zip (easiest from a phone)
Uploading many files and folders in the GitHub app or browser is painful. Instead, keep **one zip** of the whole project in the
repository and let the **Binder (from zip)** workflow unpack it and build the signed APK.

1. The repository only needs two things: `.github/workflows/binder-zip.yml` and the project zip at the top of the repo
   (not inside a folder). Workflow files must sit in `.github/workflows/` in the repo itself, so they cannot be taken from the zip.
2. To update the app: upload a new zip (Add file > Upload files). The build starts on its own. The zip can hold the project
   folder (`B10/...`) or the files directly.
3. More than one zip? The one uploaded last is built. **Run workflow** lets you type the name of a different one.
4. Same one-time signing setup as above. The APK is under Artifacts > `binder-apk`.

You can keep the other workflows and the project files in the repo. Uploading a zip does not start **Binder** or
**Binder (signed)** (they ignore `*.zip`), and **Binder (signed)** and **Binder (from zip)** use the same version-code
formula (time in minutes) and the same key, so an APK from either one installs over the other. Both name their artifact
`binder-apk`, so check which run you are downloading from.

## Checking your secrets and files
Actions > **Check secrets and files** > Run workflow shows (on the run's page, under Summary) which secrets are set or missing, what to do about each one, and whether your workflow files and project zip are the new ones.
Turn on *test_keys* to try the song keys with one real request each. It never prints a secret. The signing secrets are made by **Create signing key**; the song keys (`AUDD_KEY`, `ACR_*`) come from your AudD and ACRCloud accounts, so you paste those in yourself.

## Trackers
New bind > **Tracker** makes a bind for mood, energy, sleep or anything you rate: you name it, and its page, stats and history use that name.
Each entry is a face (Drained, Low, Okay, Good, Great), a rating out of 10 and an optional note, logged with the time.
The page has **Overview** (latest entry, today's count and average, recent faces), **Stats** (today / this week / most frequent, a 7-day chart, daily averages) and **History** (grouped by day; tap to edit, swipe left to delete, with undo).
The menu button's **+** adds an entry. Trackers are saved like any bind, so backups and older files need nothing new, and they are left out of Search and Quick add.

## Time binds
New bind > **Time** makes a bind that shows how much time is left, and counts down to any date you add.
**Overview** has a chip row: **Day / Week / Month / Year** (always there, Year is the one it opens on) and then each of your dates. The chosen one shows
the time left ("77 days left", or "9h 41m left" in the last two days), the percent completed with a progress line, a **Passed / Remaining** card and a grid of dots:
one per day (or per hour for a day, per week, month or year for long spans), solid = passed, accent = running now, faded = still to come.
**Dates** lists what you added, soonest first, with a progress ring and the time left; tap one to open it on the Overview, swipe right to edit, swipe left to delete (with undo).
The menu button's **+** (or **+ Date** on the chips) opens **New date**: a name, an **Until** date, an optional **Counting from** date (default today), a small month calendar
and a note. A date counts to the **end** of its day, so "51 days left" means 51 calendar days. Presets: End of year, In 30 days, In 1 year.
Dots are sized to keep a span to about 400 of them: hours for a day or two, days up to about a year, then weeks, months and years (a lifetime shows one dot per year).
On Home a Time bind's ring is how much of this year has passed, and its line reads "77 days left in 2026 · 2 dates".
Saved like any bind: the only new key is an optional `due` on an item, so backups and older files need nothing new. Time binds are left out of Search, Quick add and Move / Copy.

## Habits
New bind > **Habits** makes a bind for things you want to do every day (reading, a run, water). You name the bind (Habits, Morning, Health ...) and add habits to it.
Each habit has a **name**, an optional **description**, an **icon** (pick one or type any emoji), a **colour** (21 to choose from), **Yes / No or Count** tracking
(a count habit has a goal per day, like 8 glasses, and goes up one tap at a time) and an optional **streak goal** (7, 21, 30, 66 or 100 days).
The bind page has **Habits** (a card per habit with a square check button for today and a heat map of the last 26 weeks) and **Week** (the last five days as a table; tap a square to tick that day).
Tap a card to open the habit: heat map, current streak and goal, best streak, days done, completion, and a month calendar where you tap any past day to tick it (or untick it).
Press and hold a card for Open / Edit / Delete. The menu button's **+** adds a habit. On Home the bind wears the emoji of the habit at the top of its list, and its line reads "2 of 5 today".
Saved like any bind: the only new keys are optional ones on an item (`marks`, `target`, `streakGoal`), so backups and older files need nothing new. Habits binds are left out of Search, Quick add and Move / Copy.

## Heard (name that song)
New bind > **Heard** makes a bind that names songs by listening, like Shazam, and keeps them in a list. Name it anything (Heard, Songs, Shazams).
**Listen** has one big button. It listens for about ten seconds (the bars move with the sound; **Stop** cancels), then shows what it found: cover, title, artist, album and year,
with **Save to Heard**, **Try again** and **Open in Apple Music** (or Deezer). Before saving you can add a **Note**, a **Rating**, and **Add album to** your Albums bind.
Nothing is saved until you tap Save: a miss, no internet or a missing key only shows a clear message. A song already in the bind says so and the button becomes **Save again**.
**Songs** lists every saved song, grouped by day like a Tracker's History; swipe left to delete (with Undo), swipe right or tap to edit its note and rating.
The **+** (or **Search for a song**) searches Apple Music, then Deezer, by title, like Albums. On Home the bind wears sound bars and a small mic that opens it and starts listening.
Saved like any bind: a song is a plain item (title, artist, album in the item's details, year, cover, link), so backups and older files need nothing new. Heard binds are in Search and Quick add, but not in Move / Copy.

**Where it gets its answers: a chain, so one source stopping doesn't stop the bind**
1. Recognition: **AudD** first (one key, `AUDD_KEY`), then **ACRCloud** (`ACR_HOST`, `ACR_KEY`, `ACR_SECRET`) if AudD can't name the clip or fails. A source with no key is skipped.
2. Cover, album, year and link: whatever the recogniser brought, filled in from **Apple Music**, then **Deezer** (no keys). A result is only used if its title and artist match.
3. Typing a title searches Apple Music, then Deezer.
To add another recogniser (ShazamKit, say) write a `SongRecognizer` in `Recognize.kt` and list it in `Recognizers.chain`.

**Privacy:** listening needs *Settings > Fetch details automatically* on, because the ten-second clip is sent to the recognition service (AudD, then ACRCloud only if AudD fails). The clip is not kept on the phone and
the microphone is only opened while you listen. Android asks for the microphone the first time. Settings > Fetch details shows which recognisers have a key in this build.
AudD is paid after a short trial (300 free requests, about two weeks; then roughly $5 a month for 1,000), so check dashboard.audd.io for current terms. ACRCloud has a free developer tier.

## Productivity
New bind > **Productivity** makes a bind for a daily work log. You name the bind (Productivity, Work, Study ...) and add entries to it.
Each entry has a **title** (what you worked on), an optional **description**, a **mood** (Focused, Calm, Energized, Anxious or Stressed) and a **workflow stage** (Plan, Doing, Review or Done), logged with the time.
The bind page has **Today**, **Workflow** and **All**:
- **Today**: the week strip (ticked days, today, missed and coming days), a streak card (days in a row with an entry, and your longest streak), and today's entries on a timeline with a **...** menu (Edit, Move to the next stage, Delete) and **Add a new entry**. With nothing logged yet it says so and offers the same button.
- **Workflow**: how many entries sit in each stage and how many are Done, then the entries grouped by stage. Tap the circle on an entry to move it to the next stage (after Done it starts over at Plan).
- **All**: every entry grouped by day, with a search box (title, description or mood) and a mood filter; tap to edit, swipe left to delete (with undo).
The menu button's **+** opens **New entry**: title, description, mood chips and a stage switch. Opening an entry from any list edits it, and the **x** in its header deletes it.
A day with at least one entry counts for the streak; a today with nothing logged yet does not break it. On Home the bind wears the mood of its latest entry and its line reads "2 today · 6 day streak". Its ring is the share of today's entries that are Done.
Saved like any bind: an entry is a plain item (title, description in the note, mood in the item's small line, stage, time), so backups and older files need nothing new. Productivity binds are left out of Search, Quick add and Move / Copy.

## Statuses
Every normal bind (not a checklist, Tracker, Time, Habits or Productivity) has statuses: Idea / In progress / Done on **Anything**, To read / Reading / Done on Books, and so on.
Open a bind's menu (press and hold it on Home, or its **...** button) > **Statuses** to rename them or hide one. Names and the hidden status are saved on that bind
(optional keys `stageNames` and `stageHidden`, so backups and older files need nothing new).
Everything follows: the chips above the list, the status buttons on an item, the sections layout, the select-mode Status picker, the swipe label and the progress.
A bind always keeps at least two statuses, so there is a start and a finish: the first one showing is where new things start, the last one showing counts as done.
Things sitting in a hidden status are listed under the one before it (or the first one showing); nothing is changed on them, so showing the status again brings them back.
Reset to the original names puts everything back.

## New in 1.0.0
- **New shell**: round header buttons, a black/white **menu button** at the bottom (tap = menu, press and hold = pops out a +),
  and a menu sheet with Lists / Pinned / Recently edited, Search, Settings and About.
- **Accent color** (Settings > Accent color): Green (default), Coral, Teal, Amber, Violet or Pink, the same six as Scrapbook. It recolours progress lines, the + button, selected chips and links; Delete and Replace stay coral. Saved as the optional key `accent`.
- **New icon**: green with three list rows for Binder (Catalog keeps its ink-on-white icon). The Binder icon is drawn by hand in `res/drawable` (`ic_launcher_binder_background`, `ic_launcher_foreground`, `ic_launcher_monochrome`); `tools/make_icons.py` now only makes the Catalog one.
- **App name**: Binder or Catalog (Settings > App name). One switch sets the name, the launcher icon and label (two activity-aliases, see `Launcher.kt`), and the word for your lists everywhere: Bind/Binds or Catalog/Catalogs.
- **Albums can fetch details** (Settings > Fetch details automatically): type a title and pick a result, or paste an
  Apple Music link. Cover, artist, year, genre and track count are saved on the phone. If you are offline the item is
  saved as typed with "Details pending" and filled in when you open the list later.
- **Home**: pinned cards with a count and progress bar, list rows with a progress ring, dashed "+" slots.
- **List page**: progress bar, "done" check and progress on covers, ratings under covers, square covers for Albums and Games.
  View sheet: show Title / Rating / Added / Progress under covers, 2 / 3 / 4 columns.
- **Item page**: title in the header, status switch, details card (released, genre, source) and an "Open in Apple Music" button.
- **About** page, new text-only list templates, new icon.
- Old data is read automatically (0.1 files and 0.5 backups).

## Not in 1.0
Paperback / Scrapbook sync, "Up next" from Paperback, Spotify links.

## Fetching and keys
Everything below runs only when *Settings > Fetch details automatically* is on, and only for what you type or paste.

| Kind | Sources (first is the default) | Key |
|---|---|---|
| Albums | Apple Music (iTunes Search) | none |
| Movies | TMDB | `TMDB_KEY` |
| Series | TMDB, AniList (anime) | `TMDB_KEY` for TMDB |
| Games | RAWG | `RAWG_KEY` |
| Books | Open Library, Google Books (also the automatic fallback) | none |
| Manga | AniList | none |
| Comics | Google Books | none |
| Anything | Wikipedia | none |
| Places | OpenStreetMap (Nominatim, searches when you press enter) | none |

Any pasted link is routed to the source that recognises it; any other web page is read through its Open Graph tags.
A source's own rating is never imported.

**Keys.** Put `TMDB_KEY=...` and `RAWG_KEY=...` in `local.properties` (already git-ignored) for a local build, or add
them as repository secrets named `TMDB_KEY` and `RAWG_KEY` (Settings > Secrets and variables > Actions) for the
workflows. Nothing is committed. A build without a key still works: that source says it isn't set up and is hidden in
Settings > Fetch details > Sources.

Limits kept by the app: Apple 15 calls a minute, TMDB 30 per 10 s, RAWG 10 per 10 s, Open Library 3 per 3 s,
Nominatim 1 per 1.1 s, AniList 40 per minute.

## Manual checks (things the unit tests can't see)
1. **Binder to Catalog and back** (Settings > App name): the wordmark, the Bind/Binds or Catalog/Catalogs wording
   (menu, empty screen, New..., Add to..., Rename, About), the About icon, and after a moment the launcher icon and label.
   You may need to re-add the icon to the home screen. Switch back and check again.
2. **Restore a backup** (Settings > Backup & restore > Restore): lists and pictures come back; the launcher entry still matches the
   App name; nothing else changes.
3. **Upgrade from the current build**: install over 1.0.0 with the same signing key. Lists, options and pinned lists
   survive; Settings has an Items & ratings page with the Rating style; "listName" is simply ignored.
4. **Fetching off** (the default): no network calls at all. Try a link paste and a search: nothing is sent. Turn it on
   and the sources appear.
5. **Tracker**: New bind > Tracker, name it, add entries with each face and the slider; check Overview, Stats (empty days, one day, a week) and History (swipe left to delete, Undo, tap to edit); pin it and look at its card on Home.
5b. **Time bind**: New bind > Time. Check the Year view against a calendar (days left, percent, passed + remaining = total), then Day, Week and Month.
   Add a date for tomorrow (hours/days), for 3 weeks out, and one 5 years out (weeks); try a **Counting from** date in the past, a date before the start (the other date follows),
   the End of year preset, and the month calendar's year arrows. Leave the screen open past midnight or a full minute and the numbers move on their own.
   Pin it and check its card on Home, and that it does not show up in Search or Quick add.
5c. **Productivity bind**: New bind > Productivity, name it, add entries with each mood and each stage. Check Today (empty, then one entry, then several: the timeline line and the **...** menu), the week strip and streak card (log on two days in a row, then skip a day), Workflow (tap a circle: the entry moves on, and after Done it goes back to Plan) and All (search, mood chips, swipe left to delete, Undo). Pin it and look at its card on Home; check it does not show up in Search or Quick add.
6. **Ratings**: set 0.5, 2.5, 4.75 in both styles; large font size (Settings > Display) keeps stars aligned.
7. **Accent color**: pick each of the six; check the progress line, the menu's + button, selected chips, links and the Settings summary ring all change, that Delete stays coral, and that the choice survives closing the app. Look at the launcher icon (and a themed icon on Android 13+) and About, in Binder and in Catalog.
8. **Bento and Stacks** with covers, without covers (checklists), and with an empty list.

## Licences and credits
About > Licences has the TMDB notice, RAWG, Open Library, AniList, Wikipedia (CC BY-SA) and OpenStreetMap
credits, and a "Data from RAWG" link.

## Where things are
- `Models.kt` – lists, items, list templates (`Kind`), look options
- `Store.kt` – saving, undo, zip backup, navigation, fetching and retry
- `Persist.kt` – reading and writing the JSON file (old files still load)
- `Meta.kt`, `Http.kt` – the source interface, one provider per source, link parsing, the small HTTP helper (GET and POST)
- `Rating.kt`, `RatingUi.kt` – rating maths (pure) and the drawn stars, number style and rating sheet
- `Launcher.kt` – keeps the launcher icon and label in step with the App name
- `tools/make_icons.py` – makes the launcher icons from the Outfit font
- `Images.kt` – picking, downloading, shrinking and showing pictures
- `Theme.kt` – colours, fonts, cover colours
- `Components.kt` – shared pieces and gestures
- `Shell.kt` – menu button, menu sheet, About page
- `Navigation.kt` – headers (Compact / Regular / Large, like Paperback), the small page title, optional navigation bars, drawer
- `Overlays.kt` – hold menus, quick add (with search), undo bar
- `Screens.kt` – home, list and item screens
- `Tracker.kt` – the Tracker kind's page (Overview / Stats / History), the New entry screen and the face and day helpers
- `Productivity.kt`, `ProductivityLogic.kt` – the Productivity kind: the page (Today / Workflow / All), the New entry screen, and the plain Kotlin maths (moods, streaks, the week, stage counts, Home lines; tested)
- `Time.kt` – the Time kind: the date maths (spans, dots, "days left", all plain Kotlin and tested), the page (Overview / Dates), the New date screen with its month calendar
- `Settings.kt` – new list, search, Settings (Paperback style: summary card, grouped rows, one page per group)
- `app/src/test/` – unit tests (one file per source with canned answers, ratings, saving and loading old files)
- Fonts are in `app/src/main/res/font/`, licences in `FONT-LICENSES/`.
