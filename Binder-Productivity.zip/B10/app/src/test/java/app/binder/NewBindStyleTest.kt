package app.binder

import org.junit.Assert.assertEquals
import org.junit.Test

class NewBindStyleTest {
    @Test fun gridIsTheDefault() {
        assertEquals(NewBindStyle.GRID, Opts().newBind)
    }

    @Test fun theSheetShowsEveryTemplateInRowsOfFour() {
        val rows = KindGroups.flatMap { it.second }.chunked(4)
        assertEquals(listOf(4, 4, 4, 3), rows.map { it.size })
    }
}

class PopularKindsTest {
    private fun bind(k: Kind) = BinderList(name = k.label, kind = k)

    @Test fun withNoBindsItIsTheUsualFavourites() {
        assertEquals(listOf(Kind.BOOKS, Kind.MOVIES, Kind.GAMES, Kind.CHECKLIST), popularKinds(emptyList()))
    }

    @Test fun mostUsedComesFirstThenFavouritesFillTheRest() {
        val lists = listOf(bind(Kind.TRACKER), bind(Kind.TRACKER), bind(Kind.BOOKS))
        assertEquals(listOf(Kind.TRACKER, Kind.BOOKS, Kind.MOVIES, Kind.GAMES), popularKinds(lists))
    }

    @Test fun tiesGoInTemplateOrderAndThereAreAlwaysFour() {
        val lists = listOf(Kind.HEARD, Kind.ALBUMS, Kind.SERIES, Kind.COMICS, Kind.MANGA).map { bind(it) }
        assertEquals(listOf(Kind.MANGA, Kind.COMICS, Kind.SERIES, Kind.ALBUMS), popularKinds(lists))
    }
}

class PreviewFirstTest {
    @Test fun eachTemplateSitsInTheRightTab() {
        assertEquals(0, groupIndexOf(Kind.BOOKS))
        assertEquals(0, groupIndexOf(Kind.HEARD))
        assertEquals(1, groupIndexOf(Kind.TRACKER))
        assertEquals(2, groupIndexOf(Kind.ANYTHING))
        assertEquals(KindGroups.size, PreviewTabs.size)
    }

    @Test fun fieldChipsComeFromTheHint() {
        assertEquals(listOf("Title", "Author"), previewFields(Kind.BOOKS))
        assertEquals(listOf("Mood", "Energy", "Sleep"), previewFields(Kind.TRACKER))
        assertEquals(listOf("Year", "Deadlines", "Countdowns"), previewFields(Kind.TIME))
    }
}

class SwipeCardsTest {
    @Test fun thereIsOneCardForEveryTemplate() {
        assertEquals(Kind.entries.size, SwipeOrder.size)
        assertEquals(Kind.entries.toSet(), SwipeOrder.toSet())
    }

    @Test fun everyCardHasALine() {
        Kind.entries.forEach { assertEquals(false, it.blurb.isBlank()) }
    }

    @Test fun theCardsStartWithMediaAndEndWithAnything() {
        assertEquals(Kind.BOOKS, SwipeOrder.first())
        assertEquals(Kind.ANYTHING, SwipeOrder.last())
    }
}
