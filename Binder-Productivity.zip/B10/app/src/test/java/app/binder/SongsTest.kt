package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class SongsTest {
    private val apple = """
    {"resultCount":3,"results":[
      {"wrapperType":"track","kind":"song","trackId":1441164430,"trackName":"Here Comes the Sun (Remastered 2009)","artistName":"The Beatles",
       "collectionName":"Abbey Road (Remastered)","trackViewUrl":"https://music.apple.com/us/album/here-comes-the-sun/1441164426?i=1441164430&uo=4",
       "artworkUrl100":"https://is1-ssl.mzstatic.com/image/thumb/Music/aa/100x100bb.jpg","releaseDate":"1969-09-26T07:00:00Z","primaryGenreName":"Rock"},
      {"wrapperType":"track","kind":"music-video","trackId":5,"trackName":"A video"},
      {"wrapperType":"track","kind":"song","trackId":0,"trackName":"No id"}
    ]}
    """.trimIndent()

    @Test fun appleSongsAreParsed() {
        val r = AppleSongProvider.parse(apple)
        assertEquals(1, r.size) // the video and the one without an id are skipped
        val s = r[0]
        assertEquals("Apple Music", s.sourceName); assertEquals("1441164430", s.sourceId)
        assertEquals("Here Comes the Sun (Remastered 2009)", s.title); assertEquals("The Beatles", s.artist)
        assertEquals("Abbey Road (Remastered)", s.extra); assertEquals("1969", s.year); assertEquals("Rock", s.genre)
        assertTrue(s.coverUrl.endsWith("/600x600bb.jpg")); assertTrue(s.thumbUrl.endsWith("/100x100bb.jpg"))
        // the song's link still points into its album, which is how "Add album to Albums" finds it
        assertEquals("us" to "1441164426", AppleLinks.parse(s.sourceUrl))
    }

    @Test fun appleSongSearchAsksForSongsAndNeedsTwoLetters() {
        val urls = ArrayList<String>()
        val p = AppleSongProvider(get = { urls.add(it); """{"results":[]}""" }, gate = RateGate(10, 1000))
        assertTrue(p.search("a").isEmpty()); assertTrue(urls.isEmpty())
        p.search("here comes the sun")
        assertTrue(urls[0].contains("entity=song")); assertTrue(urls[0].contains("here+comes+the+sun"))
    }

    private val deezer = """
    {"data":[{"id":3135556,"title":"Harder, Better, Faster, Stronger","link":"https://www.deezer.com/track/3135556",
      "artist":{"name":"Daft Punk"},"album":{"id":302127,"title":"Discovery","cover_medium":"https://c/250.jpg","cover_big":"https://c/500.jpg","cover_xl":"https://c/1000.jpg"}},
     {"id":0,"title":"broken"}],"total":2}
    """.trimIndent()

    @Test fun deezerTracksAreParsed() {
        val r = DeezerProvider.parse(deezer)
        assertEquals(1, r.size)
        val t = r[0]
        assertEquals("Deezer", t.sourceName); assertEquals("3135556", t.sourceId)
        assertEquals("Daft Punk", t.artist); assertEquals("Discovery", t.extra)
        assertEquals("https://c/1000.jpg", t.coverUrl); assertEquals("https://c/250.jpg", t.thumbUrl)
        assertEquals("", t.year) // a search result has no date; details() asks for it
    }

    @Test fun deezerDetailsAddTheYear() {
        val p = DeezerProvider(get = { """{"id":3135556,"release_date":"2001-03-07"}""" }, gate = RateGate(10, 1000))
        assertEquals("2001", p.details(DeezerProvider.parse(deezer)[0]).year)
    }

    @Test fun deezerErrorsAreFailures() {
        try { DeezerProvider.parse("""{"error":{"type":"Exception","message":"Quota","code":4}}"""); fail() } catch (e: FetchFailure) { }
        assertTrue(DeezerProvider.parse("""{"data":[],"total":0}""").isEmpty())
    }

    @Test fun deezerLinksAreRecognised() {
        assertEquals("3135556", DeezerLinks.parse("https://www.deezer.com/track/3135556"))
        assertEquals("3135556", DeezerLinks.parse("https://www.deezer.com/en/track/3135556?utm=x"))
        assertNull(DeezerLinks.parse("https://www.deezer.com/album/302127"))
    }

    // ───────── the chain ─────────

    private class Stub(
        override val source: Source, val results: () -> List<Found>,
    ) : MetadataProvider {
        var asked = 0
        override fun search(query: String): List<Found> { asked++; return results() }
        override fun handlesLink(url: String) = false
        override fun fromLink(url: String): Found? = null
    }
    private val hit = Found("Deezer", "1", "", "T", "A")

    @Test fun theBackupAnswersWhenTheFirstIsEmptyOrFails() {
        val first = Stub(Source.APPLE) { emptyList() }
        val second = Stub(Source.DEEZER) { listOf(hit) }
        assertEquals(listOf(hit), FallbackProvider(listOf(first, second)).search("x y"))
        val broken = Stub(Source.APPLE) { throw FetchFailure("busy") }
        assertEquals(listOf(hit), FallbackProvider(listOf(broken, second)).search("x y"))
    }

    @Test fun theFirstResultWinsAndTheBackupIsNotAsked() {
        val first = Stub(Source.APPLE) { listOf(hit) }
        val second = Stub(Source.DEEZER) { throw AssertionError("not needed") }
        FallbackProvider(listOf(first, second)).search("x y")
        assertEquals(0, second.asked)
    }

    @Test fun failureOnlyWhenEveryoneFailedAndOfflineStopsAtOnce() {
        val a = Stub(Source.APPLE) { throw FetchFailure("a") }
        val b = Stub(Source.DEEZER) { throw FetchFailure("b") }
        try { FallbackProvider(listOf(a, b)).search("x y"); fail() } catch (e: FetchFailure) { assertEquals("b", e.message) }
        // one answered (with nothing) and one failed: just no results
        assertTrue(FallbackProvider(listOf(a, Stub(Source.DEEZER) { emptyList() })).search("x y").isEmpty())
        val off = Stub(Source.APPLE) { throw FetchFailure("no net", offline = true) }
        val next = Stub(Source.DEEZER) { listOf(hit) }
        try { FallbackProvider(listOf(off, next)).search("x y"); fail() } catch (e: FetchFailure) { assertTrue(e.offline) }
        assertEquals(0, next.asked)
    }

    @Test fun footerNamesTheBackup() {
        assertEquals("Results from Apple Music · backup: Deezer", FallbackProvider(listOf(Stub(Source.APPLE) { emptyList() }, Stub(Source.DEEZER) { emptyList() })).footer)
        assertEquals("Results from Apple Music", FallbackProvider(listOf(Stub(Source.APPLE) { emptyList() })).footer)
    }

    @Test fun aHeardBindSearchesSongsWithADeezerBackup() {
        assertEquals(listOf(Source.APPLE, Source.DEEZER), Kind.HEARD.sources)
        val p = Sources.forSource(Source.APPLE, Kind.HEARD)
        assertTrue(p is FallbackProvider)
        assertFalse(Sources.forSource(Source.APPLE, Kind.ALBUMS) is FallbackProvider)
        assertEquals(Source.DEEZER, Sources.forSource(Source.DEEZER, Kind.HEARD).source)
        assertTrue(Sources.forLink("https://www.deezer.com/track/3135556") != null)
    }
}
