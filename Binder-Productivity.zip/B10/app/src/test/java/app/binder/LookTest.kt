package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LookTest {
    @Test fun lookSurvivesSaveAndLoad() {
        val b = BinderList(name = "Reading", kind = Kind.BOOKS, emoji = "📒", tint = 3)
        val back = parseLists(listsToJson(listOf(b)).toString()).single()
        assertEquals("📒", back.emoji)
        assertEquals(3, back.tint)
    }

    @Test fun aPlainBindSavesNoLookKeys() {
        val json = listsToJson(listOf(BinderList(name = "Plain", kind = Kind.BOOKS))).toString()
        assertFalse(json.contains("\"emoji\""))
        assertFalse(json.contains("\"tint\""))
    }

    @Test fun anOldFileLoadsWithoutALook() {
        val old = """{"format":"binder","version":3,"lists":[{"id":"a","name":"Old","kind":"BOOKS","items":[]}]}"""
        val b = parseLists(old).single()
        assertEquals("", b.emoji)
        assertEquals(-1, b.tint)
    }

    @Test fun firstEmojiTakesOneSymbol() {
        assertEquals("📒", firstEmoji("📒📚"))
        assertEquals("a", firstEmoji("abc"))
        assertEquals("", firstEmoji("   "))
    }

    @Test fun everyTemplateIsOnExactlyOneTile() {
        val shown = KindGroups.flatMap { it.second }
        assertEquals(Kind.entries.size, shown.size)
        assertEquals(Kind.entries.toSet(), shown.toSet())
        assertTrue(Kind.entries.all { it.defaultTint in Tints.indices })
    }
}
