package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HeardTest {
    private val day = 24L * 60 * 60 * 1000
    private fun song(title: String, artist: String, at: Long, album: String = "") = Item(title = title, sub = artist, extra = album, added = at)

    @Test fun heardIsABindWithItsOwnPageButStillSearchable() {
        assertTrue(Kind.HEARD.hasOwnPage && Kind.HEARD.isHeard)
        assertEquals(listOf(Layout.LIST), Kind.HEARD.layouts)
        assertTrue(Kind.HEARD.inQuickAdd)       // a Quick add target and found by Search
        assertFalse(Kind.TRACKER.inQuickAdd)    // the other own-page binds stay out
        assertTrue(Kind.BOOKS.inQuickAdd)
        assertEquals("Artist", Kind.HEARD.subLabel); assertEquals("Album", Kind.HEARD.extraLabel)
        assertEquals(1, Kind.HEARD.stages.size)
    }

    @Test fun cardLineNamesTheLastSong() {
        assertEquals("Nothing heard yet", heardLine(emptyList()))
        val items = listOf(song("Old", "A", 1000), song("Here Comes the Sun", "The Beatles", 5000), song("Mid", "B", 3000))
        assertEquals("3 songs · Here Comes the Sun", heardLine(items))
        assertEquals("1 song · Old", heardLine(listOf(song("Old", "A", 1))))
        val list = BinderList(name = "Heard", kind = Kind.HEARD, items = items)
        assertEquals("3 songs · Here Comes the Sun", list.entryLine())
        assertEquals("3 songs", list.countLabel())
    }

    @Test fun songsAreGroupedByDayNewestFirst() {
        val now = System.currentTimeMillis()
        val today = startOfDay(now) + 3_600_000
        val items = listOf(song("a", "x", today - day), song("b", "x", today), song("c", "x", today + 1000))
        val g = heardByDay(items)
        assertEquals(2, g.size)
        assertEquals(startOfDay(today), g[0].first)
        assertEquals(listOf("c", "b"), g[0].second.map { it.title })
        assertEquals(listOf("a"), g[1].second.map { it.title })
    }

    @Test fun duplicatesAreFoundIgnoringCaseAndPunctuation() {
        val items = listOf(song("Here Comes the Sun", "The Beatles", 1000), song("Here Comes the Sun", "The Beatles", 9000))
        assertEquals(9000L, findHeard(items, "here comes the sun!", "the beatles")!!.added)
        assertNull(findHeard(items, "Here Comes the Sun", "Nina Simone"))
        assertNull(findHeard(items, "", ""))
    }

    @Test fun anAlbumAlreadyInTheAlbumsBindIsRecognised() {
        val albums = BinderList(name = "Music Albums", kind = Kind.ALBUMS, items = listOf(Item(title = "Abbey Road", sub = "The Beatles")))
        assertTrue(hasAlbum(albums, "abbey road", "The Beatles"))
        assertFalse(hasAlbum(albums, "Abbey Road", "Someone Else"))
        assertFalse(hasAlbum(albums, "", "The Beatles"))
    }

    @Test fun aSongBecomesAnItemWithEverythingItKnows() {
        val m = SongMatch("T", "A", album = "Al", year = "1969", genre = "Rock", url = "https://u", sourceName = "Apple Music", sourceId = "7", matchedBy = "AudD")
        val i = m.toSongItem("cover.jpg", " nice ", 4f)
        assertEquals("T", i.title); assertEquals("A", i.sub); assertEquals("Al", i.extra); assertEquals("1969", i.year); assertEquals("Rock", i.genre)
        assertEquals(listOf("cover.jpg"), i.images); assertEquals("https://u", i.sourceUrl); assertEquals("Apple Music", i.sourceName)
        assertEquals("nice", i.note); assertEquals(4f, i.rating, 0f)
        assertEquals("A · Al", i.songLine())
        assertEquals("Open in Apple Music", i.openLabel())
        assertEquals(emptyList<String>(), m.toSongItem(null).images)
        assertEquals("Open link", SongMatch("T", "A").openLabel())
    }

    @Test fun songsSurviveSavingAndLoading() {
        val l = BinderList(name = "Heard", kind = Kind.HEARD, items = listOf(SongMatch("T", "A", album = "Al", year = "1969", url = "https://u", sourceName = "Deezer").toSongItem("c.jpg", "n", 3f)))
        val back = parseLists(listsToJson(listOf(l)).toString())[0]
        assertEquals(Kind.HEARD, back.kind)
        assertEquals(l.items[0], back.items[0])
    }

    @Test fun deezerIsASourceWithItsOwnOpenLabel() {
        assertEquals(Source.DEEZER, Sources.byLabel("Deezer"))
        assertEquals("Open in Deezer", Source.DEEZER.openLabel)
    }
}
