package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ProductivityTest {

    private val noon = Calendar.getInstance().apply {
        set(2026, Calendar.OCTOBER, 20, 12, 0, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Noon, [back] days before [noon], by the calendar (so a clock change in between does not matter). */
    private fun noonBack(back: Int): Long = Calendar.getInstance().apply { timeInMillis = noon; add(Calendar.DAY_OF_MONTH, -back) }.timeInMillis

    private fun entry(back: Int, stage: Int = 1, mood: String = "Focused", title: String = "Brief", group: String = "") =
        Item(title = title, sub = mood, stage = stage, added = noonBack(back), group = group)

    private val site = Group(id = "site", name = "Website", stages = listOf("Idea", "Build", "Live"))
    private val exam = Group(id = "exam", name = "Exam")      // no workflow of its own: the default one

    private fun bind(vararg items: Item) =
        BinderList(name = "Work", kind = Kind.PRODUCTIVITY, layout = Layout.LIST, groups = listOf(site, exam), items = items.toList())

    @Test fun theKindIsAProductivityBindWithItsOwnPage() {
        assertTrue(Kind.PRODUCTIVITY.isProductivity)
        assertTrue(Kind.PRODUCTIVITY.hasOwnPage)
        assertFalse(Kind.PRODUCTIVITY.inQuickAdd)
        assertEquals(listOf("Plan", "Doing", "Review", "Done"), WorkStages)
        assertEquals(listOf(Layout.LIST), Kind.PRODUCTIVITY.layouts)
    }

    @Test fun anEntryReadsItsMood() {
        val e = entry(0, mood = "Calm")
        assertEquals(1, e.moodIndex())
        assertEquals("😌", e.moodEmoji())
        assertEquals(-1, entry(0, mood = "").moodIndex())
        assertEquals("📝", entry(0, mood = "Sleepy").moodEmoji())
    }

    // ───────── workflows ─────────

    @Test fun aProjectHasItsOwnWorkflowOrTheDefaultOne() {
        val l = bind()
        assertEquals(listOf("Idea", "Build", "Live"), l.flowOf("site"))
        assertEquals(WorkStages, l.flowOf("exam"))          // no stages of its own
        assertEquals(WorkStages, l.flowOf(""))              // General
        assertEquals(WorkStages, l.flowOf("gone"))          // a project that no longer exists
        val tooShort = l.copy(groups = listOf(site.copy(stages = listOf("Only"))))
        assertEquals(WorkStages, tooShort.flowOf("site"))   // fewer than two stages is not a workflow
    }

    @Test fun anEntryFollowsTheWorkflowOfItsProject() {
        val inSite = entry(0, stage = 1, group = "site")
        val loose = entry(0, stage = 1)
        val l = bind(inSite, loose)
        assertEquals(listOf("Idea", "Build", "Live"), l.flowFor(inSite))
        assertEquals(WorkStages, l.flowFor(loose))
        assertEquals(WorkStages, l.flowFor(entry(0, group = "deleted")))    // a stale project id counts as General
    }

    @Test fun stagesAreClampedMovedOnAndWrapped() {
        val flow = listOf("Idea", "Build", "Live")
        assertEquals(2, entry(0, stage = 9).stageIn(flow))                  // the workflow got shorter: the last stage
        assertEquals(0, entry(0, stage = -3).stageIn(flow))
        assertTrue(entry(0, stage = 2).isFinishedIn(flow))
        assertFalse(entry(0, stage = 2).isFinishedIn(WorkStages))           // stage 2 is Review in the default workflow
        assertEquals(1, nextStageIn(flow, 0))
        assertEquals(0, nextStageIn(flow, 2))                               // after the last it starts over
        assertEquals(0, nextStageIn(flow, 7))
    }

    @Test fun stagesAreCountedPerWorkflow() {
        val items = listOf(entry(0, stage = 0), entry(0, stage = 1), entry(1, stage = 1), entry(2, stage = 3))
        assertEquals(listOf(1, 2, 0, 1), stageCountsIn(items, WorkStages))
        assertEquals(listOf(1, 2, 1), stageCountsIn(items, listOf("Idea", "Build", "Live")))   // the 4th stage lands in the last one
    }

    @Test fun finishedShareUsesEachEntrysOwnWorkflow() {
        val a = entry(0, stage = 2, group = "site")     // last of three: finished
        val b = entry(0, stage = 2)                     // Review in the default workflow: not finished
        val c = entry(0, stage = 3)                     // Done: finished
        val l = bind(a, b, c)
        assertEquals(2f / 3f, l.finishedShare(l.items), 0.001f)
        assertEquals(0f, l.finishedShare(emptyList()), 0.001f)
    }

    @Test fun workflowNamesAreCleaned() {
        assertEquals(listOf("A", "B"), cleanFlow(listOf(" A ", "", "B", "  ")))
        assertEquals(WorkStages, cleanFlow(listOf("Only one", " ")))        // too few left: the default
        assertEquals(6, cleanFlow(listOf("1", "2", "3", "4", "5", "6", "7", "8")).size)
        assertEquals(emptyList<String>(), flowToStore(WorkStages))          // the default workflow is not stored
        assertEquals(emptyList<String>(), flowToStore(listOf("Plan", "Doing", "Review", "Done", "")))
        assertEquals(listOf("To do", "Done"), flowToStore(listOf("To do", "Done")))
    }

    @Test fun everyTemplateIsAUsableWorkflow() {
        for (t in FlowTemplates) {
            assertTrue(t.name, t.stages.size in MinStages..MaxStages)
            assertEquals(t.name, t.stages, cleanFlow(t.stages))
        }
        assertEquals(WorkStages, FlowTemplates.first().stages)
    }

    // ───────── projects ─────────

    @Test fun entriesAreSortedIntoProjects() {
        val a = entry(0, title = "A", group = "site")
        val b = entry(0, title = "B", group = "exam")
        val c = entry(0, title = "C")
        val d = entry(0, title = "D", group = "deleted")
        val l = bind(a, b, c, d)
        assertEquals(listOf("A"), l.inProject("site").map { it.title })
        assertEquals(listOf("C", "D"), l.inProject("").map { it.title })    // General holds the loose ones and those of a deleted project
        assertEquals(4, l.inProject(ALL_PROJECTS).size)
        assertEquals("Website", l.projectName("site"))
        assertEquals("General", l.projectName(""))
        assertEquals("Project", l.copy(groups = listOf(site.copy(name = " "))).projectName("site"))   // a blank name shows as "Project"
    }

    @Test fun aStreakIsPerProjectWhenYouLookAtOne() {
        val l = bind(entry(0, group = "site"), entry(1, group = "site"), entry(0, group = "exam"))
        val today = epochDay(noon)
        assertEquals(2, entryStreak(loggedDays(l.inProject("site")), today))
        assertEquals(1, entryStreak(loggedDays(l.inProject("exam")), today))
        assertEquals(2, entryStreak(loggedDays(l.inProject(ALL_PROJECTS)), today))
    }

    @Test fun aProjectWorkflowSavesAndLoads() {
        val e = Item(title = "Landing page", sub = "Focused", stage = 1, added = 42, group = "site")
        val l = bind(e)
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals(listOf("Idea", "Build", "Live"), back.groups.first { it.id == "site" }.stages)
        assertEquals(emptyList<String>(), back.groups.first { it.id == "exam" }.stages)   // no "stages" key was written for it, and it loads as none
        assertEquals("site", back.items.single().group)
        assertEquals(l.groups, back.groups)
    }

    // ───────── days and streaks ─────────

    @Test fun aStreakCountsDaysInARow() {
        val today = epochDay(noon)
        assertEquals(0, entryStreak(emptySet(), today))
        assertEquals(3, entryStreak(loggedDays(listOf(entry(0), entry(1), entry(2), entry(4))), today))
        assertEquals(2, entryStreak(loggedDays(listOf(entry(0), entry(0, title = "Again"), entry(1))), today)) // two on one day count once
    }

    @Test fun aTodayWithNothingYetDoesNotBreakTheStreak() {
        val today = epochDay(noon)
        assertEquals(2, entryStreak(loggedDays(listOf(entry(1), entry(2))), today))
        assertEquals(0, entryStreak(loggedDays(listOf(entry(2), entry(3))), today))   // yesterday missed: the streak is over
    }

    @Test fun theBestStreakIsTheLongestRun() {
        assertEquals(0, bestEntryStreak(emptySet()))
        assertEquals(1, bestEntryStreak(setOf(5)))
        assertEquals(3, bestEntryStreak(setOf(1, 2, 3, 5, 6, 9)))
        assertEquals(0.5f, streakFraction(7, 14), 0.001f)
        assertEquals(1f, streakFraction(20, 14), 0.001f)
        assertEquals(0f, streakFraction(0, 0), 0.001f)
    }

    @Test fun theStreakCardChangesItsWords() {
        assertEquals("Start a new streak", streakText(0).first)
        assertEquals("Nice start", streakText(1).first)
        assertEquals("You’re on a roll", streakText(4).first)
        assertTrue(streakText(4).second.contains("4 days"))
        assertEquals("You’ve been keeping track", streakText(7).first)
    }

    @Test fun theWeekHasSevenDaysAroundToday() {
        val today = epochDay(noon)
        for (first in listOf(Calendar.SUNDAY, Calendar.MONDAY)) {
            val week = weekOf(today, first)
            assertEquals(7, week.size)
            assertTrue(today in week)
            assertEquals(first, dowOf(week.first()))
            assertEquals(today - rowInWeek(today, first), week.first())
        }
    }

    @Test fun eachDayOfTheWeekHasItsOwnLook() {
        val today = 100
        val days = setOf(98, 100)
        assertEquals(DayState.DONE, dayState(98, today, days))
        assertEquals(DayState.MISSED, dayState(99, today, days))
        assertEquals(DayState.DONE, dayState(100, today, days))          // logged today: ticked
        assertEquals(DayState.TODAY, dayState(100, today, setOf(98)))    // nothing yet: still to do
        assertEquals(DayState.UPCOMING, dayState(101, today, days))
    }

    // ───────── lists and Home ─────────

    @Test fun todaysEntriesComeNewestFirst() {
        val early = entry(0, title = "Early").copy(added = noon - 3_600_000L)
        val late = entry(0, title = "Late")
        val old = entry(1, title = "Old")
        assertEquals(listOf("Late", "Early"), todaysEntries(listOf(early, old, late), noon).map { it.title })
        assertTrue(todaysEntries(listOf(old), noon).isEmpty())
    }

    @Test fun entriesAreFilteredByMoodAndSearch() {
        val items = listOf(entry(0), entry(0), entry(1, mood = "Calm"), entry(2))
        assertEquals(4, items.filtered(-1, "").size)
        assertEquals(1, items.filtered(1, "").size)                      // Calm
        assertEquals(1, items.filtered(-1, "calm").size)                 // the mood is searched too
        assertEquals(0, items.filtered(0, "nothing like this").size)
    }

    @Test fun homeShowsTodaysWorkAndTheStreak() {
        val l = bind(entry(0, stage = 3), entry(0, stage = 1), entry(1, stage = 1))
        assertEquals(0.5f, productivityFraction(l, noon), 0.001f)        // one of today's two entries is Done
        assertEquals("2 today · 2 day streak", productivityLine(l.items, noon))
        assertEquals("2d", productivityFace(l.items, noon))
        assertEquals("No entries yet", productivityLine(emptyList(), noon))
        assertEquals("0 today", productivityLine(listOf(entry(3)), noon))
        assertEquals("0d", productivityFace(emptyList(), noon))
    }

    @Test fun homeCountsDoneByEachProjectsOwnLastStage() {
        // stage 2 is the last of Website's three stages (done), but only Review in the default workflow
        val l = bind(entry(0, stage = 2, group = "site"), entry(0, stage = 2))
        assertEquals(0.5f, productivityFraction(l, noon), 0.001f)
    }

    @Test fun theBindWearsTheLatestMood() {
        val l = BinderList(name = "Work", kind = Kind.PRODUCTIVITY, layout = Layout.LIST, items = listOf(entry(1, mood = "Calm"), entry(0, mood = "Stressed")))
        assertEquals("😖", l.productivityEmoji())
        assertNull(BinderList(name = "Books", kind = Kind.BOOKS).productivityEmoji())
        assertNull(BinderList(name = "Work", kind = Kind.PRODUCTIVITY).productivityEmoji())
    }

    @Test fun aProductivityBindSavesAndLoadsLikeAnyBind() {
        val e = Item(title = "Q4 project brief", sub = "Anxious", stage = 1, note = "Waiting on budget numbers", added = 42)
        val l = BinderList(name = "Work", kind = Kind.PRODUCTIVITY, layout = Layout.LIST, items = listOf(e))
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals(Kind.PRODUCTIVITY, back.kind)
        assertEquals(e, back.items.single())
        assertEquals(0, back.doneCount())                                // entries in Done are not "done" items on Home
        assertEquals("1 entry", back.countLabel())
    }

    // ───────── the cards of the Today tab ─────────

    @Test fun theCardsComeInTheUsualOrderUnlessSaved() {
        assertEquals(listOf("week", "streak", "entries"), blockOrder(""))
        assertEquals(listOf("streak", "week", "entries"), blockOrder("streak,week,entries"))
        assertEquals(listOf("streak", "week", "entries"), blockOrder("streak"))                  // the rest follow in the usual order
        assertEquals(listOf("entries", "week", "streak"), blockOrder(" entries , nope,entries,week"))   // unknown names and repeats are ignored
    }

    @Test fun aCardMovesToWhereAnotherOneIs() {
        val o = listOf("week", "streak", "entries")
        assertEquals(listOf("streak", "entries", "week"), movedBlock(o, "week", "entries"))
        assertEquals(listOf("entries", "week", "streak"), movedBlock(o, "entries", "week"))
        assertEquals(listOf("streak", "week", "entries"), movedBlock(o, "streak", "week"))
        assertEquals(o, movedBlock(o, "week", "week"))
        assertEquals(o, movedBlock(o, "week", "gone"))
    }

    // ───────── any emoji ─────────

    @Test fun anEntryWearsItsOwnEmojiOrItsMoods() {
        assertEquals("🎯", entry(0).faceEmoji())
        assertEquals("🚀", entry(0).copy(emoji = "🚀").faceEmoji())
        assertEquals("📝", entry(0, mood = "").faceEmoji())
    }

    @Test fun anyEmojiIsAcceptedButNotLettersOrDigits() {
        assertEquals("🚀", cleanEmoji("🚀"))
        assertEquals("🚀", cleanEmoji(" 🚀🔥"))
        assertEquals("", cleanEmoji(""))
        assertEquals("", cleanEmoji("abc"))
        assertEquals("", cleanEmoji("7"))
    }

    @Test fun theBindWearsTheLatestEntrysOwnEmoji() {
        val l = BinderList(name = "Work", kind = Kind.PRODUCTIVITY, layout = Layout.LIST, items = listOf(entry(1, mood = "Calm"), entry(0).copy(emoji = "🚀")))
        assertEquals("🚀", l.productivityEmoji())
    }

    @Test fun anEntryEmojiAndTheCardOrderSaveAndLoad() {
        val e = Item(title = "Launch", sub = "Energized", added = 7, emoji = "🚀")
        val l = BinderList(name = "Work", kind = Kind.PRODUCTIVITY, layout = Layout.LIST, items = listOf(e), blocks = "streak,entries,week")
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals("🚀", back.items.single().emoji)
        assertEquals("streak,entries,week", back.blocks)
        assertEquals(listOf("streak", "entries", "week"), blockOrder(back.blocks))
        val plain = parseLists(listsToJson(listOf(l.copy(blocks = "", items = listOf(e.copy(emoji = ""))))).toString()).single()
        assertEquals("", plain.blocks)                                   // nothing is written when there is nothing to keep
        assertEquals("", plain.items.single().emoji)
    }
}
