package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ProductivityTest {

    private val noon = Calendar.getInstance().apply {
        set(2026, Calendar.OCTOBER, 20, 12, 0, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Noon, [back] days before [noon], by the calendar (so a clock change in between does not matter). */
    private fun noonBack(back: Int): Long = Calendar.getInstance().apply { timeInMillis = noon; add(Calendar.DAY_OF_MONTH, -back) }.timeInMillis

    private fun entry(back: Int, stage: Int = 1, mood: String = "Focused", title: String = "Brief") =
        Item(title = title, sub = mood, stage = stage, added = noonBack(back))

    @Test fun theKindIsAProductivityBindWithItsOwnPage() {
        assertTrue(Kind.PRODUCTIVITY.isProductivity)
        assertTrue(Kind.PRODUCTIVITY.hasOwnPage)
        assertFalse(Kind.PRODUCTIVITY.inQuickAdd)
        assertEquals(listOf("Plan", "Doing", "Review", "Done"), WorkStages)
        assertEquals(listOf(Layout.LIST), Kind.PRODUCTIVITY.layouts)
    }

    @Test fun anEntryReadsItsMoodAndStage() {
        val e = entry(0, stage = 2, mood = "Calm")
        assertEquals(1, e.moodIndex())
        assertEquals("😌", e.moodEmoji())
        assertEquals(2, e.workStage())
        assertFalse(e.isFinished())
        assertEquals(-1, entry(0, mood = "").moodIndex())
        assertEquals("📝", entry(0, mood = "Sleepy").moodEmoji())
        assertTrue(entry(0, stage = 9).isFinished())          // a stage out of range counts as the last one
    }

    @Test fun stagesMoveOnAndWrap() {
        assertEquals(1, nextWorkStage(0))
        assertEquals(3, nextWorkStage(2))
        assertEquals(0, nextWorkStage(3))
    }

    @Test fun aStreakCountsDaysInARow() {
        val today = epochDay(noon)
        assertEquals(0, entryStreak(emptySet(), today))
        assertEquals(3, entryStreak(loggedDays(listOf(entry(0), entry(1), entry(2), entry(4))), today))
        assertEquals(2, entryStreak(loggedDays(listOf(entry(0), entry(0, title = "Again"), entry(1))), today)) // two on one day count once
    }

    @Test fun aTodayWithNothingYetDoesNotBreakTheStreak() {
        val today = epochDay(noon)
        assertEquals(2, entryStreak(loggedDays(listOf(entry(1), entry(2))), today))
        assertEquals(0, entryStreak(loggedDays(listOf(entry(2), entry(3))), today))   // yesterday missed: the streak is over
    }

    @Test fun theBestStreakIsTheLongestRun() {
        assertEquals(0, bestEntryStreak(emptySet()))
        assertEquals(1, bestEntryStreak(setOf(5)))
        assertEquals(3, bestEntryStreak(setOf(1, 2, 3, 5, 6, 9)))
        assertEquals(0.5f, streakFraction(7, 14), 0.001f)
        assertEquals(1f, streakFraction(20, 14), 0.001f)
        assertEquals(0f, streakFraction(0, 0), 0.001f)
    }

    @Test fun theStreakCardChangesItsWords() {
        assertEquals("Start a new streak", streakText(0).first)
        assertEquals("Nice start", streakText(1).first)
        assertEquals("You’re on a roll", streakText(4).first)
        assertTrue(streakText(4).second.contains("4 days"))
        assertEquals("You’ve been keeping track", streakText(6 + 1).first)
    }

    @Test fun theWeekHasSevenDaysAroundToday() {
        val today = epochDay(noon)
        for (first in listOf(Calendar.SUNDAY, Calendar.MONDAY)) {
            val week = weekOf(today, first)
            assertEquals(7, week.size)
            assertTrue(today in week)
            assertEquals(first, dowOf(week.first()))
            assertEquals(today - rowInWeek(today, first), week.first())
        }
    }

    @Test fun eachDayOfTheWeekHasItsOwnLook() {
        val today = 100
        val days = setOf(98, 100)
        assertEquals(DayState.DONE, dayState(98, today, days))
        assertEquals(DayState.MISSED, dayState(99, today, days))
        assertEquals(DayState.DONE, dayState(100, today, days))          // logged today: ticked
        assertEquals(DayState.TODAY, dayState(100, today, setOf(98)))    // nothing yet: still to do
        assertEquals(DayState.UPCOMING, dayState(101, today, days))
    }

    @Test fun todaysEntriesComeNewestFirst() {
        val early = entry(0, title = "Early").copy(added = noon - 3_600_000L)
        val late = entry(0, title = "Late")
        val old = entry(1, title = "Old")
        assertEquals(listOf("Late", "Early"), todaysEntries(listOf(early, old, late), noon).map { it.title })
        assertTrue(todaysEntries(listOf(old), noon).isEmpty())
    }

    @Test fun stagesAreCountedAndFiltered() {
        val items = listOf(entry(0, stage = 0), entry(0, stage = 1), entry(1, stage = 1, mood = "Calm"), entry(2, stage = 3))
        assertEquals(listOf(1, 2, 0, 1), stageCounts(items))
        assertEquals(0.25f, finishedFraction(items), 0.001f)
        assertEquals(0f, finishedFraction(emptyList()), 0.001f)
        assertEquals(4, items.filtered(-1, "").size)
        assertEquals(1, items.filtered(1, "").size)                      // Calm
        assertEquals(1, items.filtered(-1, "calm").size)                 // the mood is searched too
        assertEquals(0, items.filtered(0, "nothing like this").size)
    }

    @Test fun homeShowsTodaysWorkAndTheStreak() {
        val items = listOf(entry(0, stage = 3), entry(0, stage = 1), entry(1, stage = 1))
        assertEquals(0.5f, productivityFraction(items, noon), 0.001f)    // one of today's two entries is Done
        assertEquals("2 today · 2 day streak", productivityLine(items, noon))
        assertEquals("2d", productivityFace(items, noon))
        assertEquals("No entries yet", productivityLine(emptyList(), noon))
        assertEquals("0 today", productivityLine(listOf(entry(3)), noon))
        assertEquals("0d", productivityFace(emptyList(), noon))
    }

    @Test fun theBindWearsTheLatestMood() {
        val l = BinderList(name = "Work", kind = Kind.PRODUCTIVITY, layout = Layout.LIST, items = listOf(entry(1, mood = "Calm"), entry(0, mood = "Stressed")))
        assertEquals("😖", l.productivityEmoji())
        assertNull(BinderList(name = "Books", kind = Kind.BOOKS).productivityEmoji())
        assertNull(BinderList(name = "Work", kind = Kind.PRODUCTIVITY).productivityEmoji())
    }

    @Test fun aProductivityBindSavesAndLoadsLikeAnyBind() {
        val e = Item(title = "Q4 project brief", sub = "Anxious", stage = 1, note = "Waiting on budget numbers", added = 42)
        val l = BinderList(name = "Work", kind = Kind.PRODUCTIVITY, layout = Layout.LIST, items = listOf(e))
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals(Kind.PRODUCTIVITY, back.kind)
        assertEquals(e, back.items.single())
        assertEquals(0, back.doneCount())                                // entries in Done are not "done" items on Home
        assertEquals("1 entry", back.countLabel())
    }
}
