package app.binder

import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkTest {
    private val itemId = "6f1c2d3e-aaaa-bbbb-cccc-1234567890ab"

    @Test fun readsBinderLinks() {
        val item = parseBinderUri("binder://item/$itemId")!!
        assertEquals("item", item.kind); assertEquals(itemId, item.id)
        val bind = parseBinderUri(" binder://bind/abcdef12/ ")!!
        assertEquals("bind", bind.kind); assertEquals("abcdef12", bind.id)
        assertNull(parseBinderUri("binder://other/abcdef12")); assertNull(parseBinderUri("https://example.com")); assertNull(parseBinderUri(null)); assertNull(parseBinderUri("binder://item/short"))
    }

    @Test fun theLinkBackToAScrapCarriesTheItemAndItsName() {
        assertEquals("scrapbook://scrap/abc123?binder=$itemId&title=Perfect+Days+%26+Co", bounceUrl("abc123", itemId, "Perfect Days & Co"))
        assertEquals("scrapbook://scrap/abc123", scrapUrl("abc123"))
    }

    @Test fun aScrapIdLooksLikeScrapbooksOwn() {
        val a = newScrapUid(); val b = newScrapUid()
        assertTrue(Regex("[0-9a-f]{32}").matches(a)); assertNotEquals(a, b)
        assertTrue(isScrapUid(a)); assertFalse(isScrapUid("short")); assertFalse(isScrapUid("has space in it 123"))
    }

    @Test fun theScrapAboutAMovieHasItsDetailsAQuoteAndAPlaceToWrite() {
        val l = BinderList(name = "Movies", kind = Kind.MOVIES)
        val item = Item(id = "item-1234", title = "Perfect Days", sub = "2023", year = "2023", genre = "Drama", extra = "125 min", stage = 2, rating = 5f, description = "A janitor.\nQuiet life.")
        val expected = "**Year:** 2023\n**Genre:** Drama\n**Runtime:** 125 min\n**Status:** Watched\n**Rating:** 5 / 5\n\n> A janitor.\n> Quiet life.\n\n## My thoughts\n\n\nBinder: [Perfect Days](binder://item/item-1234)"
        assertEquals(expected, aboutBody(l, item, Locale.ROOT))
    }

    @Test fun theScrapAboutAChecklistItemHasNoStatusOrRating() {
        val l = BinderList(name = "To do", kind = Kind.CHECKLIST)
        assertEquals("## My thoughts\n\n\nBinder: [Buy milk](binder://item/item-1234)", aboutBody(l, Item(id = "item-1234", title = "Buy milk"), Locale.ROOT))
    }

    @Test fun bracketsInATitleDoNotBreakTheLink() {
        val body = aboutBody(BinderList(name = "Movies", kind = Kind.MOVIES), Item(id = "item-1234", title = "A [b] c"), Locale.ROOT)
        val label = body.substringAfterLast("Binder: [").substringBefore("](")
        assertFalse(label.contains('[')); assertFalse(label.contains(']'))
    }

    @Test fun anImportNamesOnlyKindsAThatCanHoldItems() {
        assertEquals(Kind.CHECKLIST, parseKind("checklist")); assertEquals(Kind.BOOKS, parseKind(" BOOKS "))
        assertNull(parseKind("nonsense")); assertNull(parseKind(null))
        Kind.entries.filter { it.hasOwnPage }.forEach { assertNull(parseKind(it.name)) }
    }

    @Test fun importedItemsKeepOrderTicksAndValidScrapIds() {
        val l = BinderList(name = "C", kind = Kind.CHECKLIST)
        val items = importedItems(l, listOf("a", "  ", "b"), listOf(false, false, true), listOf("", "x", "abcdef12-0000"))
        assertEquals(listOf("a", "b"), items.map { it.title })
        assertEquals(listOf(l.startStage, l.endStage), items.map { it.stage })
        assertEquals(listOf("", "abcdef12-0000"), items.map { it.scrap })
    }

    @Test fun aBookThatIsDoneEndsAtItsLastStatus() {
        val l = BinderList(name = "B", kind = Kind.BOOKS)
        assertEquals(l.endStage, importedItems(l, listOf("x"), listOf(true), emptyList())[0].stage)
        assertEquals(l.startStage, importedItems(l, listOf("x"), emptyList(), emptyList())[0].stage)
    }

    @Test fun theScrapLinkSurvivesSaving() {
        val l = BinderList(name = "M", kind = Kind.MOVIES, items = listOf(Item(id = "i1", title = "T", scrap = "abcdef12-0000"), Item(id = "i2", title = "U")))
        val back = parseLists(listsToJson(listOf(l)).toString()).single().items
        assertEquals("abcdef12-0000", back[0].scrap); assertEquals("", back[1].scrap)
    }
}
