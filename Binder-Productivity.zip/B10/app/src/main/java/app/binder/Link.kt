package app.binder

import java.net.URLEncoder
import java.util.Locale
import java.util.UUID

// WORKING TOGETHER WITH SCRAPBOOK
//
// Scrapbook (package app.scrapbook) is the notes app of the same family. The two apps keep their own data and talk through links and explicit
// intents, so each one works alone and the other is simply absent when it is not installed. This file is only the rules; the Android side is
// Bridge.kt and Scrapbook.kt. The same rules are written down in Scrapbook's Binder.kt:
//
//   binder://item/<id>, binder://bind/<id>           open an item / a bind here (the id is the item's or bind's permanent id)
//   scrapbook://scrap/<uid>                          open a scrap in Scrapbook
//   scrapbook://scrap/<uid>?binder=<id>&title=<t>    opens the scrap AND makes Scrapbook add a link to that item at its end (sent after "Add to Binder")
//   action app.binder.action.ADD                     Scrapbook asks Binder to add one item:   title, note, scrap (the scrap's uid)
//   action app.binder.action.IMPORT                  Scrapbook asks Binder to make a bind:    name, kind (optional), items, done (optional), scraps (optional)
//   action app.scrapbook.action.CREATE               Binder asks Scrapbook to make a scrap:   title, body, uid, box, a cover picture in EXTRA_STREAM
//
// Binder chooses the uid of a scrap it asks for, so the item can store the link at once; Scrapbook makes the scrap with exactly that uid.

const val SCRAPBOOK_PACKAGE = "app.scrapbook"
const val SCRAPBOOK_ACTIVITY = "app.scrapbook.MainActivity"
const val ACTION_ADD = "app.binder.action.ADD"
const val ACTION_IMPORT = "app.binder.action.IMPORT"
const val ACTION_SCRAPBOOK_CREATE = "app.scrapbook.action.CREATE"

/** What a binder:// link points at: [kind] is "item" or "bind". */
class OpenRef(val kind: String, val id: String)

private val BINDER_URI = Regex("binder://(item|bind)/([A-Za-z0-9-]{8,64})/?", RegexOption.IGNORE_CASE)
private val UID = Regex("[A-Za-z0-9-]{8,64}")

fun parseBinderUri(url: String?): OpenRef? {
    val m = BINDER_URI.matchEntire(url?.trim() ?: return null) ?: return null
    return OpenRef(m.groupValues[1].lowercase(), m.groupValues[2])
}

fun scrapUrl(uid: String) = "scrapbook://scrap/$uid"

/** The link that takes you back to a scrap and makes Scrapbook add a link to this item there. */
fun bounceUrl(uid: String, itemId: String, title: String) =
    "scrapbook://scrap/$uid?binder=${URLEncoder.encode(itemId, "UTF-8")}&title=${URLEncoder.encode(title, "UTF-8")}"

/** A permanent id for a scrap, in Scrapbook's own form: 32 lowercase hex characters. */
fun newScrapUid(): String = UUID.randomUUID().toString().replace("-", "")

fun isScrapUid(s: String) = UID.matches(s)

/** A name that is safe inside [ ] of a link: brackets and line breaks become spaces. */
private fun labelOf(title: String) = title.replace(Regex("[\\[\\]\\n]+"), " ").trim().ifBlank { "item" }

/**
 * The text of the scrap "Write about this" makes: the item's details as bold labels, its description as a quote, a place to write, and the
 * link back to the item (which is how the scrap finds its way to it later).
 */
fun aboutBody(l: BinderList, item: Item, locale: Locale = Locale.getDefault()): String {
    val k = l.kind
    val rows = ArrayList<Pair<String, String>>()
    if (k.subLabel.isNotBlank() && item.sub.isNotBlank()) rows += k.subLabel to item.sub.trim()
    if (item.year.isNotBlank() && item.year != item.sub) rows += "Year" to item.year.trim()
    if (item.genre.isNotBlank()) rows += "Genre" to item.genre.trim()
    if (item.extra.isNotBlank()) rows += k.extraLabel to item.extra.trim()
    if (!k.isChecklist && !k.hasOwnPage) rows += "Status" to l.stageLabel(l.stageOf(item))
    formatRating(item.rating, locale).takeIf { it.isNotEmpty() }?.let { rows += "Rating" to "$it / ${RATING_MAX.toInt()}" }
    if (item.note.isNotBlank()) rows += "Note" to item.note.trim().replace('\n', ' ')
    val sb = StringBuilder()
    for ((a, b) in rows) sb.append("**").append(a).append(":** ").append(b).append('\n')
    if (rows.isNotEmpty()) sb.append('\n')
    if (item.description.isNotBlank()) { for (line in item.description.trim().take(600).lines()) sb.append("> ").append(line).append('\n'); sb.append('\n') }
    sb.append("## My thoughts\n\n\nBinder: [").append(labelOf(item.title)).append("](binder://item/").append(item.id).append(')')
    return sb.toString()
}

/** The kind named in an import, if it is one a bind can start as (not the binds with a page of their own). */
fun parseKind(name: String?): Kind? = Kind.entries.firstOrNull { it.name.equals(name?.trim(), ignoreCase = true) }?.takeIf { !it.hasOwnPage }

/**
 * The items an import makes in bind [l], in order: blank titles are skipped, a ticked one starts at the bind's last status (done) and the others
 * at its first, and a scrap id (the same position in [scraps]) is kept when it looks like one. At most 500.
 */
fun importedItems(l: BinderList, titles: List<String>, done: List<Boolean>, scraps: List<String>): List<Item> =
    titles.take(500).mapIndexedNotNull { i, t ->
        val title = t.trim()
        if (title.isEmpty()) null
        else Item(title = title, scrap = scraps.getOrNull(i)?.trim()?.takeIf { isScrapUid(it) }.orEmpty(), stage = if (done.getOrNull(i) == true) l.endStage else l.startStage)
    }
