package app.binder

// The plain maths of a Productivity bind (no Compose, so it can be tested on a normal JVM). The screens are in Productivity.kt.
//
// An entry is an Item: title = what you worked on, note = the description, sub = the mood (the name of one of Moods),
// stage = the workflow stage (0 Plan, 1 Doing, 2 Review, 3 Done), added = when it was logged.
// Nothing new is saved in the file, so backups and older files need nothing new.

class Mood(val name: String, val emoji: String)

/** The moods you can pick on an entry, in the order they are shown. */
val Moods = listOf(
    Mood("Focused", "🎯"),
    Mood("Calm", "😌"),
    Mood("Energized", "⚡"),
    Mood("Anxious", "😰"),
    Mood("Stressed", "😖"),
)

/** Plan, Doing, Review, Done: the workflow every entry moves through. */
val WorkStages: List<String> get() = Kind.PRODUCTIVITY.stages

/** Which of [Moods] this entry has; -1 when it has none (or one that is no longer offered). */
fun Item.moodIndex(): Int = Moods.indexOfFirst { it.name == sub }

fun Item.moodEmoji(): String = Moods.getOrNull(moodIndex())?.emoji ?: "📝"

fun Item.workStage(): Int = stage.coerceIn(0, WorkStages.lastIndex)

fun Item.isFinished(): Boolean = workStage() == WorkStages.lastIndex

/** The stage after this one; after the last one it starts over at the first. */
fun nextWorkStage(stage: Int): Int = (stage.coerceIn(0, WorkStages.lastIndex) + 1) % WorkStages.size

// ───────── days and streaks ─────────

/** The day numbers (see epochDay) on which at least one entry was logged. */
fun loggedDays(items: List<Item>): Set<Int> = items.map { epochDay(it.added) }.toSet()

/** Days in a row with an entry, counted back from today. A today with nothing logged yet does not break the streak. */
fun entryStreak(days: Set<Int>, today: Int): Int {
    var d = if (today in days) today else today - 1
    var n = 0
    while (d in days) {
        n++
        d--
    }
    return n
}

/** The longest run of days in a row with an entry, ever. */
fun bestEntryStreak(days: Set<Int>): Int {
    var best = 0
    var run = 0
    var prev = 0
    var first = true
    for (d in days.sorted()) {
        run = if (!first && d == prev + 1) run + 1 else 1
        if (run > best) best = run
        prev = d
        first = false
    }
    return best
}

/** How far the streak ring is filled: the current streak against the best one. */
fun streakFraction(streak: Int, best: Int): Float =
    if (best <= 0) 0f else (streak.toFloat() / best).coerceIn(0f, 1f)

/** The title and the line under it on the streak card. */
fun streakText(streak: Int): Pair<String, String> = when {
    streak <= 0 -> "Start a new streak" to "Add an entry today to get going."
    streak >= 7 -> "You’ve been keeping track" to "You’ve added an entry every day for the past week."
    streak == 1 -> "Nice start" to "You’ve logged today. Come back tomorrow to keep it going."
    else -> "You’re on a roll" to "You’ve added an entry $streak days in a row."
}

/** The seven day numbers of the week that holds [today], when weeks start on [firstDow] (Calendar.firstDayOfWeek). */
fun weekOf(today: Int, firstDow: Int): List<Int> {
    val start = today - rowInWeek(today, firstDow)
    return (0..6).map { start + it }
}

enum class DayState { DONE, TODAY, MISSED, UPCOMING }

/** How one square of the week strip looks: ticked, today (nothing yet), missed, or still to come. */
fun dayState(day: Int, today: Int, days: Set<Int>): DayState = when {
    day in days -> DayState.DONE
    day == today -> DayState.TODAY
    day > today -> DayState.UPCOMING
    else -> DayState.MISSED
}

// ───────── lists of entries ─────────

/** The entries logged today, newest first. */
fun todaysEntries(items: List<Item>, now: Long): List<Item> {
    val today = epochDay(now)
    return items.filter { epochDay(it.added) == today }.sortedByDescending { it.added }
}

/** How many entries sit in each stage: Plan, Doing, Review, Done. */
fun stageCounts(items: List<Item>): List<Int> = WorkStages.indices.map { s -> items.count { it.workStage() == s } }

/** Share of the entries that have reached Done (0 when there are none). */
fun finishedFraction(items: List<Item>): Float =
    if (items.isEmpty()) 0f else items.count { it.isFinished() }.toFloat() / items.size

/** The entries with this mood (a [mood] of -1 keeps every entry), then those whose title, description or mood contain [q]. */
fun List<Item>.filtered(mood: Int, q: String): List<Item> = filter { mood < 0 || it.moodIndex() == mood }
    .filter { q.isBlank() || it.title.contains(q, true) || it.note.contains(q, true) || it.sub.contains(q, true) }

// ───────── a whole bind ─────────

/** How much of today's work is done: the ring on Home. */
fun productivityFraction(items: List<Item>, now: Long): Float = finishedFraction(todaysEntries(items, now))

/** The small line under the bind's name on Home: "2 today · 6 day streak". */
fun productivityLine(items: List<Item>, now: Long): String {
    if (items.isEmpty()) return "No entries yet"
    val streak = entryStreak(loggedDays(items), epochDay(now))
    val today = todaysEntries(items, now).size
    return if (streak > 0) "$today today · $streak day streak" else "$today today"
}

/** The big thing on a small card: the streak in days, "6d". */
fun productivityFace(items: List<Item>, now: Long): String = "${entryStreak(loggedDays(items), epochDay(now))}d"

/** The mood emoji of the latest entry (Home wears it), null when there are none or the bind is not a Productivity bind. */
fun BinderList.productivityEmoji(): String? =
    if (kind.isProductivity) items.maxByOrNull { it.added }?.moodEmoji() else null
