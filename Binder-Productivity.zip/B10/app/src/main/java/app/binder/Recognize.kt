package app.binder

import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Base64
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

// Song recognition for a Heard bind. Plain Kotlin (no Android classes), so it is tested on a normal JVM.
//
// The pipeline has two steps, and each one is a chain, so the bind keeps working when one source stops:
//   1. a recognizer listens to the clip and names the song:   AudD first, ACRCloud if that can't, (ShazamKit could be added here)
//   2. the details (cover, album, year, link) come from the song search chain:   Apple Music first, Deezer if that can't (see Songs.kt)

/** A song a recognizer heard, before it becomes an item in a Heard bind. */
data class SongMatch(
    val title: String,
    val artist: String,
    val album: String = "",
    val year: String = "",
    val genre: String = "",
    val coverUrl: String = "",     // full-size picture (saved on the phone)
    val thumbUrl: String = "",     // small picture for the result card
    val url: String = "",          // where the song opens: Apple Music or Deezer when known, otherwise some other link
    val sourceName: String = "",   // the label of the Source [url] belongs to ("Apple Music", "Deezer"); "" for any other link
    val sourceId: String = "",
    val matchedBy: String = "",    // the recognizer that heard it: "AudD", "ACRCloud"
)

/** Sends a multipart form with one file and returns the answer as text. Http.postMultipart in the app, a fake in tests. */
typealias Upload = (url: String, fields: Map<String, String>, fileField: String, fileName: String, bytes: ByteArray) -> String

internal val realUpload: Upload = { url, fields, field, name, bytes -> Http.postMultipart(url, fields, field, name, bytes) }

/** A year from a date like "2014-09-18"; "" when it doesn't start with four digits. */
internal fun cleanYear(s: String): String = s.trim().take(4).takeIf { it.length == 4 && it.all(Char::isDigit) } ?: ""

/** Lower case letters and digits only, so "Here Comes The Sun (Remastered)" and "here comes the sun - remastered" compare equal. */
internal fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

interface SongRecognizer {
    val name: String
    /** False when this build has no key for it; it is then skipped. */
    val ready: Boolean
    /** The song in [wav] (a WAV file), or null when it isn't recognised. Throws [FetchFailure] when the service can't be asked. */
    fun identify(wav: ByteArray): SongMatch?
}

// ───────── AudD ─────────
// https://docs.audd.io  ·  POST https://api.audd.io/ with api_token and the clip as the "file" field; "return" asks for Apple Music and Deezer
// data too. The answer is {"status":"success","result":{artist,title,album,release_date,song_link,apple_music:{...},deezer:{...}}};
// result is null when nothing matched. One key, like TMDB_KEY and RAWG_KEY. Paid beyond a short trial: check dashboard.audd.io.

class AuddRecognizer(
    private val key: () -> String = { Keys.audd },
    private val upload: Upload = realUpload,
) : SongRecognizer {
    override val name = "AudD"
    override val ready: Boolean get() = key().isNotBlank()

    override fun identify(wav: ByteArray): SongMatch? =
        parse(upload("https://api.audd.io/", mapOf("api_token" to key(), "return" to "apple_music,deezer"), "file", "clip.wav", wav))

    companion object {
        fun parse(json: String): SongMatch? {
            val o = JSONObject(json)
            if (o.optString("status") == "error") {
                val code = o.optJSONObject("error")?.optInt("error_code", 0) ?: 0
                throw FetchFailure(
                    when (code) {
                        901 -> "AudD has no requests left for this key."
                        900 -> "AudD doesn't accept this key."
                        else -> "AudD couldn't read the clip."
                    }
                )
            }
            val r = o.optJSONObject("result") ?: return null
            val title = r.str("title").trim()
            if (title.isEmpty()) return null
            val apple = r.optJSONObject("apple_music")
            val deezer = r.optJSONObject("deezer")
            val appleUrl = apple?.str("url").orEmpty()
            val deezerUrl = deezer?.str("link").orEmpty()
            val art = apple?.optJSONObject("artwork")?.str("url").orEmpty() // ends in {w}x{h}bb.jpeg: any size can be asked for
            val genre = apple?.optJSONArray("genreNames")
                ?.let { g -> (0 until g.length()).map { g.optString(it) }.firstOrNull { it.isNotBlank() && it != "Music" } }
                .orEmpty()
            val deezerAlbum = deezer?.optJSONObject("album")
            val cover = if (art.isNotEmpty()) art.replace("{w}", "600").replace("{h}", "600") else deezerAlbum?.str("cover_xl").orEmpty()
            val thumb = if (art.isNotEmpty()) art.replace("{w}", "300").replace("{h}", "300") else deezerAlbum?.str("cover_medium").orEmpty()
            val (url, from) = when {
                appleUrl.isNotBlank() -> appleUrl to Source.APPLE.label
                deezerUrl.isNotBlank() -> deezerUrl to Source.DEEZER.label
                else -> r.str("song_link") to ""
            }
            return SongMatch(
                title = title,
                artist = r.str("artist").trim(),
                album = r.str("album").ifBlank { apple?.str("albumName").orEmpty() }.trim(),
                year = cleanYear(r.str("release_date").ifBlank { apple?.str("releaseDate").orEmpty() }),
                genre = genre,
                coverUrl = cover, thumbUrl = thumb, url = url, sourceName = from,
                sourceId = if (from == Source.APPLE.label) apple?.optJSONObject("playParams")?.str("id").orEmpty() else "",
            )
        }
    }
}

// ───────── ACRCloud ─────────
// https://docs.acrcloud.com/reference/identification-api  ·  POST https://{host}/v1/identify (multipart: sample, access_key, sample_bytes,
// timestamp, signature, data_type=audio, signature_version=1). The signature is base64(HMAC-SHA1(secret, "POST\n/v1/identify\n{key}\naudio\n1\n{timestamp}")).
// More setup than AudD (host, key and secret) but a free developer tier. It names the song; the cover comes from the details step.

class AcrCloudRecognizer(
    private val host: () -> String = { Keys.acrHost },
    private val key: () -> String = { Keys.acrKey },
    private val secret: () -> String = { Keys.acrSecret },
    private val now: () -> Long = { System.currentTimeMillis() / 1000 },
    private val upload: Upload = realUpload,
) : SongRecognizer {
    override val name = "ACRCloud"
    override val ready: Boolean get() = host().isNotBlank() && key().isNotBlank() && secret().isNotBlank()

    override fun identify(wav: ByteArray): SongMatch? {
        val ts = now().toString()
        val fields = mapOf(
            "access_key" to key(), "sample_bytes" to wav.size.toString(), "timestamp" to ts,
            "signature" to signature(key(), secret(), ts), "data_type" to "audio", "signature_version" to "1",
        )
        return parse(upload("https://${cleanHost(host())}/v1/identify", fields, "sample", "clip.wav", wav))
    }

    companion object {
        /** The bare address: "https://identify-eu-west-1.acrcloud.com/" and " identify-eu-west-1.acrcloud.com " both become identify-eu-west-1.acrcloud.com. */
        fun cleanHost(h: String): String = h.trim().removePrefix("https://").removePrefix("http://").trimEnd('/')

        fun signature(key: String, secret: String, timestamp: String): String {
            val toSign = "POST\n/v1/identify\n$key\naudio\n1\n$timestamp"
            val mac = Mac.getInstance("HmacSHA1")
            mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA1"))
            return Base64.getEncoder().encodeToString(mac.doFinal(toSign.toByteArray(Charsets.UTF_8)))
        }

        fun parse(json: String): SongMatch? {
            val o = JSONObject(json)
            when (o.optJSONObject("status")?.optInt("code", -1) ?: -1) {
                0 -> {}
                1001 -> return null // "no result": the service answered, it just doesn't know this one
                3001, 3002, 3014 -> throw FetchFailure("ACRCloud doesn't accept these keys.")
                3003 -> throw FetchFailure("ACRCloud's limit is reached.")
                else -> throw FetchFailure("ACRCloud couldn't read the clip.")
            }
            val m = o.optJSONObject("metadata")?.optJSONArray("music")?.optJSONObject(0) ?: return null
            val title = m.str("title").trim()
            if (title.isEmpty()) return null
            val artists = m.optJSONArray("artists")
            val artist = if (artists == null) "" else (0 until artists.length())
                .mapNotNull { artists.optJSONObject(it)?.str("name")?.takeIf { n -> n.isNotBlank() } }
                .joinToString(", ")
            val ext = m.optJSONObject("external_metadata")
            val deezerId = ext?.optJSONObject("deezer")?.optJSONObject("track")?.str("id").orEmpty()
            val spotifyId = ext?.optJSONObject("spotify")?.optJSONObject("track")?.str("id").orEmpty()
            val genre = m.optJSONArray("genres")?.optJSONObject(0)?.str("name").orEmpty()
            val (url, from) = when {
                deezerId.isNotBlank() -> "https://www.deezer.com/track/$deezerId" to Source.DEEZER.label
                spotifyId.isNotBlank() -> "https://open.spotify.com/track/$spotifyId" to ""
                else -> "" to ""
            }
            return SongMatch(
                title = title, artist = artist,
                album = m.optJSONObject("album")?.str("name").orEmpty().trim(),
                year = cleanYear(m.str("release_date")),
                genre = genre, url = url, sourceName = from,
                sourceId = if (from == Source.DEEZER.label) deezerId else "",
            )
        }
    }
}

// ───────── asking them in turn ─────────

/** What came of a listen. Nothing is ever saved from here: saving is always the person's own tap. */
sealed interface Outcome {
    data class Match(val song: SongMatch) : Outcome
    /** At least one service answered and none of them knows the clip. */
    data object NoMatch : Outcome
    /** This build has no recognition key at all. */
    data object NoKeys : Outcome
    data object Offline : Outcome
    /** Every service that was asked failed (a limit, a bad key ...); the message is safe to show. */
    data class Failed(val message: String) : Outcome
}

class Recognition(private val recognizers: List<SongRecognizer>) {
    /** Asks each ready recognizer in turn until one names the song. A service that fails is skipped; no connection stops the whole round. */
    fun run(wav: ByteArray): Outcome {
        val ready = recognizers.filter { it.ready }
        if (ready.isEmpty()) return Outcome.NoKeys
        var answered = 0
        var failure: String? = null
        for (r in ready) {
            try {
                val m = r.identify(wav)
                if (m != null) return Outcome.Match(m.copy(matchedBy = r.name))
                answered++
            } catch (e: FetchFailure) {
                if (e.offline) return Outcome.Offline
                failure = e.message
            } catch (e: Exception) {
                failure = "${r.name} sent an answer Binder can't read."
            }
        }
        return if (answered > 0) Outcome.NoMatch else Outcome.Failed(failure ?: "Couldn't identify it.")
    }
}

/** The recognizers, in the order they are asked. To add another one (ShazamKit, say) write a SongRecognizer and list it here. */
object Recognizers {
    val chain: List<SongRecognizer> by lazy { listOf(AuddRecognizer(), AcrCloudRecognizer()) }
    fun ready(): List<SongRecognizer> = chain.filter { it.ready }
    fun pipeline(): Recognition = Recognition(chain)
}

// ───────── cover, album, year and a link ─────────

object SongLookup {
    /**
     * Fills in what a recognizer didn't bring (cover, album, year, a link to open) from the song search chain
     * (Apple Music, then Deezer). Only a result with the same title (and artist) is used, so a wrong cover never gets attached.
     * If the search fails the match is returned as it was.
     */
    fun enrich(
        m: SongMatch,
        search: (String) -> List<Found> = { q -> Sources.forSource(Source.APPLE, Kind.HEARD).search(q) },
    ): SongMatch {
        val linked = m.url.isNotBlank() && m.sourceName.isNotBlank()
        if (linked && m.coverUrl.isNotBlank() && m.album.isNotBlank()) return m
        val hit = runCatching { best(search("${m.title} ${m.artist}".trim()), m) }.getOrNull() ?: return m
        return m.copy(
            album = m.album.ifBlank { hit.extra },
            year = m.year.ifBlank { hit.year },
            genre = m.genre.ifBlank { hit.genre },
            coverUrl = m.coverUrl.ifBlank { hit.coverUrl },
            thumbUrl = m.thumbUrl.ifBlank { hit.thumbUrl },
            url = if (linked) m.url else hit.sourceUrl.ifBlank { m.url },
            sourceName = if (linked) m.sourceName else hit.sourceName.ifBlank { m.sourceName },
            sourceId = if (linked) m.sourceId else hit.sourceId.ifBlank { m.sourceId },
        )
    }

    /** The first result with the same title and the same artist (or any artist, when none was heard). */
    fun best(list: List<Found>, m: SongMatch): Found? {
        val t = norm(m.title)
        val a = norm(m.artist)
        fun titleOk(f: Found): Boolean {
            val x = norm(f.title)
            return x.isNotEmpty() && t.isNotEmpty() && (x == t || x.startsWith(t) || t.startsWith(x))
        }
        fun artistOk(f: Found): Boolean {
            val x = norm(f.artist)
            return a.isEmpty() || (x.isNotEmpty() && (x.contains(a) || a.contains(x)))
        }
        return list.firstOrNull { titleOk(it) && artistOk(it) }
    }

    /** Finds the album a song sits on, as a result for an Albums bind: by the song's Apple link when it has one, otherwise by searching. */
    fun albumOf(
        album: String, artist: String, link: String,
        apple: MetadataProvider = Sources.forSource(Source.APPLE, Kind.ALBUMS),
    ): Found? {
        if (AppleLinks.parse(link) != null) {
            val viaLink = runCatching { apple.fromLink(link) }.getOrNull()
            if (viaLink != null) return viaLink
        }
        if (album.isBlank()) return null
        val a = norm(artist)
        val results = apple.search("$album $artist".trim())
        return results.firstOrNull { norm(it.title).startsWith(norm(album)) && (a.isEmpty() || norm(it.artist).contains(a) || a.contains(norm(it.artist))) }
            ?: results.firstOrNull { norm(it.title).startsWith(norm(album)) }
    }
}

// ───────── the clip ─────────

object Wav {
    const val RATE = 16_000

    /** Wraps raw 16-bit mono PCM in a WAV header (44 bytes). */
    fun pack(pcm: ByteArray, sampleRate: Int = RATE): ByteArray {
        val b = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray(Charsets.US_ASCII))
        b.putInt(36 + pcm.size)
        b.put("WAVE".toByteArray(Charsets.US_ASCII))
        b.put("fmt ".toByteArray(Charsets.US_ASCII))
        b.putInt(16)
        b.putShort(1)                 // PCM
        b.putShort(1)                 // mono
        b.putInt(sampleRate)
        b.putInt(sampleRate * 2)      // bytes a second
        b.putShort(2)                 // bytes a frame
        b.putShort(16)                // bits a sample
        b.put("data".toByteArray(Charsets.US_ASCII))
        b.putInt(pcm.size)
        b.put(pcm)
        return b.array()
    }

    /** How loud the first [n] bytes of 16-bit little-endian PCM are, 0 (silence) to 1; made a bit livelier so speech and music fill the bars. */
    fun level(pcm: ByteArray, n: Int): Float {
        val count = n / 2
        if (count <= 0) return 0f
        var sum = 0.0
        for (i in 0 until count) {
            val s = ((pcm[2 * i + 1].toInt() shl 8) or (pcm[2 * i].toInt() and 0xFF)).toShort().toInt()
            sum += s.toDouble() * s
        }
        val rms = Math.sqrt(sum / count) / 32768.0
        return (rms * 5.0).coerceIn(0.0, 1.0).toFloat()
    }
}
