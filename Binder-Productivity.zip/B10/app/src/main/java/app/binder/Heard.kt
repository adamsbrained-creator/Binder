package app.binder

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// A Heard bind (Kind.HEARD): a song finder. Two tabs, Listen and Songs.
//   Listen: one big button; it listens for about ten seconds, then shows what it found (cover, title, artist, album, year) with
//           Save, Try again and Open in Apple Music. Nothing is saved until you tap Save, and a miss never saves anything.
//   Songs:  every saved song, grouped by day like Tracker's History; swipe left to delete (with Undo), swipe right or tap to edit.
// The naming is done by the recognizers in Recognize.kt (AudD, then ACRCloud), the cover and details by Songs.kt (Apple Music, then Deezer).
// Every song is a plain Item (see Kind.HEARD), so backups and older files need nothing new.

private const val CLIP_SECONDS = 10
private const val BARS = 15

private fun fmt(p: String, ms: Long) = SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))
private fun timeOf(ms: Long) = fmt("h:mm a", ms)

private fun dayName(start: Long, now: Long): String = when (start) {
    startOfDay(now) -> "Today"
    startOfDay(now, -1) -> "Yesterday"
    else -> fmt("EEE, MMM d", start)
}

// ───────── the microphone ─────────

class MicUnavailable : Exception("The microphone couldn't be opened.")

/** Records [seconds] of sound from the microphone as a 16 kHz mono WAV. Blocking: always call it off the main thread. */
class ClipRecorder(private val seconds: Int = CLIP_SECONDS) {
    @Volatile private var cancelled = false

    fun cancel() { cancelled = true }

    /**
     * Returns the WAV, or null if [cancel] was called. [onTick] gets the loudness (0..1) and the seconds left, about ten times a second.
     * Throws [MicUnavailable] when the microphone can't be opened (another app has it) or stops early.
     */
    @SuppressLint("MissingPermission") // the screen asks for RECORD_AUDIO before it starts this
    fun record(onTick: (Float, Int) -> Unit): ByteArray? {
        val rate = Wav.RATE
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) throw MicUnavailable()
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, rate))
        } catch (e: Exception) {
            throw MicUnavailable()
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw MicUnavailable()
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            throw MicUnavailable()
        }
        val out = ByteArrayOutputStream()
        val buf = ByteArray(rate / 10 * 2) // 100 ms
        val total = rate * 2 * seconds
        try {
            while (!cancelled && out.size() < total) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) break
                out.write(buf, 0, n)
                val left = Math.ceil((total - out.size()) / (rate * 2.0)).toInt().coerceAtLeast(0)
                onTick(Wav.level(buf, n), left)
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
        if (cancelled) return null
        if (out.size() < rate * 2 * 2) throw MicUnavailable() // under two seconds: the microphone gave up
        return Wav.pack(out.toByteArray(), rate)
    }
}

// ───────── what the Listen tab is doing ─────────

sealed interface Phase {
    data object Idle : Phase
    data object Listening : Phase
    data object Matching : Phase
    data class Found(val song: SongMatch) : Phase
    /** Couldn't identify it, no connection, no key ... : a message and Try again. Nothing was saved. */
    data class Miss(val title: String, val body: String) : Phase
    /** Fetching is off in Settings, and listening needs it (the clip is sent to the recognizer). */
    data object NeedFetch : Phase
    /** The microphone permission was refused. */
    data object NeedMic : Phase
}

class ListenSession {
    var phase by mutableStateOf<Phase>(Phase.Idle)
    var levels by mutableStateOf(List(BARS) { 0f })
    var secondsLeft by mutableStateOf(CLIP_SECONDS)
    var recorder: ClipRecorder? = null
    var job: Job? = null

    fun tick(level: Float, left: Int) {
        levels = levels.drop(1) + level
        secondsLeft = left
    }
}

// ───────── small pieces ─────────

@Composable
fun ListenDot(modifier: Modifier = Modifier, size: Dp = 40.dp, onClick: () -> Unit) {
    Box(modifier.size(size).clip(CircleShape).background(Coral).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(Ic.Mic, "Listen", tint = Color(0xFF111111), modifier = Modifier.size(size * 0.5f))
    }
}

/** What a Heard bind wears on Home in place of the progress ring: five little sound bars. */
@Composable
fun WaveMark(size: Dp = 44.dp) {
    Row(
        Modifier.size(size), horizontalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        listOf(10, 20, 28, 16, 8).forEach { h ->
            Box(Modifier.width(4.dp).height((h * size.value / 44f).dp).clip(RoundedCornerShape(2.dp)).background(Coral))
        }
    }
}

@Composable
private fun SongCover(url: String, title: String, size: Dp, radius: Dp) {
    val bmp = rememberRemoteImage(url, 400)
    Box(Modifier.size(size)) {
        ArtBox(Art(coverFor(title)), Modifier.size(size), radius)
        if (bmp != null) Image(bmp, null, Modifier.size(size).clip(RoundedCornerShape(radius)), contentScale = ContentScale.Crop)
    }
}

@Composable
private fun OptionChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).background(if (on) P.primary else P.surface)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp)
    ) { Txt(label, 14, if (on) P.onPrimary else P.fg) }
}

@Composable
private fun SoftButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(52.dp).clip(CircleShape).background(P.surface).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Txt(text, 15, maxLines = 1) }
}

/** The big round button with two soft rings. [active] makes the rings breathe. */
@Composable
private fun ListenCircle(active: Boolean, onClick: (() -> Unit)?) {
    val t = rememberInfiniteTransition(label = "listen")
    val pulse by t.animateFloat(1f, 1.07f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    val k = if (active) pulse else 1f
    Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(290.dp).graphicsLayer { scaleX = k; scaleY = k }.border(1.5.dp, Coral.copy(alpha = 0.14f), CircleShape))
        Box(Modifier.size(232.dp).graphicsLayer { scaleX = k; scaleY = k }.border(1.5.dp, Coral.copy(alpha = 0.28f), CircleShape))
        Box(
            Modifier.size(170.dp).clip(CircleShape).background(Coral)
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
            contentAlignment = Alignment.Center,
        ) { Icon(Ic.Mic, "Listen", tint = Color(0xFF111111), modifier = Modifier.size(60.dp)) }
    }
}

@Composable
private fun Wave(levels: List<Float>) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).padding(top = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        levels.forEach { v -> Box(Modifier.width(5.dp).height((10 + 44 * v.coerceIn(0f, 1f)).dp).clip(RoundedCornerShape(3.dp)).background(Coral)) }
    }
}

@Composable
private fun BigCaption(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Txt(title, 28, align = TextAlign.Center)
        Txt(body, 15, P.mute, Modifier.padding(top = 6.dp), align = TextAlign.Center)
    }
}

/** Which sources do the work, and what is sent. */
@Composable
private fun SourcesCard(matching: Boolean) {
    val names = Recognizers.ready().map { it.name }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(P.surface).padding(horizontal = 20.dp, vertical = 16.dp)) {
        if (names.isEmpty()) {
            Txt("No song recognition key in this build", 14)
            Txt("Add AUDD_KEY (and, as a backup, the three ACRCloud keys) and build again. The README says how.", 13, P.mute, Modifier.padding(top = 4.dp), lh = 20.sp)
        } else {
            Row {
                Txt(if (matching) "Matching with " else "Matches with ", 14)
                Txt(names.first(), 14, Coral, weight = FontWeight.Medium)
            }
            val backup = if (names.size > 1) "If it can't match, the next source tries (${names.drop(1).joinToString(", ")}). " else ""
            Txt(
                backup + "Cover and details come from Apple Music, then Deezer. A $CLIP_SECONDS-second clip is sent to match it.",
                13, P.mute, Modifier.padding(top = 4.dp), lh = 20.sp,
            )
        }
    }
}

// ───────── the page ─────────

@Composable
fun HeardScreen(vm: BinderViewModel, id: String) {
    val nav = vm.nav
    val o = vm.opts
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf(0) }
    val s = remember { ListenSession() }
    val l = vm.lists.firstOrNull { it.id == id }

    DisposableEffect(Unit) { onDispose { s.recorder?.cancel() } }

    fun begin() {
        val rec = ClipRecorder(CLIP_SECONDS)
        s.recorder = rec
        s.levels = List(BARS) { 0f }
        s.secondsLeft = CLIP_SECONDS
        s.phase = Phase.Listening
        s.job = scope.launch {
            val clip = try {
                withContext(Dispatchers.IO) { rec.record { level, left -> s.tick(level, left) } }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                s.phase = Phase.Miss("Can't use the microphone", "Another app may be using it. Try again in a moment. Nothing was saved.")
                return@launch
            }
            if (clip == null) { // Stop was pressed
                s.phase = Phase.Idle
                return@launch
            }
            s.phase = Phase.Matching
            val outcome = withContext(Dispatchers.IO) {
                val r = Recognizers.pipeline().run(clip)
                if (r is Outcome.Match) Outcome.Match(SongLookup.enrich(r.song)) else r
            }
            s.phase = when (outcome) {
                is Outcome.Match -> Phase.Found(outcome.song)
                Outcome.NoMatch -> Phase.Miss("Couldn't identify it", "Try again a little closer to the music. Nothing was saved.")
                Outcome.NoKeys -> Phase.Miss("Song matching isn't set up", "This build has no recognition key. Add AUDD_KEY (the README says how) and build again.")
                Outcome.Offline -> Phase.Miss("No connection", "Binder needs the internet to match a song. Nothing was saved.")
                is Outcome.Failed -> Phase.Miss("Couldn't identify it", "${outcome.message} Nothing was saved.")
            }
        }
    }

    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else s.phase = Phase.NeedMic
    }

    fun listen() {
        if (s.phase == Phase.Listening || s.phase == Phase.Matching) return
        if (!vm.opts.fetch) { s.phase = Phase.NeedFetch; return }
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
        else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    // the little mic on Home opens the bind and starts listening at once
    LaunchedEffect(id) {
        if (vm.listenOnOpen == id) {
            vm.listenOnOpen = null
            listen()
        }
        vm.retryPending(id) // songs typed while offline get their cover and details now
    }

    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val add: () -> Unit = { if (o.add != AddStyle.SHEET) nav.push(Route.ItemEdit(l.id, null)) else vm.quick = l.id }

    Box(Modifier.fillMaxSize()) {
        Screen {
            Header2(
                l.name, l.countLabel(), onBack = { nav.pop() },
                right = {
                    CircleBtn(Ic.Dots, "${o.list} options") {
                        vm.sheet = SheetData(
                            l.name,
                            listOf(
                                Act("Search for a song") { add() },
                                Act(if (l.pinned) "Unpin" else "Pin to top") { vm.togglePin(l.id) },
                                Act("Rename") { vm.rename = l },
                                Act("Delete ${o.listLower}", danger = true) { vm.deleteList(l); nav.pop() },
                            ),
                        )
                    }
                },
            )
            Seg(listOf("Listen", "Songs"), tab, Modifier.padding(top = 6.dp, bottom = 4.dp)) { tab = it }
            if (tab == 0) {
                ListenTab(vm, l, s, onListen = { listen() }, onSaved = { s.phase = Phase.Idle; tab = 1 })
            } else {
                SongsTab(vm, l, onListen = { tab = 0 })
            }
        }
        if (tab == 0 && s.phase == Phase.Listening) {
            Box(Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 16.dp, bottom = 34.dp)) {
                Pill("Stop") { s.recorder?.cancel() }
            }
        }
        MenuFab(vm, onAdd = add, onAddHold = add, addLabel = "Add song")
    }
}

// ───────── Listen ─────────

@Composable
private fun ColumnScope.ListenTab(vm: BinderViewModel, l: BinderList, s: ListenSession, onListen: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 120.dp)) {
        when (val p = s.phase) {
            Phase.Idle -> {
                ListenCircle(false, onListen)
                BigCaption("Tap to listen", "Hold your phone near the music")
                Spacer(Modifier.height(24.dp))
                SourcesCard(false)
            }
            Phase.Listening -> {
                ListenCircle(true, null)
                BigCaption("Listening…", "Hold your phone near the music · ${s.secondsLeft}s")
                Wave(s.levels)
                Spacer(Modifier.height(20.dp))
                SourcesCard(true)
            }
            Phase.Matching -> {
                ListenCircle(true, null)
                BigCaption("Matching…", "Checking the sources")
                Wave(List(BARS) { 0.1f })
                Spacer(Modifier.height(20.dp))
                SourcesCard(true)
            }
            is Phase.Found -> FoundCard(vm, l, p.song, onTryAgain = onListen, onSaved = onSaved)
            is Phase.Miss -> {
                Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Txt(p.title, 24, font = TitleFont, align = TextAlign.Center)
                    Txt(p.body, 14, P.mute, Modifier.padding(top = 6.dp, bottom = 24.dp, start = 16.dp, end = 16.dp), align = TextAlign.Center)
                    Pill("Try again", filled = true) { onListen() }
                }
            }
            Phase.NeedFetch -> {
                Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Txt("Fetching is off", 24, font = TitleFont, align = TextAlign.Center)
                    Txt(
                        "To name a song, Binder sends a short clip of sound to a recognition service. Turn on Fetch details to allow that.",
                        14, P.mute, Modifier.padding(top = 6.dp, bottom = 24.dp, start = 16.dp, end = 16.dp), align = TextAlign.Center,
                    )
                    Pill("Turn on fetching", filled = true) { vm.change { it.copy(fetch = true) }; s.phase = Phase.Idle }
                }
            }
            Phase.NeedMic -> {
                Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Txt("The microphone is off", 24, font = TitleFont, align = TextAlign.Center)
                    Txt(
                        "Binder only listens when you tap the button. Allow the microphone for Binder in the phone's settings.",
                        14, P.mute, Modifier.padding(top = 6.dp, bottom = 24.dp, start = 16.dp, end = 16.dp), align = TextAlign.Center,
                    )
                    Pill("Open settings", filled = true) {
                        runCatching {
                            ctx.startActivity(
                                Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FoundCard(vm: BinderViewModel, l: BinderList, song: SongMatch, onTryAgain: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    var note by remember(song) { mutableStateOf("") }
    var rating by remember(song) { mutableStateOf(0f) }
    var showNote by remember(song) { mutableStateOf(false) }
    var showRating by remember(song) { mutableStateOf(false) }
    var withAlbum by remember(song) { mutableStateOf(false) }
    var saving by remember(song) { mutableStateOf(false) }
    val albums = vm.lists.filter { it.kind == Kind.ALBUMS }.maxByOrNull { it.activity() }
    val canAlbum = albums != null && song.album.isNotBlank() && !hasAlbum(albums, song.album, song.artist)
    val dup = findHeard(l.items, song.title, song.artist)
    val now = System.currentTimeMillis()

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(P.surface).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            SongCover(song.thumbUrl.ifBlank { song.coverUrl }, song.title, 104.dp, 18.dp)
            Column(Modifier.weight(1f)) {
                Txt("FOUND IT", 13, P.mute, ls = 0.06.em)
                Txt(song.title, 24, modifier = Modifier.padding(vertical = 4.dp), maxLines = 3, lh = 28.sp)
                if (song.artist.isNotBlank()) Txt(song.artist, 15, P.mute, maxLines = 1)
                val more = listOf(song.album, song.year).filter { it.isNotBlank() }.joinToString(" · ")
                if (more.isNotEmpty()) Txt(more, 14, P.mute, maxLines = 2)
            }
        }
        val via = "Matched by ${song.matchedBy}" + if (song.sourceName.isNotBlank()) " · details from ${song.sourceName}" else ""
        Txt(via, 13, P.mute, Modifier.padding(top = 16.dp))
        if (dup != null) {
            Txt("Already in ${l.name} · ${dayName(startOfDay(dup.added), now).lowercase()}", 13, Coral, Modifier.padding(top = 6.dp))
        }
    }
    FlowRow(
        Modifier.fillMaxWidth().padding(top = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        OptionChip("Note", showNote) { showNote = !showNote }
        OptionChip("Rating", showRating) { showRating = !showRating }
        if (canAlbum && albums != null) OptionChip("Add album to ${albums.name}", withAlbum) { withAlbum = !withAlbum }
    }
    if (showNote) Field("Note", note, Modifier.padding(top = 10.dp), singleLine = false) { note = it }
    if (showRating) Box(Modifier.padding(top = 10.dp, start = 4.dp)) { RatingInput(vm, rating) { rating = it } }
    Spacer(Modifier.height(16.dp))
    BigButton(if (saving) "Saving…" else if (dup != null) "Save again" else "Save to ${l.name}") {
        if (!saving) {
            saving = true
            vm.saveSong(l.id, song, note, rating, if (withAlbum && albums != null) albums.id else null) { onSaved() }
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SoftButton("Try again", Modifier.weight(1f), onTryAgain)
        if (song.url.isNotBlank()) SoftButton(song.openLabel(), Modifier.weight(1f)) { openLink(ctx, song.url) }
    }
}

// ───────── Songs ─────────

@Composable
private fun ColumnScope.SongsTab(vm: BinderViewModel, l: BinderList, onListen: () -> Unit) {
    if (l.items.isEmpty()) {
        EmptyBlock("No songs yet", "Listen to a song and keep it, or search for one to add.", "Listen", onListen)
        return
    }
    val now = System.currentTimeMillis()
    val groups = heardByDay(l.items)
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 110.dp)) {
        groups.forEach { (day, list) ->
            item(key = "day$day") { Cap(dayName(day, now).uppercase(), Modifier.padding(start = 4.dp)) }
            items(list, key = { it.id }) { e ->
                val edit = { vm.nav.push(Route.ItemEdit(l.id, e.id)) }
                Box(Modifier.padding(bottom = 8.dp)) {
                    SwipeRow(true, "Edit", "Delete", onRight = { edit() }, onLeft = { vm.deleteItem(l.id, e) }) {
                        Row(
                            Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(22.dp)).background(P.surface)
                                .clickable { edit() }.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            ArtBox(e.art(), Modifier.size(52.dp), 12.dp, 150)
                            Column(Modifier.weight(1f)) {
                                Txt(e.title, 17, maxLines = 1)
                                Txt(e.songLine(), 14, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                            }
                            Txt(timeOf(e.added), 13, P.mute)
                        }
                    }
                }
            }
        }
        item { Txt("Swipe left on a song to delete it", 12, P.mute, Modifier.fillMaxWidth().padding(top = 8.dp), align = TextAlign.Center) }
    }
}

// ───────── one song (edit, or add by hand) ─────────

@Composable
fun SongScreen(vm: BinderViewModel, listId: String, itemId: String?) {
    val nav = vm.nav
    val ctx = LocalContext.current
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.items?.firstOrNull { it.id == itemId }
    var title by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var artist by rememberSaveable { mutableStateOf(existing?.sub ?: "") }
    var album by rememberSaveable { mutableStateOf(existing?.extra ?: "") }
    var note by rememberSaveable { mutableStateOf(existing?.note ?: "") }
    var rating by rememberSaveable { mutableStateOf(existing?.rating ?: 0f) }
    var albumAdded by remember { mutableStateOf(false) }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val albums = vm.lists.filter { it.kind == Kind.ALBUMS }.maxByOrNull { it.activity() }
    val canAlbum = albums != null && album.isNotBlank() && !albumAdded && !hasAlbum(albums, album, artist)

    Screen {
        Header2(
            if (existing == null) "New song" else "Song", l.name, onBack = { nav.pop() },
            right = { if (existing != null) CircleBtn(Ic.Close, "Delete song") { vm.deleteItem(l.id, existing); nav.pop() } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            if (existing != null) {
                Box(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp), contentAlignment = Alignment.Center) {
                    ArtBox(existing.art(), Modifier.size(200.dp), 24.dp, 600)
                }
                val facts = listOf(existing.year, existing.genre).filter { it.isNotBlank() }.joinToString(" · ")
                if (facts.isNotEmpty()) Txt(facts, 13, P.mute, Modifier.fillMaxWidth().padding(bottom = 8.dp), align = TextAlign.Center)
            }
            Field("Song", title, Modifier.padding(top = 6.dp)) { title = it }
            Field("Artist", artist, Modifier.padding(top = 8.dp)) { artist = it }
            Field("Album", album, Modifier.padding(top = 8.dp)) { album = it }
            Cap("NOTE", Modifier.padding(start = 4.dp))
            Field("Optional", note, singleLine = false) { note = it }
            Cap("RATING", Modifier.padding(start = 4.dp))
            Box(Modifier.padding(start = 4.dp)) { RatingInput(vm, rating) { rating = it } }
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val url = existing?.sourceUrl.orEmpty()
                if (existing != null && url.isNotBlank()) SoftButton(existing.openLabel(), Modifier.weight(1f)) { openLink(ctx, url) }
                if (canAlbum && albums != null) {
                    SoftButton("Add album to ${albums.name}", Modifier.weight(1f)) {
                        albumAdded = true
                        vm.addAlbumOf(albums.id, album, artist, url)
                    }
                }
            }
            if (albumAdded) Txt("Album added", 13, P.mute, Modifier.padding(start = 4.dp, top = 8.dp))
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Save song", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            if (title.isNotBlank()) {
                val item = (existing ?: Item(title = "")).copy(title = title.trim(), sub = artist.trim(), extra = album.trim(), note = note.trim(), rating = rating)
                vm.saveItem(l.id, item)
                nav.pop()
            }
        }
    }
}

/** The "Each song has" part of the New bind page, shown when Heard is picked. */
@Composable
fun HeardHas(note: String) {
    Txt(note, 12, P.mute, Modifier.padding(start = 4.dp, top = 10.dp))
    Cap("EACH SONG HAS")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Triple("🎧", "Title and artist", "from the clip"), Triple("💿", "Cover and album", "Apple Music, Deezer"), Triple("📝", "Note and rating", "optional")).forEach { (icon, title, value) ->
            Row(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(22.dp)).background(P.surface).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { Txt(icon, 20) }
                Txt(title, 16, modifier = Modifier.weight(1f))
                Txt(value, 14, P.mute)
            }
        }
    }
}
