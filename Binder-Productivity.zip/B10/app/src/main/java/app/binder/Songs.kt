package app.binder

import org.json.JSONObject
import java.net.URLEncoder

// Song search for a Heard bind: Apple Music (the iTunes Search API), Deezer as the backup, and a chain that asks them in turn.
// Neither needs a key. They give covers and details for a recognised song, and they are what typing a title in Quick add searches.

// ───────── Apple Music, songs ─────────

class AppleSongProvider(
    private val get: (String) -> String = Http::get,
    private val gate: RateGate = RateGate(15, 60_000), // Apple allows about 20 a minute
) : MetadataProvider {
    override val source = Source.APPLE

    override fun search(query: String): List<Found> {
        val q = query.trim()
        if (q.length < 2) return emptyList()
        gate.check()
        val term = URLEncoder.encode(q, "UTF-8")
        return parse(get("https://itunes.apple.com/search?term=$term&entity=song&limit=10"))
    }

    // pasted music.apple.com links are read by AppleProvider (albums), which is also asked first for links
    override fun handlesLink(url: String): Boolean = false
    override fun fromLink(url: String): Found? = null

    companion object {
        /** Turns the JSON of a song search into results. Skips anything that isn't a song. Album name goes in [Found.extra]. */
        fun parse(json: String): List<Found> {
            val results = JSONObject(json).optJSONArray("results") ?: return emptyList()
            val out = ArrayList<Found>()
            for (i in 0 until results.length()) {
                val o = results.optJSONObject(i) ?: continue
                val id = o.optLong("trackId", 0L)
                val name = o.optString("trackName", "")
                if (id == 0L || name.isBlank()) continue
                if (o.has("kind") && o.optString("kind") != "song") continue
                val art = o.optString("artworkUrl100", "")
                out.add(
                    Found(
                        sourceName = Source.APPLE.label,
                        sourceId = id.toString(),
                        sourceUrl = o.optString("trackViewUrl", ""),
                        title = name,
                        artist = o.optString("artistName", ""),
                        year = cleanYear(o.optString("releaseDate", "")),
                        genre = o.optString("primaryGenreName", ""),
                        coverUrl = if (art.isEmpty()) "" else AppleProvider.artwork(art, 600),
                        thumbUrl = art,
                        extra = o.optString("collectionName", ""),
                    )
                )
            }
            return out
        }
    }
}

// ───────── Deezer ─────────
// https://developers.deezer.com/api/search  ·  GET https://api.deezer.com/search?q=… (no key; about 50 requests in 5 seconds)

object DeezerLinks {
    // deezer.com/track/3135556, deezer.com/en/track/3135556
    private val track = Regex("""deezer\.com/(?:[a-zA-Z-]{2,5}/)?track/(\d+)""")
    fun parse(url: String): String? = track.find(url.trim())?.groupValues?.get(1)
}

class DeezerProvider(
    private val get: (String) -> String = Http::get,
    private val gate: RateGate = RateGate(40, 5_000),
) : MetadataProvider {
    override val source = Source.DEEZER

    override fun search(query: String): List<Found> {
        val q = query.trim()
        if (q.length < 2) return emptyList()
        gate.check()
        val term = URLEncoder.encode(q, "UTF-8")
        return parse(get("https://api.deezer.com/search?q=$term&limit=10"))
    }

    override fun handlesLink(url: String): Boolean = DeezerLinks.parse(url) != null

    override fun fromLink(url: String): Found? {
        val id = DeezerLinks.parse(url) ?: return null
        gate.check()
        val o = JSONObject(get("https://api.deezer.com/track/$id"))
        if (o.has("error")) return null
        return track(o)
    }

    /** A search result carries no release date; the track itself does. */
    override fun details(f: Found): Found {
        if (f.year.isNotBlank() || f.sourceId.isBlank()) return f
        gate.check()
        val o = JSONObject(get("https://api.deezer.com/track/${f.sourceId}"))
        return f.copy(year = cleanYear(o.optString("release_date", "")))
    }

    companion object {
        /** One Deezer track object as a result; the album's name goes in [Found.extra]. Null when it has no id or title. */
        fun track(o: JSONObject): Found? {
            val id = o.optLong("id", 0L)
            val title = o.optString("title", "")
            if (id == 0L || title.isBlank()) return null
            val album = o.optJSONObject("album")
            return Found(
                sourceName = Source.DEEZER.label,
                sourceId = id.toString(),
                sourceUrl = o.optString("link", ""),
                title = title,
                artist = o.optJSONObject("artist")?.optString("name", "").orEmpty(),
                year = cleanYear(o.optString("release_date", "")),
                coverUrl = album?.str("cover_xl").orEmpty().ifBlank { album?.str("cover_big").orEmpty() },
                thumbUrl = album?.str("cover_medium").orEmpty(),
                extra = album?.str("title").orEmpty(),
            )
        }

        fun parse(json: String): List<Found> {
            val o = JSONObject(json)
            if (o.has("error")) throw FetchFailure("Deezer couldn't answer that.")
            val data = o.optJSONArray("data") ?: return emptyList()
            return (0 until data.length()).mapNotNull { data.optJSONObject(it)?.let { t -> track(t) } }
        }
    }
}

// ───────── the chain ─────────

/**
 * Asks several providers in turn and uses the first one that has results, so a source that is down, busy or empty
 * doesn't stop the search. [details] goes to the provider the result came from.
 */
class FallbackProvider(private val chain: List<MetadataProvider>) : MetadataProvider {
    override val source: Source = chain.first().source
    override val footer: String? =
        "Results from ${chain.first().source.label}" +
            (if (chain.size > 1) " · backup: ${chain.drop(1).joinToString(", ") { it.source.label }}" else "")

    override fun search(query: String): List<Found> {
        var answered = false
        var failure: FetchFailure? = null
        for (p in chain) {
            try {
                val r = p.search(query)
                if (r.isNotEmpty()) return r
                answered = true
            } catch (e: FetchFailure) {
                if (e.offline) throw e // no connection: the next one can't help either
                failure = e
            }
        }
        if (!answered && failure != null) throw failure
        return emptyList()
    }

    override fun handlesLink(url: String): Boolean = chain.any { it.handlesLink(url) }
    override fun fromLink(url: String): Found? = chain.firstOrNull { it.handlesLink(url) }?.fromLink(url)
    override fun details(f: Found): Found = chain.firstOrNull { it.source.label == f.sourceName }?.details(f) ?: f
    override val searchOnEnter: Boolean get() = false
}
