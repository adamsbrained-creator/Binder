package app.binder

// The plain parts of a Heard bind (no screen, no Android): what its card says, how its songs are grouped by day, and duplicates.
// See Heard.kt for the page.

/** The small line under a Heard bind's name on Home: "12 songs · Here Comes the Sun" (the song heard last), or a hint while it is empty. */
fun heardLine(items: List<Item>): String {
    if (items.isEmpty()) return "Nothing heard yet"
    val last = items.maxByOrNull { it.added } ?: return "Nothing heard yet"
    val count = "${items.size} ${if (items.size == 1) "song" else "songs"}"
    return if (last.title.isBlank()) count else "$count · ${last.title}"
}

/** Songs newest first, grouped by the day they were heard (the start of each day, newest day first). */
fun heardByDay(items: List<Item>): List<Pair<Long, List<Item>>> =
    items.sortedByDescending { it.added }.groupBy { startOfDay(it.added) }.toList()

/** The song already in the bind with this title and artist (compared without case, spaces or punctuation), or null. The newest one if several. */
fun findHeard(items: List<Item>, title: String, artist: String): Item? {
    val t = norm(title)
    val a = norm(artist)
    if (t.isEmpty()) return null
    return items.filter { norm(it.title) == t && norm(it.sub) == a }.maxByOrNull { it.added }
}

/** An Albums bind that already holds this album (same title, same artist). */
fun hasAlbum(albums: BinderList, album: String, artist: String): Boolean {
    val t = norm(album)
    val a = norm(artist)
    return t.isNotEmpty() && albums.items.any { norm(it.title) == t && (a.isEmpty() || norm(it.sub) == a) }
}

/** The line under a song's title: "The Beatles · Abbey Road" (whatever of the two is known). */
fun Item.songLine(): String = listOf(sub, extra).filter { it.isNotBlank() }.joinToString(" · ")

/** What a recognised song becomes in the bind. [cover] is the file name of the downloaded picture, if there is one. */
fun SongMatch.toSongItem(cover: String?, note: String = "", rating: Float = 0f): Item = Item(
    title = title, sub = artist, extra = album, year = year, genre = genre,
    images = listOfNotNull(cover), sourceName = sourceName, sourceId = sourceId, sourceUrl = url,
    note = note.trim(), rating = rating,
)

/** The label of the button that opens a song: "Open in Apple Music", "Open in Deezer", or just "Open link". */
fun Item.openLabel(): String = Sources.byLabel(sourceName)?.openLabel ?: "Open link"
fun SongMatch.openLabel(): String = Sources.byLabel(sourceName)?.openLabel ?: "Open link"
