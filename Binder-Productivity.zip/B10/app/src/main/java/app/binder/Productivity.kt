package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// A Productivity bind is a normal bind (Kind.PRODUCTIVITY) with its own page: Today / Workflow / All, and a "New entry" screen.
// Every entry is a plain Item (see Kind.PRODUCTIVITY and ProductivityLogic.kt), so old files and backups need nothing new.

private val MoodColors = listOf(Color(0xFF5CCB8A), Color(0xFF4C9BF0), Color(0xFFF5B83D), Color(0xFF9B8CFF), Color(0xFFF2874E))
private val StreakYellow = Color(0xFFF5B301)
private val CheckInk = Color(0xFF111111)

private fun moodColor(i: Int): Color = MoodColors.getOrElse(i) { Color(0xFF9A9A9A) }

private fun pfmt(p: String, ms: Long) = SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))

private fun pTime(ms: Long) = pfmt("hh:mm a", ms)

private fun pDayTitle(start: Long, now: Long): String = when (start) {
    startOfDay(now) -> "Today"
    startOfDay(now, -1) -> "Yesterday"
    else -> pfmt("EEE, MMM d", start)
}

/** Three letters of a weekday, from a day number. */
private fun pWeekday(day: Int): String = DateFormatSymbols.getInstance(Locale.getDefault()).shortWeekdays[dowOf(day)].take(3)

private fun Item.pLine(): String = note.ifBlank { sub.ifBlank { "No description" } }

// ───────── small pieces ─────────

@Composable
private fun PCard(modifier: Modifier = Modifier, radius: Int = 28, content: @Composable () -> Unit) =
    Box(modifier.clip(RoundedCornerShape(radius.dp)).background(P.surface)) { content() }

/** The square with a mood's emoji on a wash of its colour. */
@Composable
private fun MoodTile(e: Item, size: Int = 40) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size * 0.35f).dp)).background(moodColor(e.moodIndex()).copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center,
    ) { Txt(e.moodEmoji(), (size * 0.55f).toInt()) }
}

/** A small rounded label, like "Doing". */
@Composable
private fun PTag(text: String, on: Boolean = false) {
    Box(Modifier.clip(RoundedCornerShape(10.dp)).background(if (on) Coral.copy(alpha = 0.22f) else P.bg).padding(horizontal = 9.dp, vertical = 4.dp)) {
        Txt(text, 12, P.fg, weight = FontWeight.Medium, maxLines = 1)
    }
}

/** The "Each entry has" part of the New bind page, shown when Productivity is picked. */
@Composable
fun ProductivityHas(note: String) {
    Txt(note, 12, P.mute, Modifier.padding(start = 4.dp, top = 10.dp))
    Cap("EACH ENTRY HAS")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Triple("🎯", "A mood", "5 moods"), Triple("✍️", "A description", "what you did"), Triple("🔁", "A workflow stage", "Plan to Done")).forEach { (icon, title, value) ->
            Row(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(22.dp)).background(P.surface).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { Txt(icon, 20) }
                Txt(title, 16, modifier = Modifier.weight(1f))
                Txt(value, 14, P.mute)
            }
        }
    }
}

// ───────── the bind page ─────────

@Composable
fun ProductivityScreen(vm: BinderViewModel, id: String) {
    val nav = vm.nav
    val o = vm.opts
    var tab by rememberSaveable { mutableStateOf(0) }
    var q by rememberSaveable { mutableStateOf("") }
    var mood by rememberSaveable { mutableStateOf(-1) }
    val l = vm.lists.firstOrNull { it.id == id }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val now = System.currentTimeMillis()
    val entries = l.items.sortedByDescending { it.added }
    val today = todaysEntries(entries, now)
    val add = { nav.push(Route.ItemEdit(l.id, null)) }

    Box(Modifier.fillMaxSize()) {
        Screen {
            Header2(
                l.name, if (entries.isEmpty()) "" else "${today.size} today", onBack = { nav.pop() },
                right = {
                    CircleBtn(Ic.Dots, "${o.list} options") {
                        vm.sheet = SheetData(
                            l.name,
                            listOf(
                                Act("Add entry") { add() },
                                Act(if (l.pinned) "Unpin" else "Pin to top") { vm.togglePin(l.id) },
                                Act("Rename") { vm.rename = l },
                                Act("Delete ${o.listLower}", danger = true) { vm.deleteList(l); nav.pop() },
                            ),
                        )
                    }
                },
            )
            Seg(listOf("Today", "Workflow", "All"), tab, Modifier.padding(top = 6.dp)) { tab = it }
            when (tab) {
                0 -> TodayTab(vm, l, entries, today, now, add) { tab = 2 }
                1 -> WorkflowTab(vm, l, entries, add)
                else -> AllTab(vm, l, entries, now, q, mood, add, { q = it }) { mood = it }
            }
        }
        MenuFab(vm, onAdd = add, onAddHold = add, addLabel = "New entry")
    }
}

private fun entryMenu(vm: BinderViewModel, l: BinderList, e: Item): SheetData = SheetData(
    e.title.ifBlank { "Entry" },
    listOf(
        Act("Edit") { vm.nav.push(Route.ItemEdit(l.id, e.id)) },
        Act("Move to ${WorkStages[nextWorkStage(e.stage)]}") { vm.saveItem(l.id, e.copy(stage = nextWorkStage(e.stage))) },
        Act("Delete", danger = true) { vm.deleteItem(l.id, e) },
    ),
)

// ───────── Today ─────────

@Composable
private fun WeekStrip(days: Set<Int>, today: Int) {
    val first = remember { Calendar.getInstance().firstDayOfWeek }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        weekOf(today, first).forEach { d ->
            val st = dayState(d, today, days)
            val isToday = d == today
            val shape = RoundedCornerShape(20.dp)
            Column(
                Modifier.weight(1f).height(66.dp).clip(shape).background(P.surface)
                    .border(2.dp, if (isToday) Coral else Color.Transparent, shape),
                verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Txt(pWeekday(d), 12, if (isToday) P.fg else P.mute, maxLines = 1, weight = if (isToday) FontWeight.Medium else FontWeight.Normal)
                val dot = Modifier.size(26.dp).clip(CircleShape)
                when (st) {
                    DayState.DONE -> Box(dot.background(StreakYellow), contentAlignment = Alignment.Center) {
                        Icon(Ic.Check, "Logged", tint = CheckInk, modifier = Modifier.size(15.dp))
                    }
                    DayState.TODAY -> Box(dot.border(2.dp, Coral, CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Coral))
                    }
                    DayState.MISSED -> Box(dot.background(P.line), contentAlignment = Alignment.Center) { Txt("–", 14, P.mute) }
                    DayState.UPCOMING -> Box(dot.border(2.dp, P.line, CircleShape))
                }
            }
        }
    }
}

@Composable
private fun StreakCard(streak: Int, best: Int) {
    val (title, line) = streakText(streak)
    val frac = streakFraction(streak, best)
    val track = P.line
    PCard(Modifier.fillMaxWidth(), 36) {
        Box(Modifier.fillMaxWidth().background(Coral.copy(alpha = 0.16f))) {
            Row(
                Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Box(Modifier.size(80.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = 7.dp.toPx()
                        val box = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w)
                        val tl = androidx.compose.ui.geometry.Offset(w / 2f, w / 2f)
                        drawArc(track, 0f, 360f, false, tl, box, style = Stroke(w))
                        if (frac > 0f) drawArc(Coral, -90f, 360f * frac, false, tl, box, style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Txt("$streak", 28, weight = FontWeight.Medium)
                        Txt(if (streak == 1) "Day" else "Days", 12, P.mute)
                    }
                }
                Column(Modifier.weight(1f)) {
                    Txt(title, 17, weight = FontWeight.Bold, maxLines = 2)
                    Txt(line, 13, P.mute, Modifier.padding(top = 4.dp), maxLines = 3)
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PTag("Longest streak")
                        PTag("$best ${if (best == 1) "day" else "days"}", on = true)
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.TodayTab(
    vm: BinderViewModel, l: BinderList, entries: List<Item>, today: List<Item>, now: Long,
    add: () -> Unit, viewAll: () -> Unit,
) {
    val days = loggedDays(entries)
    val day = epochDay(now)
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(2.dp))
        WeekStrip(days, day)
        StreakCard(entryStreak(days, day), bestEntryStreak(days))
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Txt("Today’s entries", 16, weight = FontWeight.Medium)
            Txt("All entries", 13, Coral, Modifier.clickable { viewAll() })
        }
        PCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                if (today.isEmpty()) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Txt("Nothing logged yet", 18, font = TitleFont, align = TextAlign.Center)
                        Txt("How’s today going? A quick note takes under a minute.", 13, P.mute, align = TextAlign.Center)
                    }
                } else {
                    today.forEachIndexed { i, e -> TimelineRow(vm, l, e, last = i == today.lastIndex) }
                }
                Box(
                    Modifier.fillMaxWidth().height(52.dp).clip(CircleShape).background(if (today.isEmpty()) P.primary else P.bg).clickable { add() },
                    contentAlignment = Alignment.Center,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Txt("Add a new entry", 15, if (today.isEmpty()) P.onPrimary else P.fg, weight = FontWeight.Medium)
                        Icon(Ic.Plus, null, tint = if (today.isEmpty()) P.onPrimary else P.fg, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

/** One of today's entries: the mood tile on a line that runs down to the next one, then what you did and when. */
@Composable
private fun TimelineRow(vm: BinderViewModel, l: BinderList, e: Item, last: Boolean) {
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            MoodTile(e)
            if (!last) Box(Modifier.padding(top = 6.dp).weight(1f).width(2.dp).background(P.line))
        }
        Column(Modifier.weight(1f).padding(bottom = if (last) 0.dp else 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { vm.nav.push(Route.ItemEdit(l.id, e.id)) }) {
                    Txt(e.title, 16, weight = FontWeight.Medium, maxLines = 1)
                    Txt(e.pLine(), 13, P.mute, Modifier.padding(top = 2.dp), maxLines = 2)
                }
                IconBtn(Ic.Dots, "Entry options") { vm.sheet = entryMenu(vm, l, e) }
            }
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Txt("${pTime(e.added)} · ${e.sub.ifBlank { "No mood" }}", 12, P.mute, maxLines = 1)
                PTag(WorkStages[e.workStage()], on = e.isFinished())
            }
        }
    }
}

// ───────── Workflow ─────────

@Composable
private fun ColumnScope.WorkflowTab(vm: BinderViewModel, l: BinderList, entries: List<Item>, add: () -> Unit) {
    if (entries.isEmpty()) {
        EmptyBlock("Nothing to move yet", "Entries you log show up here, grouped by workflow stage.", "Add a new entry") { add() }
        return
    }
    val counts = stageCounts(entries)
    val done = counts.last()
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 10.dp, bottom = 110.dp)) {
        item(key = "summary") {
            PCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Txt("Workflow", 16, weight = FontWeight.Medium)
                        PTag("$done of ${entries.size} done", on = true)
                    }
                    Progress(finishedFraction(entries))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        WorkStages.forEachIndexed { s, name ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Txt("${counts[s]}", 22, weight = FontWeight.Medium)
                                Txt(name, 12, P.mute)
                            }
                        }
                    }
                }
            }
        }
        WorkStages.forEachIndexed { s, name ->
            val here = entries.filter { it.workStage() == s }
            if (here.isNotEmpty()) {
                item(key = "stage$s") { Cap("${name.uppercase()} · ${here.size}", Modifier.padding(start = 4.dp)) }
                items(here, key = { it.id }) { e ->
                    Row(
                        Modifier.padding(bottom = 8.dp).fillMaxWidth().height(64.dp).clip(RoundedCornerShape(22.dp)).background(P.surface)
                            .clickable { vm.nav.push(Route.ItemEdit(l.id, e.id)) }.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        // tap the circle to move the entry on to the next stage (after Done it starts over at Plan)
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).background(if (e.isFinished()) Coral else Color.Transparent)
                                .border(2.dp, if (e.isFinished()) Coral else P.line, CircleShape)
                                .clickable { vm.saveItem(l.id, e.copy(stage = nextWorkStage(e.stage))) },
                            contentAlignment = Alignment.Center,
                        ) { if (e.isFinished()) Icon(Ic.Check, "Done", tint = CheckInk, modifier = Modifier.size(16.dp)) }
                        Column(Modifier.weight(1f)) {
                            Txt(e.title, 16, if (e.isFinished()) P.mute else P.fg, maxLines = 1, strike = e.isFinished())
                            Txt("${e.moodEmoji()} ${e.sub.ifBlank { "No mood" }} · ${pTime(e.added)}", 12, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                        }
                        PTag(WorkStages[nextWorkStage(e.stage)].let { "→ $it" })
                    }
                }
            }
        }
        item(key = "hint") { Txt("Tap the circle to move an entry to its next stage", 12, P.mute, Modifier.fillMaxWidth().padding(top = 8.dp), align = TextAlign.Center) }
    }
}

// ───────── All entries ─────────

@Composable
private fun ColumnScope.AllTab(
    vm: BinderViewModel, l: BinderList, entries: List<Item>, now: Long, q: String, mood: Int,
    add: () -> Unit, onQuery: (String) -> Unit, onMood: (Int) -> Unit,
) {
    if (entries.isEmpty()) {
        EmptyBlock("Nothing logged yet", "Log what you worked on and how you felt and it builds up here.", "Add a new entry") { add() }
        return
    }
    val shown = entries.filtered(mood, q)
    val groups = shown.groupBy { startOfDay(it.added) }.toList()
    Field("Search entries", q, Modifier.padding(top = 8.dp)) { onQuery(it) }
    Chips(listOf("All") + Moods.map { it.name }, mood + 1) { onMood(it - 1) }
    if (shown.isEmpty()) {
        EmptyBlock("No matches", "No entry fits this search and mood.")
        return
    }
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 110.dp)) {
        groups.forEach { (day, list) ->
            item(key = "day$day") { Cap(pDayTitle(day, now).uppercase(), Modifier.padding(start = 4.dp)) }
            items(list, key = { it.id }) { e ->
                val edit = { vm.nav.push(Route.ItemEdit(l.id, e.id)) }
                Box(Modifier.padding(bottom = 8.dp)) {
                    SwipeRow(true, "Edit", "Delete", onRight = { edit() }, onLeft = { vm.deleteItem(l.id, e) }) {
                        Row(
                            Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(22.dp)).background(P.surface)
                                .clickable { edit() }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            MoodTile(e, 44)
                            Column(Modifier.weight(1f)) {
                                Txt(e.title, 16, maxLines = 1)
                                Txt(e.pLine(), 12, P.mute, Modifier.padding(top = 2.dp), maxLines = 1)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Txt(pTime(e.added), 13, P.mute)
                                PTag(WorkStages[e.workStage()], on = e.isFinished())
                            }
                        }
                    }
                }
            }
        }
        item { Txt("Swipe left on an entry to delete it", 12, P.mute, Modifier.fillMaxWidth().padding(top = 8.dp), align = TextAlign.Center) }
    }
}

// ───────── new entry ─────────

@Composable
fun ProductivityEntryScreen(vm: BinderViewModel, listId: String, itemId: String?) {
    val nav = vm.nav
    val l = vm.lists.firstOrNull { it.id == listId }
    val existing = l?.items?.firstOrNull { it.id == itemId }
    var title by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var note by rememberSaveable { mutableStateOf(existing?.note ?: "") }
    var mood by rememberSaveable { mutableStateOf(existing?.moodIndex()?.takeIf { it >= 0 } ?: 0) }
    var stage by rememberSaveable { mutableStateOf(existing?.workStage() ?: 1) }
    if (l == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    Screen {
        Header2(
            if (existing == null) "New entry" else "Edit entry", l.name, onBack = { nav.pop() },
            right = { if (existing != null) CircleBtn(Ic.Close, "Delete entry") { vm.deleteItem(l.id, existing); nav.pop() } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Cap("WHAT DID YOU WORK ON?", Modifier.padding(start = 4.dp))
            Field("Title", title) { title = it }
            Cap("DESCRIPTION", Modifier.padding(start = 4.dp))
            Field("Optional · how did it go?", note, singleLine = false) { note = it }
            Cap("MOOD", Modifier.padding(start = 4.dp))
            FlowChips(Moods.map { "${it.emoji} ${it.name}" }, mood) { mood = it }
            Cap("WORKFLOW STAGE", Modifier.padding(start = 4.dp))
            Seg(WorkStages, stage) { stage = it }
            Spacer(Modifier.height(16.dp))
        }
        BigButton("Save entry", Modifier.navigationBarsPadding().padding(top = 8.dp, bottom = 18.dp)) {
            val m = Moods[mood]
            val item = (existing ?: Item(title = "")).copy(title = title.trim().ifBlank { m.name }, sub = m.name, stage = stage, note = note.trim())
            vm.saveItem(l.id, item)
            nav.pop()
        }
    }
}
