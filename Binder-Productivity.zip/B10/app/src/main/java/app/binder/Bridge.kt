package app.binder

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

// SCRAPBOOK <-> BINDER, the Android side (the rules are in Link.kt). Everything that arrives from Scrapbook or from a binder:// link is read
// here, and everything sent to Scrapbook leaves from here. The rest of the app touches this from marked hook lines ("[scrapbook hook N]"):
//
//   1. MainActivity.kt: calls vm.handleIntent for the first intent and for each new one
//   2. ItemSheet.kt: the "Write about this" / "Open scrap" / "Unlink scrap" rows
//   3. AndroidManifest.xml: the binder:// link, launchMode singleTask, and the FileProvider that hands Scrapbook an item's cover
//   4. Models.kt / Persist.kt: Item.scrap, saved as the optional key "scrap"

/** Reads one intent: a binder:// link, Scrapbook's "add this scrap" or "make a bind from these". Anything else is ignored. */
fun BinderViewModel.handleIntent(ctx: Context, i: Intent?) {
    if (i == null) return
    when (i.action) {
        Intent.ACTION_VIEW -> parseBinderUri(i.dataString)?.let { openRef(ctx, it) }
        ACTION_ADD -> addFromScrapbook(ctx, i.getStringExtra("title").orEmpty(), i.getStringExtra("note").orEmpty(), i.getStringExtra("scrap").orEmpty())
        ACTION_IMPORT -> importFromScrapbook(ctx, i.getStringExtra("name").orEmpty(), parseKind(i.getStringExtra("kind")),
            i.getStringArrayListExtra("items").orEmpty(), i.getBooleanArrayExtra("done")?.toList().orEmpty(), i.getStringArrayListExtra("scraps").orEmpty())
    }
}

private fun BinderViewModel.showList(id: String) { nav.root(Route.Home); nav.push(Route.Lst(id)) }

/** Opens the bind or the item a binder:// link points at. */
private fun BinderViewModel.openRef(ctx: Context, ref: OpenRef) {
    if (ref.kind == "bind") {
        if (lists.any { it.id == ref.id }) showList(ref.id) else Toast.makeText(ctx, "That bind isn't in Binder any more", Toast.LENGTH_SHORT).show()
        return
    }
    val l = lists.firstOrNull { b -> b.items.any { it.id == ref.id } }
    if (l == null) { Toast.makeText(ctx, "That item isn't in Binder any more", Toast.LENGTH_SHORT).show(); return }
    showList(l.id)
    if (!l.kind.hasOwnPage) nav.push(Route.ItemEdit(l.id, ref.id))
}

/** Scrapbook's "Add to Binder": asks which bind, adds the item (linked to the scrap), then takes you back to the scrap with a link to the item added there. */
private fun BinderViewModel.addFromScrapbook(ctx: Context, title: String, note: String, scrapUid: String) {
    val binds = lists.filter { !it.kind.hasOwnPage }
    if (binds.isEmpty()) { Toast.makeText(ctx, "Make a bind in Binder first, then add the scrap to it", Toast.LENGTH_LONG).show(); return }
    val uid = scrapUid.trim().takeIf { isScrapUid(it) }.orEmpty()
    sheet = SheetData("Add “${title.take(40)}” to…", binds.map { b ->
        Act(b.name) {
            val item = Item(title = title.ifBlank { "Untitled" }, note = note.take(280), scrap = uid, stage = b.startStage)
            saveItem(b.id, item)
            Toast.makeText(ctx, "Added to ${b.name}", Toast.LENGTH_SHORT).show()
            if (uid.isNotEmpty()) runCatching {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(bounceUrl(uid, item.id, item.title))).setClassName(SCRAPBOOK_PACKAGE, SCRAPBOOK_ACTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    })
}

/** Scrapbook's "make a bind": a checklist (kind given) is made at once; otherwise you choose what kind of bind it is. The new bind opens. */
private fun BinderViewModel.importFromScrapbook(ctx: Context, name: String, kind: Kind?, titles: List<String>, done: List<Boolean>, scraps: List<String>) {
    if (titles.none { it.isNotBlank() }) return
    val bindName = name.trim().ifBlank { "From Scrapbook" }
    fun make(k: Kind) {
        val id = addList(bindName, k)
        val l = lists.first { it.id == id }
        val items = importedItems(l, titles, done, scraps)
        items.asReversed().forEach { saveItem(id, it) }   // new items go on top, so they are added last to first
        showList(id)
        Toast.makeText(ctx, "Made “$bindName” with ${items.size} ${if (items.size == 1) "item" else "items"}", Toast.LENGTH_SHORT).show()
    }
    if (kind != null) make(kind)
    else sheet = SheetData("What kind of bind is “${bindName.take(40)}”?", Kind.entries.filter { !it.hasOwnPage }.map { k -> Act(k.label) { make(k) } })
}

/**
 * "Write about this": asks Scrapbook to make a scrap about the item (its details, description and cover) and links the item to it. The link is
 * only stored once Scrapbook has been reached, so nothing is left pointing nowhere when Scrapbook is not installed.
 */
fun writeAbout(ctx: Context, vm: BinderViewModel, l: BinderList, item: Item) {
    val uid = newScrapUid()
    val i = Intent(ACTION_SCRAPBOOK_CREATE).setClassName(SCRAPBOOK_PACKAGE, SCRAPBOOK_ACTIVITY)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        .putExtra("title", item.title).putExtra("body", aboutBody(l, item)).putExtra("uid", uid).putExtra("box", l.name)
    item.images.firstOrNull()?.let { name ->
        val f = File(File(ctx.filesDir, "images"), name)
        if (f.exists()) runCatching {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
            i.putExtra(Intent.EXTRA_STREAM, uri); i.clipData = ClipData.newRawUri(null, uri)
        }
    }
    try { ctx.startActivity(i); vm.saveItem(l.id, item.copy(scrap = uid)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Scrapbook isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/** Opens a scrap in Scrapbook. */
fun openScrap(ctx: Context, uid: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(scrapUrl(uid))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Scrapbook isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}
