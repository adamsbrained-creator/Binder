package app.binder

import java.util.UUID

enum class Layout(val label: String) {
    GRID("Grid"), LIST("List"), SHELF("Shelf"), SECTIONS("Sections"), CARDS("Cards"),
    CAROUSEL("Carousel"), TIMELINE("Timeline")
}

enum class Sort(val label: String) {
    MANUAL("Manual"), NEWEST("Newest"), TITLE("A–Z"), RATING("Rating")
}

/**
 * Where details can be fetched from. [needsKey] sources only work in a build that has their key
 * (see Keys in Meta.kt); without it they say so and are hidden in More.
 */
enum class Source(val label: String, val openLabel: String, val needsKey: Boolean = false) {
    APPLE("Apple Music", "Open in Apple Music"),
    TMDB("TMDB", "Open on TMDB", needsKey = true),
    RAWG("RAWG", "Open on RAWG", needsKey = true),
    OPENLIBRARY("Open Library", "Open on Open Library"),
    GOOGLEBOOKS("Google Books", "Open in Google Books"),
    DEEZER("Deezer", "Open in Deezer"),
    ANILIST("AniList", "Open on AniList"),
    NOMINATIM("OpenStreetMap", "Open on OpenStreetMap"),
    WIKIPEDIA("Wikipedia", "Open on Wikipedia"),
    WEB("Web page", "Open page"),     // any other pasted link (Open Graph tags); not a source you pick for a list
}

/** The kinds of list you can start from. Add a new one here and it shows up everywhere. */
enum class Kind(
    val label: String,
    val hint: String,
    val noun: String,
    val single: String,
    val subLabel: String,
    val stages: List<String>,
    val hasRating: Boolean,
    val square: Boolean = false,                 // album and game covers are square
    val sources: List<Source> = emptyList(),     // where details can come from; the first one is the default
    val extraLabel: String = "Details",          // what Item.extra holds for this kind (runtime, seasons, pages ...)
) {
    BOOKS("Books", "Title, author", "books", "book", "Author", listOf("To read", "Reading", "Done"), true, sources = listOf(Source.OPENLIBRARY, Source.GOOGLEBOOKS), extraLabel = "Pages"),
    MANGA("Manga", "Title, author", "manga", "manga", "Author", listOf("To read", "Reading", "Done"), true, sources = listOf(Source.ANILIST), extraLabel = "Volumes"),
    COMICS("Comics", "Title, writer", "comics", "comic", "Writer", listOf("To read", "Reading", "Done"), true, sources = listOf(Source.GOOGLEBOOKS), extraLabel = "Pages"),
    MOVIES("Movies", "Title, year", "movies", "movie", "Year", listOf("To watch", "Watching", "Watched"), true, sources = listOf(Source.TMDB), extraLabel = "Runtime"),
    SERIES("Series", "Seasons", "series", "series", "Seasons", listOf("To watch", "Watching", "Watched"), true, sources = listOf(Source.TMDB, Source.ANILIST), extraLabel = "Episodes"),
    ALBUMS("Albums", "Artist, year", "albums", "album", "Artist", listOf("To listen", "Listening", "Heard"), true, square = true, sources = listOf(Source.APPLE)),
    GAMES("Games", "Platform", "games", "game", "Platform", listOf("To play", "Playing", "Played"), true, square = true, sources = listOf(Source.RAWG), extraLabel = "Platforms"),
    PLACES("Places", "City", "places", "place", "City", listOf("Want to go", "Planned", "Visited"), true, sources = listOf(Source.NOMINATIM), extraLabel = "Address"),
    ANYTHING("Anything", "Your own", "things", "thing", "Details", listOf("Idea", "In progress", "Done"), true, sources = listOf(Source.WIKIPEDIA)),
    CHECKLIST("Checklist", "Items, done", "items", "item", "", listOf("To do", "Done"), false),
    // A tracker (mood, energy, sleep ...). Each entry is an Item: stage = the face (0..4), rating = 1..10, note = the note,
    // added = when it was logged, title = the face's word. Nothing new is saved in the file. See Tracker.kt.
    TRACKER("Tracker", "Mood, energy, sleep…", "entries", "entry", "", listOf("Drained", "Low", "Okay", "Good", "Great"), true),
    // A time tracker. The page always shows how much of today / this week / this month / this year is gone; each Item is a date to
    // count down to: title = its name, added = the day counting starts, due = the day it ends (midnight of that day), note = the note.
    // `due` is the only new saved key (optional, so old files and backups need nothing). See Time.kt.
    TIME("Time", "Year, deadlines, countdowns…", "dates", "date", "", listOf("Counting"), false),
    // A habit tracker. Each Item is a habit: title = its name, note = the description, sub = its emoji, cover = its colour (HabitColors),
    // target = times a day (1 = done / not done), streakGoal = days (0 = none), marks = the check-ins (day number -> times that day).
    // marks, target and streakGoal are the only new saved keys (all optional, so old files and backups need nothing). See Habits.kt.
    HABITS("Habits", "Reading, workouts, water…", "habits", "habit", "", listOf("Active"), false),
    // A song finder (like Shazam). The page listens for about ten seconds and names the song; each song you keep is an Item:
    // title = the song, sub = the artist, extra = the album, year, genre, images = the cover (downloaded), sourceName / sourceUrl = where it opens
    // (Apple Music or Deezer), note and rating = yours, added = when you heard it. Nothing new is saved in the file. See Heard.kt, Recognize.kt, Songs.kt.
    HEARD("Heard", "Name songs by listening", "songs", "song", "Artist", listOf("Heard"), true, square = true, sources = listOf(Source.APPLE, Source.DEEZER), extraLabel = "Album"),
    // A productivity log. Each entry is an Item: title = what you worked on, note = the description, sub = the mood (see Moods),
    // stage = the workflow stage (Plan / Doing / Review / Done), added = when it was logged. Nothing new is saved in the file.
    // See Productivity.kt and ProductivityLogic.kt.
    PRODUCTIVITY("Productivity", "Mood, workflow, daily log", "entries", "entry", "", listOf("Plan", "Doing", "Review", "Done"), false);

    val isChecklist: Boolean get() = this == CHECKLIST
    val isTracker: Boolean get() = this == TRACKER
    val isTime: Boolean get() = this == TIME
    val isHabits: Boolean get() = this == HABITS
    val isHeard: Boolean get() = this == HEARD
    val isProductivity: Boolean get() = this == PRODUCTIVITY
    /**
     * Tracker, Time, Habits and Heard binds have a page of their own: they are left out of Move / Copy, and the first three
     * of Search and Quick add too. A Heard bind is the exception: its songs are found by Search and it is a Quick add target (search a title, add the song).
     */
    val hasOwnPage: Boolean get() = isTracker || isTime || isHabits || isHeard || isProductivity
    /** Quick add and Search skip the binds with a page of their own, except Heard. */
    val inQuickAdd: Boolean get() = !hasOwnPage || isHeard
    val layouts: List<Layout> get() = if (isChecklist) listOf(Layout.LIST, Layout.SECTIONS) else if (hasOwnPage) listOf(Layout.LIST) else Layout.entries
}

/** What can be shown under a cover in the grid. */
enum class Under(val label: String) { TITLE("Title"), RATING("Rating"), ADDED("Added"), PROGRESS("Progress") }

data class Item(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val sub: String = "",
    val stage: Int = 0,
    val rating: Float = 0f,
    val note: String = "",
    val added: Long = System.currentTimeMillis(),
    val cover: Int = -1, // -1 = automatic colour
    val images: List<String> = emptyList(), // file names in files/images, the first one is the cover
    // filled in when details are fetched (all optional, old files simply have none)
    val sourceName: String = "",
    val sourceId: String = "",
    val sourceUrl: String = "",
    val year: String = "",
    val genre: String = "",
    val description: String = "",
    val detailsPending: Boolean = false, // saved offline, details still to be fetched
    val extra: String = "",              // optional: runtime, seasons, pages, volumes, platforms ... (see Kind.extraLabel)
    val due: Long = 0L,                  // optional: a Time bind's date to count down to (midnight of that day); 0 = none
    val group: String = "",              // the id of the group (folder) this item sits in; "" = the main list
    val marks: Map<Int, Int> = emptyMap(), // a habit's check-ins: day number (see epochDay) -> how many times that day; empty = none
    val target: Int = 1,                 // a habit's goal per day: 1 = done / not done, more = a count
    val streakGoal: Int = 0,             // a habit's streak goal in days; 0 = none
    val scrap: String = "",              // optional: the permanent id of the Scrapbook scrap written about this item; "" = none (optional key "scrap"; see Link.kt)
)

/** A folder inside a bind, like "The Beatles" inside Music Albums. Items point at it with [Item.group]. */
data class Group(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val stages: List<String> = emptyList(), // a Productivity project's own workflow, first to last (optional key "stages"); empty = the default one
)

/** The icon a Time bind wears on Home (Change icon in its menu). */
enum class TimeIcon(val label: String) { TILE("Days left"), CALENDAR("Calendar"), FILL("Filling circle") }

data class BinderList(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: Kind,
    val layout: Layout = Layout.GRID,
    val sort: Sort = Sort.MANUAL,
    val pinned: Boolean = false,
    val items: List<Item> = emptyList(),
    val created: Long = System.currentTimeMillis(),
    val columns: Int = 3,                         // 2, 3 or 4 in the grid layout
    val under: Set<Under> = setOf(Under.TITLE, Under.RATING),
    val source: Source? = null,                   // optional: which source to fetch from (null = the first one the kind offers)
    val timeIcon: TimeIcon = TimeIcon.TILE,       // a Time bind's icon on Home
    val groups: List<Group> = emptyList(),        // folders inside this bind
    val stageNames: List<String> = emptyList(),   // this bind's own names for its statuses, one per status; "" = the kind's own name (optional key "stageNames")
    val stageHidden: Set<Int> = emptySet(),       // statuses switched off for this bind (indexes into Kind.stages; optional key "stageHidden")
    val emoji: String = "",                       // the icon its card wears on Home instead of the usual mark; "" = the usual one (optional key "emoji")
    val tint: Int = -1,                           // the colour behind its card on Home, a place in Tints; -1 = the plain grey card (optional key "tint")
)

/** The id of the group this item really sits in; "" is the main list (also for an item whose group no longer exists). */
fun BinderList.groupIdOf(item: Item): String = if (groups.any { it.id == item.group }) item.group else ""

/** The items of one group ("" = the main list), in the bind's order. */
fun BinderList.itemsIn(gid: String): List<Item> = sorted().filter { groupIdOf(it) == gid }

/** If all of these items share one artist / author / ..., that one, otherwise "". Used to name a new group. */
fun BinderList.commonSub(ids: Set<String>): String {
    val subs = items.filter { it.id in ids }.map { it.sub.trim() }.distinct()
    return if (subs.size == 1) subs[0] else ""
}

// ───────── statuses (Idea / In progress / Done ...) ─────────
// An item always saves its status as a number: the place in Kind.stages. A bind can give each status its own name and switch one off;
// that changes what is shown, never what is saved, so switching a status back on brings its items back to it.

/** Binds whose statuses can be renamed or hidden: everything except checklists and the binds with a page of their own. */
val BinderList.hasEditableStages: Boolean get() = !kind.isChecklist && !kind.hasOwnPage

/** The name of status [i]: this bind's own name for it, otherwise the kind's. */
fun BinderList.stageLabel(i: Int): String {
    val k = i.coerceIn(0, kind.stages.lastIndex)
    return stageNames.getOrNull(k)?.trim()?.takeIf { it.isNotEmpty() } ?: kind.stages[k]
}

/**
 * The statuses in use, as places in Kind.stages, in order. At most one is hidden, so there is always a start and a finish
 * (anything else in a file falls back to showing them all).
 */
val BinderList.liveStages: List<Int> get() {
    val all = kind.stages.indices.toList()
    if (!hasEditableStages) return all
    val shown = all.filter { it !in stageHidden }
    return if (shown.size >= 2) shown else all
}

/** The status a saved number stands for: itself if that one is in use, otherwise the nearest one below it (or the first, if there is none). */
fun BinderList.stageAt(stage: Int): Int {
    val live = liveStages
    val s = stage.coerceIn(0, kind.stages.lastIndex)
    return if (s in live) s else live.lastOrNull { it < s } ?: live.first()
}

fun BinderList.stageOf(item: Item): Int = stageAt(item.stage)

/** Where new things start. */
val BinderList.startStage: Int get() = liveStages.first()

/** The last status in use is the finish line: it is what "done" means for this bind. */
val BinderList.endStage: Int get() = liveStages.last()

/** The names of the statuses in use, in order (what the pickers show). */
fun BinderList.stageLabels(): List<String> = liveStages.map { stageLabel(it) }

/** The status after the item's own; after the last one it wraps back to the first. */
fun BinderList.nextStage(item: Item): Int {
    val live = liveStages
    val at = live.indexOf(stageOf(item))
    return live[if (at < 0 || at >= live.lastIndex) 0 else at + 1]
}

fun BinderList.doneCount(): Int = if (kind.hasOwnPage) 0 else items.count { stageOf(it) == endStage }
/** For a tracker the bar shows the latest entry (rating out of 10); for a Time bind, how much of this year has passed; for everything else, how much is done. */
fun BinderList.progress(): Float =
    if (kind.isTime) yearFraction(System.currentTimeMillis())
    else if (kind.isHabits) habitsFraction(items, System.currentTimeMillis())
    else if (kind.isProductivity) productivityFraction(this, System.currentTimeMillis())
    else if (kind.isTracker) (items.maxByOrNull { it.added }?.rating ?: 0f) / 10f
    else if (items.isEmpty()) 0f else doneCount().toFloat() / items.size
fun BinderList.activity(): Long = maxOf(created, items.maxOfOrNull { it.added } ?: 0L)
/** A tracker's most recent entry, or null for any other kind of bind and for a tracker with no entries yet. */
fun BinderList.lastEntry(): Item? = if (kind.isTracker) items.maxByOrNull { it.added } else null
/** The face of a tracker's latest entry, or null when there is none. */
fun BinderList.lastFace(): String? = lastEntry()?.let { Faces[it.stage.coerceIn(0, Faces.lastIndex)] }
/** A Habits bind's emoji on Home: the one chosen for the habit at the top of its list (a habit with none gets the sparkle), null when it has no habits yet. */
fun BinderList.habitEmoji(): String? =
    if (kind.isHabits) items.firstOrNull()?.let { it.sub.trim().ifEmpty { "✨" } } else null
/** The big thing on a small card: a tracker's face, a Time bind's days left, otherwise how many items. */
fun BinderList.cardFace(): String =
    if (kind.isTime) yearLeftBig(System.currentTimeMillis())
    else if (kind.isHabits) habitsFace(items, System.currentTimeMillis())
    else if (kind.isProductivity) productivityFace(items, System.currentTimeMillis())
    else lastFace() ?: "${items.size}"
/** The small line under a tracker's name ("3 entries · Good"), a Time bind's ("77 days left in 2026 · 2 dates") or a Heard bind's ("12 songs · Here Comes the Sun"); null for anything else. */
fun BinderList.entryLine(): String? =
    if (kind.isHeard) heardLine(items)
    else if (kind.isTime) timeLine(System.currentTimeMillis(), items.size)
    else if (kind.isHabits) habitsLine(items, System.currentTimeMillis())
    else if (kind.isProductivity) productivityLine(items, System.currentTimeMillis())
    else lastEntry()?.let { last ->
        "${items.size} ${if (items.size == 1) "entry" else "entries"} · ${kind.stages[last.stage.coerceIn(0, kind.stages.lastIndex)]}"
    }

fun BinderList.countLabel(): String =
    if (kind.isChecklist) "${doneCount()} of ${items.size} done"
    else "${items.size} ${if (items.size == 1) kind.single else kind.noun}"

fun BinderList.sorted(): List<Item> = when (sort) {
    Sort.MANUAL -> items
    Sort.NEWEST -> items.sortedByDescending { it.added }
    Sort.TITLE -> items.sortedBy { it.title.lowercase() }
    Sort.RATING -> items.sortedByDescending { it.rating }
}

// ───────── look & feel options ─────────

enum class HeaderStyle(val label: String) {
    WORDMARK("Wordmark"), CIRCLES("Circles"), MENU_CENTER("Menu, centred"), MENU_LEFT("Menu, left")
}

/** How much room the top bar takes (same three sizes as Paperback). Compact also drops the page title on the home screen. */
enum class HeaderSize(val label: String) { COMPACT("Compact"), REGULAR("Regular"), LARGE("Large") }

enum class NavStyle(val label: String) {
    NONE("None"), DOCK("Dock"), SPLIT("Split dock"), NOTCH("Notch bar"), SEARCH("Search bar"),
    TABS("Top tabs"), MINI("Mini dock"), PILL("Labelled pill"), RAIL("Side rail"), DRAWER("Drawer")
}

enum class HomeStyle(val label: String) {
    PINNED("Pinned"), TILES("Tiles"), ROWS("Rows"), GROUPED("Grouped"), STACKS("Stacks")
}

/** How a new bind is made: a full page with a grid of templates, a sheet over the current screen, a full page with a Popular row and a list, a full page with a live preview of the Home card, or a full page of big cards you swipe through. */
enum class NewBindStyle(val label: String) { GRID("Grid"), SHEET("Emoji sheet"), POPULAR("Popular + list"), PREVIEW("Preview first"), SWIPE("Swipe cards") }

enum class AddStyle(val label: String) {
    SHEET("Quick sheet"), EDITOR("Full editor"), BAR("Add bar")
}

/** The button in the bottom corner. HOLD is the original (menu button, hold it for a +). */
enum class AddButton(val label: String) {
    HOLD("Hold for +"), LABEL("Menu and label"), DIAL("Speed dial"), BADGE("Corner badge")
}

enum class ItemPage(val label: String) { STANDARD("Standard"), COLLAGE("Collage"), HERO("Hero"), COMPACT("Compact") }

enum class FontChoice(val label: String) {
    OUTFIT("Outfit"), LORA("Outfit + Lora"), CRIMSON("Outfit + Crimson"),
    INSTRUMENT("Outfit + Instrument Serif"), INSTSANS("Instrument Sans"), WORKSANS("Work Sans")
}

data class Opts(
    val theme: String = "system",
    val appName: String = "binder", // "binder" or "catalog"
    val font: FontChoice = FontChoice.OUTFIT,
    val header: HeaderStyle = HeaderStyle.WORDMARK,
    val nav: NavStyle = NavStyle.NONE,
    val home: HomeStyle = HomeStyle.PINNED,
    val add: AddStyle = AddStyle.SHEET,
    val itemPage: ItemPage = ItemPage.STANDARD,
    val fetch: Boolean = false,           // fetch details from the internet (off = no network calls at all)
    val emptySlots: Boolean = true,       // dashed "+" slots in empty places
    val ratingStyle: RatingStyle = RatingStyle.STARS, // saved as the optional key "ratingStyle"
    val headerSize: HeaderSize = HeaderSize.REGULAR,  // saved as the optional key "headerSize"
    val accent: Int = 4,                              // index into Accents (4 = Green, the default); saved as the optional key "accent"
    val listProgress: Boolean = true,                 // the coral progress line under a list's header; optional key "listProgress"
    val addButton: AddButton = AddButton.HOLD,        // the corner button; optional key "addButton"
    val newBind: NewBindStyle = NewBindStyle.GRID,    // how New bind looks; optional key "newBind"
)

/** True when the app is set to Catalog (name, icon and wording all follow this one switch). */
val Opts.isCatalog: Boolean get() = appName == "catalog"

/** "Binder" or "Catalog": the app name as shown (wordmark, About, label). */
val Opts.appLabel: String get() = if (isCatalog) "Catalog" else "Binder"

/** The word for one list and for many: Bind/Binds, or Catalog/Catalogs. Follows [Opts.appName]. */
val Opts.lists: String get() = if (isCatalog) "Catalogs" else "Binds"
val Opts.list: String get() = if (isCatalog) "Catalog" else "Bind"
val Opts.listsLower: String get() = lists.lowercase()
val Opts.listLower: String get() = list.lowercase()
