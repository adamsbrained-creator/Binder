package app.binder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// The "Today" view of Home (HomeStyle.TODAY): a big day name with the date at the right, then every bind as one quiet line,
// a small mark, its name and a short status, with dotted rules between them. Finished binds sink to the bottom, faded.
// (Layout concept: the Binder_Home mockup.) Press and hold a row for the usual menu.

@Composable
fun ColumnScope.TodayHome(shown: List<BinderList>, pad: Int, open: (BinderList) -> Unit, hold: (BinderList) -> Unit) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            now = System.currentTimeMillis()
        }
    }
    // same idea as Grouped's "Completed": a bind with items that are all done (a tracker, habits and the like never finish)
    val finished = shown.filter { !it.kind.hasOwnPage && it.items.isNotEmpty() && it.progress() >= 1f }
    val active = shown.filter { it !in finished }
    val date = Date(now)
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 8.dp, bottom = pad.dp)) {
        item(key = "~day") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.Top) {
                    Txt(SimpleDateFormat("EEE", Locale.getDefault()).format(date), 60, weight = FontWeight.Bold, ls = (-0.04).em, maxLines = 1)
                    Box(Modifier.padding(start = 8.dp, top = 22.dp).size(12.dp).clip(CircleShape).background(Coral))
                }
                Column(Modifier.padding(top = 6.dp), horizontalAlignment = Alignment.End) {
                    Txt(SimpleDateFormat("MMMM d", Locale.getDefault()).format(date), 20, P.mute, weight = FontWeight.Medium, maxLines = 1)
                    Txt(SimpleDateFormat("yyyy", Locale.getDefault()).format(date), 20, P.mute.copy(alpha = 0.7f), weight = FontWeight.Medium, maxLines = 1)
                }
            }
            Spacer(Modifier.height(20.dp))
        }
        items(active, key = { it.id }) { l -> TodayRow(l, false, open, hold) }
        items(finished, key = { it.id }) { l -> TodayRow(l, true, open, hold) }
    }
}

@Composable
private fun TodayRow(l: BinderList, done: Boolean, open: (BinderList) -> Unit, hold: (BinderList) -> Unit) {
    val rule = P.line
    Row(
        Modifier.fillMaxWidth().height(62.dp).tapHold({ open(l) }, { hold(l) })
            .drawBehind {
                // a dotted rule along the bottom: zero-length dashes with round caps are dots
                val w = 2.dp.toPx()
                drawLine(
                    rule, Offset(0f, size.height - w / 2), Offset(size.width, size.height - w / 2), strokeWidth = w,
                    cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(0.1f, w * 2.6f), 0f),
                )
            }
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TodayMark(l, done)
        Txt(l.name, 19, if (done) P.mute else P.fg, Modifier.weight(1f), weight = FontWeight.Medium, maxLines = 1)
        Txt(todayStatus(l), 15, P.mute, maxLines = 1)
    }
}

/** The small mark at the start of a row: the bind's own emoji or face if it has one, a wave for Heard, otherwise a thin ring (dashed once finished). */
@Composable
private fun TodayMark(l: BinderList, done: Boolean) {
    val glyph = l.emoji.trim().ifEmpty { l.lastFace() ?: l.habitEmoji() ?: l.productivityEmoji() ?: "" }
    Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
        when {
            glyph.isNotEmpty() -> Txt(glyph, 22)
            l.kind.isHeard -> WaveMark(26.dp)
            else -> MiniRing(l.progress(), done)
        }
    }
}

@Composable
private fun MiniRing(frac: Float, done: Boolean) {
    val track = P.line
    val faded = P.mute.copy(alpha = 0.6f)
    Canvas(Modifier.size(26.dp)) {
        val w = 2.6.dp.toPx()
        val box = Size(size.width - w, size.height - w)
        val tl = Offset(w / 2f, w / 2f)
        if (done) {
            drawArc(faded, 0f, 360f, false, tl, box, style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)))
        } else {
            drawArc(track, 0f, 360f, false, tl, box, style = Stroke(w))
            if (frac > 0f) drawArc(Coral, -90f, 360f * frac.coerceIn(0f, 1f), false, tl, box, style = Stroke(w, cap = StrokeCap.Round))
        }
    }
}

/** The short grey text at the right of a row: "3 of 6", "4 today", "69 days", "5 entries". */
private fun todayStatus(l: BinderList): String {
    val line = l.entryLine()
    return when {
        l.kind.isTime -> yearLeftShort(System.currentTimeMillis())
        line != null -> line.substringBefore(" · ")
        l.items.isEmpty() -> "Empty"
        else -> "${l.doneCount()} of ${l.items.size}"
    }
}
