package app.binder

/** The glossy icons of the Showcase home. One per kind of bind; the first three also dress the shortcut cards. */
enum class Gloss { SUN, CHECK, MEDIA, MEDIAB, BOOK, BOOKB, BOOKR, DISC, PAD, PIN, SPARK, FACE, MIC, FLAME, CAL }

/** Which glossy icon a kind of bind wears on the Showcase home. */
fun Kind.gloss(): Gloss = when (this) {
    Kind.BOOKS -> Gloss.BOOK
    Kind.MANGA -> Gloss.BOOKB
    Kind.COMICS -> Gloss.BOOKR
    Kind.MOVIES -> Gloss.MEDIA
    Kind.SERIES -> Gloss.MEDIAB
    Kind.ALBUMS -> Gloss.DISC
    Kind.GAMES -> Gloss.PAD
    Kind.PLACES -> Gloss.PIN
    Kind.ANYTHING -> Gloss.SPARK
    Kind.CHECKLIST -> Gloss.CHECK
    Kind.TRACKER -> Gloss.FACE
    Kind.TIME -> Gloss.CAL
    Kind.HABITS -> Gloss.SUN
    Kind.HEARD -> Gloss.MIC
    Kind.PRODUCTIVITY -> Gloss.FLAME
}
