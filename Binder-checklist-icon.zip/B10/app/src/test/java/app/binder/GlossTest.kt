package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GlossTest {
    @Test fun everyKindWearsAnIcon() {
        // gloss() is an exhaustive when, so this also fails to compile if a new Kind is added without one
        for (k in Kind.entries) assertTrue(k.name, Gloss.entries.contains(k.gloss()))
    }

    @Test fun checklistsAndProductivityKeepTheirIcons() {
        assertEquals(Gloss.CHECK, Kind.CHECKLIST.gloss())
        assertEquals(Gloss.FLAME, Kind.PRODUCTIVITY.gloss())
        assertEquals(Gloss.CAL, Kind.TIME.gloss())
    }

    @Test fun showcaseIsAHomeStyleButNotTheDefault() {
        assertTrue(HomeStyle.entries.contains(HomeStyle.SHOWCASE))
        assertEquals(HomeStyle.PINNED, Opts().home)
    }
}
