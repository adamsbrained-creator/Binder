package app.binder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ───────── the bottom button: menu, and a way to add ─────────

/**
 * The corner button. Tap always opens the menu (or, in "Menu and label", the white pill adds).
 * Settings > App style > Add button picks how adding looks: hold for a +, a labelled pill,
 * a speed dial, or a small accent + badge on the button.
 *
 * [newBind] is true where adding means "new bind" (home, lists, settings); the speed dial then offers
 * the kinds. Elsewhere [addLabel] names what + adds ("New book", "New entry"); null means "New bind".
 */
@Composable
fun BoxScope.MenuFab(
    vm: BinderViewModel,
    bottom: Int = 0,
    onAdd: () -> Unit,
    onAddHold: (() -> Unit)? = null,
    addLabel: String? = null,
    newBind: Boolean = false,
) {
    when (vm.opts.addButton) {
        AddButton.HOLD -> HoldFab(vm, bottom, onAdd, onAddHold)
        AddButton.LABEL -> LabelFab(vm, bottom, onAdd, onAddHold, addLabel ?: "New ${vm.opts.listLower}")
        AddButton.DIAL -> DialFab(vm, bottom, onAdd, addLabel ?: "New ${vm.opts.listLower}", newBind)
        AddButton.BADGE -> BadgeFab(vm, bottom, onAdd, onAddHold)
    }
}

/** The original: tap opens the menu; press and hold pops a + out beside it. */
@Composable
private fun BoxScope.HoldFab(vm: BinderViewModel, bottom: Int, onAdd: () -> Unit, onAddHold: (() -> Unit)?) {
    var open by remember { mutableStateOf(false) }
    LaunchedEffect(open) {
        if (open) {
            delay(4000)
            open = false
        }
    }
    Row(
        Modifier.align(Alignment.BottomEnd).navigationBarsPadding()
            .padding(end = 16.dp, bottom = (bottom + 18).dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AnimatedVisibility(
            visible = open,
            enter = fadeIn() + scaleIn(initialScale = 0.4f) + slideInHorizontally { it / 2 },
            exit = fadeOut() + scaleOut(targetScale = 0.4f),
        ) {
            RoundBtn(
                Ic.Plus, "Add", 58.dp, Modifier.border(1.dp, P.line, CircleShape),
                onHold = onAddHold?.let { h -> { open = false; h() } },
            ) { open = false; onAdd() }
        }
        RoundBtn(Ic.Menu, "Menu", 58.dp, onHold = { open = true }) {
            if (open) open = false else vm.menu = true
        }
    }
}

/** Menu button (dark) and a white pill with "+ New bind" next to it. No holding needed. */
@Composable
private fun BoxScope.LabelFab(vm: BinderViewModel, bottom: Int, onAdd: () -> Unit, onAddHold: (() -> Unit)?, label: String) {
    Row(
        Modifier.align(Alignment.BottomEnd).navigationBarsPadding()
            .padding(end = 16.dp, bottom = (bottom + 18).dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(54.dp).clip(CircleShape).background(P.surface).border(1.dp, P.line, CircleShape)
                .tapHold({ vm.menu = true }),
            contentAlignment = Alignment.Center,
        ) { Icon(Ic.Menu, "Menu", tint = P.fg, modifier = Modifier.size(24.dp)) }
        Row(
            Modifier.height(54.dp).clip(CircleShape).background(P.primary)
                .tapHold(onAdd, onAddHold).padding(start = 14.dp, end = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Ic.Plus, null, tint = P.onPrimary, modifier = Modifier.size(22.dp))
            Txt(label, 15, P.onPrimary, weight = FontWeight.Medium, maxLines = 1)
        }
    }
}

private data class DialChoice(val icon: ImageVector, val label: String, val action: () -> Unit)

/** One labelled choice in the speed dial. */
@Composable
private fun DialItem(c: DialChoice, onPick: () -> Unit) {
    Row(
        Modifier.clip(CircleShape).background(P.surface).border(1.dp, P.line, CircleShape)
            .clickable { onPick(); c.action() }.padding(start = 14.dp, end = 18.dp, top = 12.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(c.icon, null, tint = P.fg, modifier = Modifier.size(20.dp))
        Txt(c.label, 14, weight = FontWeight.Medium, maxLines = 1)
    }
}

/**
 * Press and hold the menu button: it turns into a close button and labelled choices rise above it.
 * Where adding means "new bind" the choices are Media, Checklist, Tracker and Time (New bind opens with that kind
 * picked); anywhere else there is a single choice named [label]. Tap outside or on the button to close.
 */
@Composable
private fun BoxScope.DialFab(vm: BinderViewModel, bottom: Int, onAdd: () -> Unit, label: String, newBind: Boolean) {
    var open by remember { mutableStateOf(false) }
    val o = vm.opts
    val choices = if (newBind) listOf(
        DialChoice(Ic.Photo, "Media ${o.listLower}") { vm.newListKind = Kind.BOOKS; onAdd() },
        DialChoice(Ic.Check, "Checklist") { vm.newListKind = Kind.CHECKLIST; onAdd() },
        DialChoice(Ic.Star, "Tracker") { vm.newListKind = Kind.TRACKER; onAdd() },
        DialChoice(Ic.Clock, "Time") { vm.newListKind = Kind.TIME; onAdd() },
        DialChoice(Ic.Repeat, "Habits") { vm.newListKind = Kind.HABITS; onAdd() },
        DialChoice(Ic.Mic, "Heard") { vm.newListKind = Kind.HEARD; onAdd() },
    ) else listOf(DialChoice(Ic.Plus, label) { onAdd() })

    AnimatedVisibility(visible = open, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .pointerInput(Unit) { detectTapGestures { open = false } }
        )
    }
    Column(
        Modifier.align(Alignment.BottomEnd).navigationBarsPadding()
            .padding(end = 16.dp, bottom = (bottom + 18).dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        AnimatedVisibility(
            visible = open,
            enter = fadeIn() + slideInVertically { it / 4 },
            exit = fadeOut(),
        ) {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                choices.forEach { c -> DialItem(c) { open = false } }
            }
        }
        RoundBtn(if (open) Ic.Close else Ic.Menu, if (open) "Close" else "Menu", 58.dp, onHold = { open = true }) {
            if (open) open = false else vm.menu = true
        }
    }
}

/**
 * The menu button with a small accent + always sitting on its top-right corner.
 * Tap the badge to add (hold it for the other way of adding); tap the button for the menu.
 * The box is a little bigger than the button so the badge has a comfortable touch area.
 */
@Composable
private fun BoxScope.BadgeFab(vm: BinderViewModel, bottom: Int, onAdd: () -> Unit, onAddHold: (() -> Unit)?) {
    Box(
        Modifier.align(Alignment.BottomEnd).navigationBarsPadding()
            .padding(end = 4.dp, bottom = (bottom + 18).dp)
            .size(width = 70.dp, height = 74.dp)
    ) {
        RoundBtn(Ic.Menu, "Menu", 58.dp, Modifier.align(Alignment.BottomStart)) { vm.menu = true }
        Box(
            Modifier.align(Alignment.TopStart).offset(x = 30.dp, y = 4.dp).size(40.dp).tapHold(onAdd, onAddHold),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier.size(32.dp).clip(CircleShape).background(Coral).border(3.dp, P.bg, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Ic.Plus, "Add", tint = Color(0xFF111111), modifier = Modifier.size(16.dp)) }
        }
    }
}

// ───────── menu sheet ─────────

/** A floating sheet that rises from the bottom with a little room around it, over a dimmed screen. */
@Composable
private fun BoxScope.FloatingSheet(onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val st = remember { MutableTransitionState(false).apply { targetState = true } }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.42f)).pointerInput(Unit) { detectTapGestures { onClose() } })
    AnimatedVisibility(
        visibleState = st,
        modifier = Modifier.align(Alignment.BottomCenter),
        enter = slideInVertically { it / 2 } + fadeIn(),
    ) {
        val shape = RoundedCornerShape(36.dp)
        Column(
            Modifier.navigationBarsPadding().padding(start = 10.dp, end = 10.dp, bottom = 16.dp)
                .fillMaxWidth().clip(shape).background(P.bg).border(1.dp, P.line, shape)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            content = content,
        )
    }
}

/** One of the three big quick actions. The first one is drawn in the primary colour. */
@Composable
private fun MenuTile(icon: ImageVector, label: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    val fg = if (primary) P.onPrimary else P.fg
    Column(
        modifier.height(96.dp).clip(shape).background(if (primary) P.primary else P.surface)
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(26.dp))
        Txt(label, 15, fg, weight = FontWeight.Medium, maxLines = 1)
    }
}

/** A row in the card of links: round icon, title, a line of detail, and a chevron. */
@Composable
private fun MenuLink(icon: ImageVector, title: String, sub: String, divider: Boolean, onClick: () -> Unit) {
    if (divider) Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(1.dp).background(P.line))
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).heightIn(min = 64.dp).padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(P.bg), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = P.fg, modifier = Modifier.size(20.dp))
        }
        Column(Modifier.weight(1f)) {
            Txt(title, 16, maxLines = 1)
            Txt(sub, 13, P.mute, maxLines = 1)
        }
        Icon(Ic.Chevron, null, tint = P.mute, modifier = Modifier.size(20.dp))
    }
}

/**
 * Add item from the menu: on a list it adds to that list; anywhere else it asks which one.
 * A tracker takes a new entry, and everything else follows Settings > Adding items.
 */
private fun addItemFromMenu(vm: BinderViewModel) {
    val o = vm.opts
    val start = { l: BinderList ->
        if ((l.kind.hasOwnPage && !l.kind.isHeard) || o.add != AddStyle.SHEET) vm.nav.push(Route.ItemEdit(l.id, null)) else vm.quick = l.id
    }
    val here = (vm.nav.top as? Route.Lst)?.let { r -> vm.lists.firstOrNull { it.id == r.id } }
    val all = vm.lists.sortedByDescending { it.activity() }
    when {
        here != null -> start(here)
        all.isEmpty() -> vm.nav.push(Route.NewList)
        all.size == 1 -> start(all[0])
        else -> vm.sheet = SheetData("Add item to", all.map { l -> Act(l.name) { start(l) } })
    }
}

@Composable
fun BoxScope.MenuSheet(vm: BinderViewModel) {
    val o = vm.opts
    val nav = vm.nav
    val close = { vm.menu = false }
    val binds = vm.lists.size
    val items = vm.lists.sumOf { it.items.size }
    FloatingSheet(onClose = close) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt("Menu", 24, weight = FontWeight.Medium)
                Txt(
                    "$binds ${if (binds == 1) o.listLower else o.listsLower} · $items ${if (items == 1) "item" else "items"}",
                    14, P.mute, maxLines = 1,
                )
            }
            IconBtn(Ic.Close, "Close") { close() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MenuTile(Ic.Plus, "Add item", true, Modifier.weight(1f)) { close(); addItemFromMenu(vm) }
            MenuTile(Ic.Layers, "New ${o.listLower}", false, Modifier.weight(1f)) { close(); nav.push(Route.NewList) }
            MenuTile(Ic.Search, "Search", false, Modifier.weight(1f)) { close(); nav.push(Route.Search) }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(P.surface).padding(vertical = 4.dp)) {
            MenuLink(Ic.Sliders, "Settings", "Look, navigation and sources", false) { close(); nav.push(Route.More) }
            MenuLink(Ic.Download, "Backup and restore", "Save or restore a .zip of everything", true) {
                close(); nav.push(Route.Setting(SettingsPage.BACKUP))
            }
            MenuLink(Ic.Info, "About", "${o.appLabel} ${BuildConfig.VERSION_NAME} · Changelog · Licences", true) {
                close(); nav.push(Route.About)
            }
        }
    }
}

// ───────── About ─────────

private const val CHANGELOG = """1.0.0
• New look: menu button, round header buttons, rings and progress bars
• One App name switch (Binder or Catalog) sets the name, the icon, the label under the icon and the word for your lists
• Launcher icon: green with three list rows (Binder), ink on white (Catalog), both with a themed (monochrome) version
• Settings > Accent color: Green (default), Coral, Teal, Amber, Violet or Pink for progress lines, the + button, selected chips and links
• New Tracker list (mood, energy, sleep or anything you rate): Overview, Stats and History, with a New entry screen
• New Time list: how much of today, this week, this month and this year has passed (dots, percent, days left), plus any date you add, counted down the same way; its icon on the home screen can be days left (default), a calendar or a filling circle
• Albums can fetch cover, artist, year and genre from Apple Music (off by default)
• View options per list: columns and what shows under covers
• Items remember where their details came from
• More sources (each only when "Fetch details automatically" is on): TMDB for movies and series, RAWG for games, Open Library (with Google Books) for books and comics, AniList for manga and anime, Wikipedia for Anything, OpenStreetMap for places, and the title and picture of any other pasted web page
• New Manga and Comics lists
• A list can pick its source (list menu > Source, or the switcher in quick add)
• Details card also shows runtime, episodes, pages, volumes or platforms
• Ratings: fixed the part-filled star, which sat too far left. Stars are now drawn exactly. New Rating style option (Stars or a number like 4.75 ★) with a 0 to 5 slider in steps of 0.25
• The home screen has a view button next to the All / Media / Checklists chips; it opens a menu with every layout. Tiles now show a progress ring. New layouts: Compact, Fill, Grouped and Numerals
• Bento and Stacks no longer overlap or show placeholder gradients
• Settings page rebuilt in the same style as Paperback's (More is now called Settings): a summary card, grouped rows with icons, and a page for each group
• Header sizes like Paperback (Compact, Regular, Large) with a small page title under the menu button; Compact has no page title on the home screen
• New option: hide the coral progress line at the top of a list (Settings > Items & ratings)
• New Add button option (Settings > App style): Hold for +, Menu and label, Speed dial or Corner badge
• New menu: a floating sheet with Add item, New bind and Search, then Settings, Backup and restore and About
• A tracker now shows the face of its latest entry in your list instead of the progress ring

0.5
• Pictures, layouts, fonts, gestures, zip backup, Binder / Catalog name

0.1
• First version"""

private const val LICENCES = """Fonts: Outfit, Lora, Crimson Pro, Instrument Serif, Instrument Sans and Work Sans are used under the SIL Open Font License 1.1. The licence texts are in the FONT-LICENSES folder of the project.

Album details and covers come from the Apple Music (iTunes) search service when fetching is on. Apple and Apple Music are trademarks of Apple Inc. Binder is not affiliated with or endorsed by Apple.

Movie and series details and posters come from TMDB. This product uses the TMDB API but is not endorsed or certified by TMDB.

Game details and pictures come from RAWG (rawg.io).

Book details and covers come from Open Library (openlibrary.org), a project of the Internet Archive, and from Google Books when Open Library has nothing.

Place details come from OpenStreetMap (© OpenStreetMap contributors, ODbL, openstreetmap.org/copyright) through Nominatim.

Anime and manga details and covers come from AniList (anilist.co).

Text and pictures from Wikipedia are available under the Creative Commons Attribution-ShareAlike licence; each item keeps a link to its article. Other web pages are read through the title, picture and description they publish themselves (Open Graph tags)."""

@Composable
private fun InfoRow(title: String, trailing: String = "", body: String) {
    var open by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(26.dp)).background(P.surface)
            .clickable { open = !open }.padding(horizontal = 20.dp, vertical = 15.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(title, 15, modifier = Modifier.weight(1f))
            if (trailing.isNotEmpty()) Txt(trailing, 14, P.mute, Modifier.padding(end = 8.dp))
            Icon(Ic.Chevron, null, tint = P.mute, modifier = Modifier.size(18.dp))
        }
        if (open) Txt(body, 13, P.mute, Modifier.padding(top = 10.dp), lh = 19.sp)
    }
}

@Composable
fun AboutScreen(vm: BinderViewModel) {
    val o = vm.opts
    val ctx = LocalContext.current
    Screen {
        AppHeader(vm)
        PageLabel("About") { vm.nav.pop() }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Column(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(104.dp).clip(RoundedCornerShape(26.dp)).background(Color.White)
                        .border(1.dp, P.line, RoundedCornerShape(26.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    // the real launcher artwork, so About always shows the icon that is active
                    if (!o.isCatalog) Image(
                        painterResource(R.drawable.ic_launcher_binder_background),
                        contentDescription = null,
                        modifier = Modifier.size(104.dp),
                    )
                    Image(
                        painterResource(if (o.isCatalog) R.drawable.ic_launcher_catalog_foreground else R.drawable.ic_launcher_foreground),
                        contentDescription = o.appLabel,
                        modifier = Modifier.size(104.dp),
                    )
                }
                Txt("Version ${BuildConfig.VERSION_NAME}", 22, weight = FontWeight.Medium, modifier = Modifier.padding(top = 16.dp))
                Txt(
                    "${o.lists} and pictures stay on this phone. Only the text you search for is sent when fetching is on.",
                    14, P.mute, Modifier.padding(top = 6.dp, start = 12.dp, end = 12.dp), align = TextAlign.Center, lh = 20.sp,
                )
            }
            InfoRow(
                "Data", "On this phone",
                "Your ${o.listsLower} are saved in a file on this phone and your pictures in a folder next to it. Nothing is sent anywhere unless you turn on “Fetch details automatically” in Settings. Then only the words you type to search (or a link you paste) go to the source.",
            )
            InfoRow("Changelog", body = CHANGELOG)
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(CircleShape).background(P.surface)
                    .clickable { vm.nav.push(Route.Setting(SettingsPage.BACKUP)) }.padding(horizontal = 20.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Txt("Backup and restore", 15, modifier = Modifier.weight(1f))
                Icon(Ic.Chevron, null, tint = P.mute, modifier = Modifier.size(18.dp))
            }
            InfoRow("Licences", body = LICENCES)
            // RAWG asks for an active link back to RAWG wherever its data is used
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(CircleShape).background(P.surface)
                    .clickable { openLink(ctx, "https://rawg.io") }.padding(horizontal = 20.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Txt("Data from RAWG", 15, modifier = Modifier.weight(1f))
                Icon(Ic.Out, null, tint = P.mute, modifier = Modifier.size(18.dp))
            }
            Cap("PART OF THE FAMILY")
            FlowChips(listOf("Paperback", "Scrapbook", "Binder"), 2) { }
            Spacer(Modifier.height(40.dp))
        }
    }
}
