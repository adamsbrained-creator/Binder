package app.binder

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class RecognizeTest {
    @After fun reset() { Keys.audd = ""; Keys.acrHost = ""; Keys.acrKey = ""; Keys.acrSecret = "" }

    // The shape of a real AudD answer (trimmed to the fields Binder reads).
    private val audd = """
    {"status":"success","result":{"artist":"Imagine Dragons","title":"Warriors","album":"Warriors","release_date":"2014-09-18",
     "label":"Universal Music","timecode":"02:32","song_link":"https://lis.tn/Warriors",
     "apple_music":{"artwork":{"width":1500,"height":1500,"url":"https://is2-ssl.mzstatic.com/image/thumb/Music128/x/00602547623805.rgb.jpg/{w}x{h}bb.jpeg"},
       "artistName":"Imagine Dragons","url":"https://music.apple.com/us/album/warriors/1440831203?i=1440831624",
       "genreNames":["Alternative","Music"],"releaseDate":"2014-09-18","name":"Warriors","albumName":"Smoke + Mirrors (Deluxe)",
       "playParams":{"id":"1440831624","kind":"song"}}}}
    """.trimIndent()

    @Test fun auddAnswerBecomesASong() {
        val m = AuddRecognizer.parse(audd)!!
        assertEquals("Warriors", m.title)
        assertEquals("Imagine Dragons", m.artist)
        assertEquals("Warriors", m.album)
        assertEquals("2014", m.year)
        assertEquals("Alternative", m.genre)
        assertTrue(m.coverUrl.endsWith("/600x600bb.jpeg"))
        assertTrue(m.thumbUrl.endsWith("/300x300bb.jpeg"))
        assertEquals("Apple Music", m.sourceName)
        assertEquals("1440831624", m.sourceId)
        assertTrue(m.url.startsWith("https://music.apple.com/us/album/"))
    }

    @Test fun auddWithoutAppleDataFallsBackToDeezerThenToItsOwnLink() {
        val dz = """{"status":"success","result":{"artist":"A","title":"T","album":"Al","release_date":"2001-05-05",
            "song_link":"https://lis.tn/T","deezer":{"link":"https://www.deezer.com/track/9","album":{"cover_xl":"https://c/xl.jpg","cover_medium":"https://c/m.jpg"}}}}"""
        val d = AuddRecognizer.parse(dz)!!
        assertEquals("Deezer", d.sourceName); assertEquals("https://c/xl.jpg", d.coverUrl); assertEquals("https://c/m.jpg", d.thumbUrl)
        val bare = AuddRecognizer.parse("""{"status":"success","result":{"artist":"A","title":"T","song_link":"https://lis.tn/T"}}""")!!
        assertEquals("", bare.sourceName); assertEquals("https://lis.tn/T", bare.url); assertEquals("", bare.coverUrl)
    }

    @Test fun auddNoMatchIsNull() {
        assertNull(AuddRecognizer.parse("""{"status":"success","result":null}"""))
        assertNull(AuddRecognizer.parse("""{"status":"success","result":[]}"""))
    }

    @Test fun auddErrorsAreFailuresWithAMessage() {
        try {
            AuddRecognizer.parse("""{"status":"error","error":{"error_code":901,"error_message":"limit"}}""")
            fail()
        } catch (e: FetchFailure) {
            assertTrue(e.message!!.contains("no requests left"))
        }
    }

    @Test fun auddSendsTheTokenAndTheClip() {
        Keys.audd = "tok"
        var seen: Map<String, String> = emptyMap(); var field = ""; var size = 0
        val r = AuddRecognizer(upload = { _, f, ff, _, b -> seen = f; field = ff; size = b.size; """{"status":"success","result":null}""" })
        assertTrue(r.ready)
        assertNull(r.identify(ByteArray(10)))
        assertEquals("tok", seen["api_token"]); assertEquals("file", field); assertEquals(10, size)
        assertTrue(seen["return"]!!.contains("apple_music"))
        Keys.audd = ""
        assertTrue(!AuddRecognizer().ready)
    }

    @Test fun acrSignatureMatchesTheDocumentedRecipe() {
        // base64(HMAC-SHA1("s", "POST\n/v1/identify\nk\naudio\n1\n1700000000")), worked out independently
        assertEquals("Rz0v9Nh+ugLrHX8ccNBeybc9ck4=", AcrCloudRecognizer.signature("k", "s", "1700000000"))
    }

    @Test fun acrAnswerBecomesASong() {
        val json = """{"status":{"code":0,"msg":"Success"},"metadata":{"music":[{"title":"Here Comes the Sun",
            "artists":[{"name":"The Beatles"}],"album":{"name":"Abbey Road"},"release_date":"1969-09-26","genres":[{"name":"Rock"}],
            "external_metadata":{"deezer":{"track":{"id":12345}}}}]}}"""
        val m = AcrCloudRecognizer.parse(json)!!
        assertEquals("Here Comes the Sun", m.title); assertEquals("The Beatles", m.artist); assertEquals("Abbey Road", m.album)
        assertEquals("1969", m.year); assertEquals("Rock", m.genre)
        assertEquals("https://www.deezer.com/track/12345", m.url); assertEquals("Deezer", m.sourceName); assertEquals("12345", m.sourceId)
    }

    @Test fun acrNoResultIsNullAndLimitsAreFailures() {
        assertNull(AcrCloudRecognizer.parse("""{"status":{"code":1001,"msg":"No result"}}"""))
        try { AcrCloudRecognizer.parse("""{"status":{"code":3003,"msg":"limit"}}"""); fail() } catch (e: FetchFailure) { assertTrue(e.message!!.contains("limit")) }
    }

    @Test fun acrNeedsAllThreeKeys() {
        Keys.acrHost = "h"; Keys.acrKey = "k"
        assertTrue(!AcrCloudRecognizer().ready)
        Keys.acrSecret = "s"
        assertTrue(AcrCloudRecognizer().ready)
    }

    // ───────── the chain ─────────

    private class Fake(override val name: String, override val ready: Boolean = true, val answer: () -> SongMatch?) : SongRecognizer {
        var asked = 0
        override fun identify(wav: ByteArray): SongMatch? { asked++; return answer() }
    }
    private val song = SongMatch("T", "A")

    @Test fun theNextRecognizerTriesWhenOneFails() {
        val a = Fake("A") { throw FetchFailure("limit") }
        val b = Fake("B") { song }
        val out = Recognition(listOf(a, b)).run(ByteArray(1))
        assertEquals("B", (out as Outcome.Match).song.matchedBy)
    }

    @Test fun aMissFromOneStillAsksTheNext() {
        val a = Fake("A") { null }; val b = Fake("B") { song }
        assertTrue(Recognition(listOf(a, b)).run(ByteArray(1)) is Outcome.Match)
        assertEquals(1, b.asked)
    }

    @Test fun noMatchOnlyWhenSomeoneAnsweredAndNobodyKnows() {
        assertEquals(Outcome.NoMatch, Recognition(listOf(Fake("A") { null }, Fake("B") { throw FetchFailure("x") })).run(ByteArray(1)))
    }

    @Test fun noKeysAndSkippedRecognizers() {
        val off = Fake("A", ready = false) { song }
        assertEquals(Outcome.NoKeys, Recognition(listOf(off)).run(ByteArray(1)))
        assertEquals(0, off.asked)
    }

    @Test fun offlineStopsTheRound() {
        val b = Fake("B") { song }
        val out = Recognition(listOf(Fake("A") { throw FetchFailure("no net", offline = true) }, b)).run(ByteArray(1))
        assertEquals(Outcome.Offline, out); assertEquals(0, b.asked)
    }

    @Test fun everyoneFailingGivesTheLastMessage() {
        val out = Recognition(listOf(Fake("A") { throw FetchFailure("first") }, Fake("B") { throw FetchFailure("second") })).run(ByteArray(1))
        assertEquals("second", (out as Outcome.Failed).message)
    }

    @Test fun anAnswerThatCantBeReadIsAFailureNotACrash() {
        val out = Recognition(listOf(Fake("A") { throw org.json.JSONException("bad") })).run(ByteArray(1))
        assertTrue(out is Outcome.Failed)
    }

    // ───────── cover and details ─────────

    @Test fun enrichFillsInWhatIsMissing() {
        val hit = Found("Apple Music", "7", "https://music.apple.com/x?i=7", "Here Comes the Sun (Remastered 2009)", "The Beatles", "1969", "Rock", coverUrl = "https://c/600.jpg", thumbUrl = "https://c/100.jpg", extra = "Abbey Road")
        val m = SongLookup.enrich(SongMatch("Here Comes the Sun", "The Beatles"), search = { listOf(Found("x", "1", "", "Other", "Someone"), hit) })
        assertEquals("Abbey Road", m.album); assertEquals("1969", m.year); assertEquals("https://c/600.jpg", m.coverUrl)
        assertEquals("Apple Music", m.sourceName); assertEquals("https://music.apple.com/x?i=7", m.url)
    }

    @Test fun enrichNeverAttachesTheWrongSong() {
        val wrong = Found("Apple Music", "7", "u", "Something Else", "The Beatles", coverUrl = "c")
        val m = SongMatch("Here Comes the Sun", "The Beatles")
        assertEquals(m, SongLookup.enrich(m, search = { listOf(wrong) }))
        val sameTitleOtherArtist = Found("Apple Music", "8", "u", "Here Comes the Sun", "Richie Havens", coverUrl = "c")
        assertEquals(m, SongLookup.enrich(m, search = { listOf(sameTitleOtherArtist) }))
    }

    @Test fun enrichKeepsAFullMatchAndSurvivesASearchFailure() {
        val full = SongMatch("T", "A", album = "Al", coverUrl = "c", url = "u", sourceName = "Apple Music")
        assertEquals(full, SongLookup.enrich(full, search = { throw AssertionError("not needed") }))
        val bare = SongMatch("T", "A")
        assertEquals(bare, SongLookup.enrich(bare, search = { throw FetchFailure("down") }))
    }

    @Test fun albumIsFoundByTheSongsAppleLinkOrBySearch() {
        val album = Found("Apple Music", "1", "https://music.apple.com/us/album/x/1", "Abbey Road", "The Beatles")
        val viaLink = object : MetadataProvider {
            override val source = Source.APPLE
            override fun search(query: String) = emptyList<Found>()
            override fun handlesLink(url: String) = true
            override fun fromLink(url: String): Found? = album
        }
        assertEquals(album, SongLookup.albumOf("Abbey Road", "The Beatles", "https://music.apple.com/us/album/x/1?i=2", viaLink))
        val viaSearch = object : MetadataProvider {
            override val source = Source.APPLE
            override fun search(query: String) = listOf(Found("Apple Music", "9", "", "Greatest Hits", "The Beatles"), album)
            override fun handlesLink(url: String) = false
            override fun fromLink(url: String): Found? = null
        }
        assertEquals(album, SongLookup.albumOf("Abbey Road", "The Beatles", "https://www.deezer.com/track/3", viaSearch))
        assertNull(SongLookup.albumOf("", "x", "", viaSearch))
    }

    // ───────── the clip ─────────

    @Test fun wavHasAProperHeader() {
        val w = Wav.pack(ByteArray(100), 16000)
        assertEquals(144, w.size)
        assertEquals("RIFF", String(w, 0, 4)); assertEquals("WAVE", String(w, 8, 4)); assertEquals("data", String(w, 36, 4))
        assertEquals(100, (w[40].toInt() and 0xFF) or ((w[41].toInt() and 0xFF) shl 8))
        assertEquals(16000, (w[24].toInt() and 0xFF) or ((w[25].toInt() and 0xFF) shl 8) or ((w[26].toInt() and 0xFF) shl 16))
    }

    @Test fun levelIsZeroForSilenceAndGrowsWithSound() {
        assertEquals(0f, Wav.level(ByteArray(200), 200), 0f)
        assertEquals(0f, Wav.level(ByteArray(0), 0), 0f)
        val loud = ByteArray(200) { i -> if (i % 2 == 1) 0x40.toByte() else 0.toByte() } // samples of 0x4000
        assertTrue(Wav.level(loud, 200) > 0.9f)
    }
}
