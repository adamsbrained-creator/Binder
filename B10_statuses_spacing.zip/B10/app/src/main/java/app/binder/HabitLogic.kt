package app.binder

import java.util.TimeZone

// The plain maths of a Habits bind (no Compose, so it can be tested on a normal JVM). The screens are in Habits.kt.
//
// A habit is an Item: title = name, note = description, sub = its emoji, cover = its colour (index into HabitColors, -1 = accent),
// target = times a day (1 = done / not done), streakGoal = days (0 = none), marks = the check-ins.
// A check-in is saved against a day number (see epochDay) and says how many times the habit was done that day.

/** Day number: whole days since 1970-01-01 in the phone's own time zone. Check-ins are saved against it. */
fun epochDay(ms: Long): Int =
    Math.floorDiv(ms + TimeZone.getDefault().getOffset(ms), 86_400_000L).toInt()

/** Weekday of a day number in java.util.Calendar's numbering: Sunday = 1 ... Saturday = 7. */
fun dowOf(day: Int): Int = Math.floorMod(day + 4, 7) + 1

/** Which row of a week (0..6) a day sits in, when weeks start on [firstDow] (Calendar.firstDayOfWeek). */
fun rowInWeek(day: Int, firstDow: Int): Int = (dowOf(day) - firstDow + 7) % 7

/**
 * The day shown in one square of the heat map: [cols] weeks side by side, the last column is this week,
 * rows run from the first day of the week downwards. Squares after [today] are in the future.
 */
fun heatDay(today: Int, firstDow: Int, cols: Int, col: Int, row: Int): Int =
    today - (cols - 1 - col) * 7 - rowInWeek(today, firstDow) + row

// ───────── one habit ─────────

/** How many times a day the habit asks for (1 = a plain yes / no). */
fun Item.goal(): Int = target.coerceAtLeast(1)

fun Item.isCount(): Boolean = goal() > 1

fun Item.countOn(day: Int): Int = marks[day] ?: 0

fun Item.doneOn(day: Int): Boolean = countOn(day) >= goal()

/** 0..1: how far that day got (a count of 2 out of 4 is 0.5). */
fun Item.fractionOn(day: Int): Float = (countOn(day).toFloat() / goal()).coerceIn(0f, 1f)

fun Item.withCount(day: Int, n: Int): Item =
    copy(marks = if (n <= 0) marks - day else marks + (day to n))

/** A tap on a day: done <-> not done. A count goes up by one and starts over after the goal is passed. */
fun Item.tapped(day: Int): Item {
    val next = if (!isCount()) {
        if (doneOn(day)) 0 else 1
    } else {
        val c = countOn(day) + 1
        if (c > goal()) 0 else c
    }
    return withCount(day, next)
}

/** Days in a row that the habit was done, counted back from today. A today that is not done yet does not break the streak. */
fun Item.currentStreak(today: Int): Int {
    var d = if (doneOn(today)) today else today - 1
    var n = 0
    while (doneOn(d)) {
        n++
        d--
    }
    return n
}

fun Item.bestStreak(): Int {
    val days = marks.filter { it.value >= goal() }.keys.sorted()
    var best = 0
    var run = 0
    var prev = 0
    var first = true
    for (d in days) {
        run = if (!first && d == prev + 1) run + 1 else 1
        if (run > best) best = run
        prev = d
        first = false
    }
    return best
}

/** How many days the habit was done, ever. */
fun Item.daysDone(): Int = marks.count { it.value >= goal() }

/** 0..1: the share of days done since the habit was started (or its first check-in) up to today. */
fun Item.completionRate(today: Int): Float {
    val first = minOf(epochDay(added), marks.keys.minOrNull() ?: Int.MAX_VALUE)
    val span = (today - first + 1).coerceAtLeast(1)
    val done = marks.count { it.key in first..today && it.value >= goal() }
    return (done.toFloat() / span).coerceIn(0f, 1f)
}

/** The small line under a habit's name on its card. */
fun habitSubline(h: Item, today: Int): String {
    val streak = h.currentStreak(today)
    return when {
        h.isCount() && h.countOn(today) > 0 && !h.doneOn(today) -> "${h.countOn(today)} of ${h.goal()} today"
        streak > 0 -> "$streak day streak"
        h.note.isNotBlank() -> h.note
        else -> "Tap the check to start"
    }
}

// ───────── a whole bind ─────────

/** The streak goals you can pick (0 = none). */
val StreakGoals = listOf(0, 7, 21, 30, 66, 100)

fun streakGoalLabel(days: Int): String = if (days <= 0) "None" else "$days days"

fun habitsDoneToday(items: List<Item>, now: Long): Int {
    val today = epochDay(now)
    return items.count { it.doneOn(today) }
}

/** How much of today is done: the ring on Home. */
fun habitsFraction(items: List<Item>, now: Long): Float =
    if (items.isEmpty()) 0f else habitsDoneToday(items, now).toFloat() / items.size

fun habitsLine(items: List<Item>, now: Long): String =
    if (items.isEmpty()) "No habits yet" else "${habitsDoneToday(items, now)} of ${items.size} today"

/** The big thing on a small card: "2/5". */
fun habitsFace(items: List<Item>, now: Long): String = "${habitsDoneToday(items, now)}/${items.size}"
