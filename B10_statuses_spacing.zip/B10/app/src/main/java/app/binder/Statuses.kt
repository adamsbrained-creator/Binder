package app.binder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// ───────── renaming and hiding a bind's statuses (Idea / In progress / Done ...) ─────────
// Press and hold a bind (or open its menu) > Statuses. Names and the hidden one are saved on the bind (see Models.kt: stageNames, stageHidden),
// and every screen reads them through BinderList.stageLabel / liveStages, so the chips, the pickers, the sections and the progress all follow.

@Composable
fun BoxScope.StatusSheet(vm: BinderViewModel, l: BinderList) {
    val defaults = l.kind.stages
    // what each status is called right now (the bind's own name, or the kind's)
    val names = remember(l.id) { mutableStateListOf<String>().apply { addAll(defaults.indices.map { l.stageLabel(it) }) } }
    var hidden by remember(l.id) {
        mutableStateOf(if (defaults.size - l.stageHidden.size >= 2) l.stageHidden.filter { it in defaults.indices }.toSet() else emptySet<Int>())
    }
    val close = { vm.statusFor = null }
    val inUse = defaults.indices.filter { it !in hidden }
    val canHideMore = inUse.size > 2

    SheetFrame(close) {
        Txt("Statuses", 22, weight = FontWeight.Medium)
        Txt(
            "Rename or hide the statuses of ${l.name}. The first one showing is where new ${l.kind.noun} start; the last one counts as done.",
            12, P.mute, Modifier.padding(top = 2.dp, bottom = 14.dp),
        )
        Column(
            Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            defaults.forEachIndexed { i, def ->
                val off = i in hidden
                val role = when {
                    off -> " · hidden"
                    i == inUse.first() -> " · start"
                    i == inUse.last() -> " · counts as done"
                    else -> ""
                }
                val canToggle = off || canHideMore
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Field("$def$role", names[i], Modifier.weight(1f).alpha(if (off) 0.5f else 1f)) { names[i] = it }
                    Box(
                        Modifier.height(48.dp).clip(CircleShape)
                            .background(if (off) Coral else P.surface)
                            .alpha(if (canToggle) 1f else 0.4f)
                            .clickable(enabled = canToggle) { hidden = if (off) hidden - i else hidden + i }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) { Txt(if (off) "Show" else "Hide", 14, if (off) Color(0xFF111111) else P.fg) }
                }
            }
        }
        Txt(
            "At least two statuses stay showing. ${l.kind.noun.replaceFirstChar { it.uppercase() }} in a hidden status are listed under the one before it, and come back to it when you show it again.",
            12, P.mute, Modifier.padding(top = 12.dp),
        )
        Txt(
            "Reset to the original names",
            14, P.mute,
            Modifier.clip(CircleShape).clickable {
                defaults.indices.forEach { names[it] = defaults[it] }
                hidden = emptySet()
            }.padding(vertical = 12.dp),
        )
        BigButton("Save") {
            // a name that is blank or the original is saved as "" (the kind's own name)
            vm.setStatuses(l.id, names.mapIndexed { i, n -> if (n.trim() == defaults[i]) "" else n.trim() }, hidden)
            close()
        }
    }
}
