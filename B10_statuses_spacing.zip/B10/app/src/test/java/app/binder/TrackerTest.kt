package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackerTest {

    @Test fun ratingPicksTheFace() {
        assertEquals(0, levelOf(1f))
        assertEquals(1, levelOf(3f))
        assertEquals(2, levelOf(5f))
        assertEquals(3, levelOf(6.8f))
        assertEquals(4, levelOf(9f))
        assertEquals(4, levelOf(10f))
        assertEquals(0, levelOf(0f))
    }

    @Test fun eachFaceStartsAtItsOwnRating() {
        for (face in 0..4) assertEquals(face, levelOf(defaultRating(face).toFloat()))
    }

    @Test fun averageOfNothingIsZero() {
        assertEquals(0f, emptyList<Item>().averageRating())
        assertEquals(6f, listOf(Item(title = "Good", rating = 7f), Item(title = "Low", rating = 5f)).averageRating())
    }

    @Test fun daysStartAtMidnightAndStepBack() {
        val now = 1_760_000_000_000L
        val today = startOfDay(now)
        assertTrue(today <= now && now - today < 25L * 3600_000)
        assertEquals(today, startOfDay(today + 3600_000))
        assertTrue(startOfDay(now, -1) < today)
    }

    @Test fun aTrackerSavesAndLoadsLikeAnyBind() {
        val entry = Item(title = "Good", stage = 3, rating = 7f, note = "Quiet start", added = 42)
        val l = BinderList(name = "Energy", kind = Kind.TRACKER, layout = Layout.LIST, items = listOf(entry))
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals(Kind.TRACKER, back.kind)
        assertEquals(entry, back.items.single())
        assertEquals(0.7f, back.progress(), 0.001f)   // the bar follows the latest rating
        assertEquals(0, back.doneCount())             // "Great" entries are not "done"
        assertEquals("1 entry", back.countLabel())
    }
}

class AccentTest {
    // Theme.kt holds fonts and colours (it needs Android to load), so only the saved choice is checked here.
    @Test fun accentDefaultsToGreen() {
        assertEquals(4, Opts().accent)
        assertEquals(3, Opts().copy(accent = 3).accent)
    }
}
