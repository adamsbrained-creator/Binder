package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GroupsTest {
    private val g = Group(id = "g1", name = "The Beatles")
    private val list = BinderList(
        id = "m", name = "Music Albums", kind = Kind.ALBUMS, groups = listOf(g),
        items = listOf(
            Item(id = "a", title = "Help!", sub = "The Beatles", group = "g1"),
            Item(id = "b", title = "Revolver", sub = "The Beatles", group = "g1"),
            Item(id = "c", title = "Thriller", sub = "Michael Jackson"),
            Item(id = "d", title = "Old", sub = "X", group = "gone"),   // its group was deleted
        ),
    )

    @Test fun itemsLiveInTheirGroupOrTheMainList() {
        assertEquals(listOf("a", "b"), list.itemsIn("g1").map { it.id })
        assertEquals(listOf("c", "d"), list.itemsIn("").map { it.id })   // a missing group falls back to the main list
        assertEquals("", list.groupIdOf(list.items[3]))
    }

    @Test fun aNewGroupIsNamedAfterTheArtistTheyShare() {
        assertEquals("The Beatles", list.commonSub(setOf("a", "b")))
        assertEquals("", list.commonSub(setOf("a", "c")))
        assertEquals("", list.commonSub(emptySet()))
    }

    @Test fun groupsAreSavedAndLoaded() {
        val back = parseLists(listsToJson(listOf(list)).toString()).single()
        assertEquals(listOf(g), back.groups)
        assertEquals(listOf("g1", "g1", "", "gone"), back.items.map { it.group })
        // a bind without groups writes nothing extra and loads with none
        val plain = parseLists(listsToJson(listOf(list.copy(groups = emptyList(), items = emptyList()))).toString()).single()
        assertTrue(plain.groups.isEmpty())
    }
}
