package app.binder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StatusesTest {

    private fun bind(
        names: List<String> = emptyList(), hidden: Set<Int> = emptySet(), stages: List<Int> = emptyList(),
        kind: Kind = Kind.ANYTHING,
    ) = BinderList(
        name = "Watch", kind = kind, stageNames = names, stageHidden = hidden,
        items = stages.mapIndexed { n, s -> Item(id = "i$n", title = "t$n", stage = s) },
    )

    @Test fun aBindWithNothingChangedUsesTheKindsOwnStatuses() {
        val l = bind(stages = listOf(0, 1, 2))
        assertEquals(listOf("Idea", "In progress", "Done"), l.stageLabels())
        assertEquals(listOf(0, 1, 2), l.liveStages)
        assertEquals(1, l.doneCount())
    }

    @Test fun renamingChangesOnlyTheNameShown() {
        val l = bind(names = listOf("To watch", "", "Seen"), stages = listOf(0, 1, 2))
        assertEquals(listOf("To watch", "In progress", "Seen"), l.stageLabels())
        assertEquals("To watch", l.stageLabel(l.stageOf(l.items[0])))
        assertEquals(0, l.items[0].stage)       // what is saved on the item is still the number
    }

    @Test fun aHiddenMiddleStatusSendsItsItemsBackToTheOneBefore() {
        val l = bind(hidden = setOf(1), stages = listOf(0, 1, 2))
        assertEquals(listOf(0, 2), l.liveStages)
        assertEquals(listOf("Idea", "Done"), l.stageLabels())
        assertEquals(0, l.stageOf(l.items[1]))
        assertEquals(1, l.doneCount())
        assertEquals(2, l.nextStage(l.items[0]))
        assertEquals(0, l.nextStage(l.items[2]))      // after the last one it wraps
    }

    @Test fun hidingTheFirstStatusMakesTheNextOneTheStart() {
        val l = bind(hidden = setOf(0), stages = listOf(0, 1, 2))
        assertEquals(1, l.startStage)
        assertEquals(1, l.stageOf(l.items[0]))        // nothing is below it, so it moves up to the first one showing
        assertEquals(2, l.endStage)
    }

    @Test fun hidingTheLastStatusMakesTheOneBeforeItTheFinishLine() {
        val l = bind(hidden = setOf(2), stages = listOf(0, 1, 2))
        assertEquals(1, l.endStage)
        assertEquals(2, l.doneCount())                // the item in "Done" and the one in "In progress" both finish
        assertEquals(1f, bind(hidden = setOf(2), stages = listOf(1, 2)).progress(), 0.001f)
    }

    @Test fun atLeastTwoStatusesAlwaysStayShowing() {
        val l = bind(hidden = setOf(0, 1), stages = listOf(0, 1, 2))
        assertEquals(listOf(0, 1, 2), l.liveStages)   // an unusable file falls back to everything
    }

    @Test fun checklistsAndOwnPageBindsAreLeftAlone() {
        val check = bind(hidden = setOf(0), kind = Kind.CHECKLIST, stages = listOf(0, 1))
        assertFalse(check.hasEditableStages)
        assertEquals(listOf(0, 1), check.liveStages)
        assertFalse(bind(kind = Kind.HABITS).hasEditableStages)
        assertTrue(bind(kind = Kind.MOVIES).hasEditableStages)
    }

    @Test fun namesAndHiddenStatusesSurviveSaving() {
        val l = bind(names = listOf("To watch", "", "Seen"), hidden = setOf(1), stages = listOf(0, 2))
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals(listOf("To watch", "", "Seen"), back.stageNames)
        assertEquals(setOf(1), back.stageHidden)
        assertEquals(listOf("To watch", "Seen"), back.stageLabels())
    }

    @Test fun anOlderFileHasNoStatusKeysAndLoadsUnchanged() {
        val json = listsToJson(listOf(bind(stages = listOf(1)))).toString()
        assertFalse(json.contains("stageNames"))
        assertFalse(json.contains("stageHidden"))
        val back = parseLists(json).single()
        assertTrue(back.stageNames.isEmpty())
        assertTrue(back.stageHidden.isEmpty())
    }

    @Test fun aHabitsBindWearsTheEmojiOfItsTopHabit() {
        val none = BinderList(name = "Habits", kind = Kind.HABITS)
        assertNull(none.habitEmoji())
        val one = none.copy(items = listOf(Item(title = "Reading", sub = "📖")))
        assertEquals("📖", one.habitEmoji())
        val blank = none.copy(items = listOf(Item(title = "Run", sub = "")))
        assertEquals("✨", blank.habitEmoji())
        assertNull(BinderList(name = "Books", kind = Kind.BOOKS, items = listOf(Item(title = "x", sub = "📖"))).habitEmoji())
    }
}
