package app.binder

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class HabitsTest {

    private val noon = Calendar.getInstance().apply {
        set(2026, Calendar.OCTOBER, 16, 12, 0, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    @Test fun dayNumbersFollowTheCalendar() {
        val next = Calendar.getInstance().apply { timeInMillis = noon; add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
        assertEquals(epochDay(noon) + 1, epochDay(next))
        assertEquals(epochDay(noon), epochDay(startOfDay(noon)))
        assertEquals(epochDay(noon) - 9, epochDay(startOfDay(noon, -9)))
    }

    @Test fun weekdaysMatchTheCalendar() {
        val cal = Calendar.getInstance().apply { timeInMillis = noon }
        assertEquals(cal.get(Calendar.DAY_OF_WEEK), dowOf(epochDay(noon)))
        assertEquals(Calendar.THURSDAY, dowOf(0))   // 1 January 1970
    }

    @Test fun theHeatMapEndsOnToday() {
        val today = epochDay(noon)
        for (first in listOf(Calendar.SUNDAY, Calendar.MONDAY)) {
            val row = rowInWeek(today, first)
            assertEquals(today, heatDay(today, first, 26, 25, row))        // last column, today's own row
            assertEquals(today - 7, heatDay(today, first, 26, 24, row))    // the same weekday a week before
            assertEquals(today - row, heatDay(today, first, 26, 25, 0))    // the first day of this week
            assertTrue(heatDay(today, first, 26, 25, 6) >= today)          // the rest of this week is still to come
        }
    }

    @Test fun aTapTicksAndUnticksADay() {
        val on = Item(title = "Read").tapped(100)
        assertTrue(on.doneOn(100))
        assertEquals(1, on.countOn(100))
        val off = on.tapped(100)
        assertFalse(off.doneOn(100))
        assertTrue(off.marks.isEmpty())
    }

    @Test fun aCountGoesUpOneAtATimeAndStartsOver() {
        val water = Item(title = "Water", target = 3)
        assertTrue(water.isCount())
        val one = water.tapped(5)
        assertEquals(1, one.countOn(5))
        assertFalse(one.doneOn(5))
        assertEquals(1f / 3f, one.fractionOn(5), 0.001f)
        val three = one.tapped(5).tapped(5)
        assertTrue(three.doneOn(5))
        assertTrue(three.tapped(5).marks.isEmpty())   // one tap past the goal starts over
    }

    @Test fun streaksCountDaysInARow() {
        val h = listOf(10, 11, 12, 14, 15).fold(Item(title = "Run")) { acc, d -> acc.tapped(d) }
        assertEquals(2, h.currentStreak(15))
        assertEquals(2, h.currentStreak(16))   // today is not done yet: yesterday's streak still stands
        assertEquals(0, h.currentStreak(17))   // two days missed
        assertEquals(3, h.bestStreak())
        assertEquals(5, h.daysDone())
        assertEquals(0, Item(title = "New").bestStreak())
    }

    @Test fun completionIsTheShareOfDaysDoneSinceTheStart() {
        val today = epochDay(noon)
        val started = Item(title = "x", added = startOfDay(noon, -9))   // ten days, counting today
        val done = (0..4).fold(started) { acc, back -> acc.tapped(today - back) }
        assertEquals(0.5f, done.completionRate(today), 0.001f)
        assertEquals(0f, started.completionRate(today), 0.001f)
    }

    @Test fun theLineUnderAHabit() {
        val h = Item(title = "Read", note = "Ten pages")
        assertEquals("Ten pages", habitSubline(h, 20))
        assertEquals("Tap the check to start", habitSubline(Item(title = "Read"), 20))
        assertEquals("1 day streak", habitSubline(h.tapped(20), 20))
        assertEquals("2 of 3 today", habitSubline(Item(title = "Water", target = 3).tapped(20).tapped(20), 20))
    }

    @Test fun aHabitsBindSummarisesToday() {
        val now = System.currentTimeMillis()
        val today = epochDay(now)
        val items = listOf(Item(title = "a").tapped(today), Item(title = "b"), Item(title = "c").tapped(today))
        assertEquals(2, habitsDoneToday(items, now))
        assertEquals("2 of 3 today", habitsLine(items, now))
        assertEquals("2/3", habitsFace(items, now))
        assertEquals(2f / 3f, habitsFraction(items, now), 0.001f)
        assertEquals("No habits yet", habitsLine(emptyList(), now))

        val l = BinderList(name = "Habits", kind = Kind.HABITS, layout = Layout.LIST, items = items)
        assertEquals(2f / 3f, l.progress(), 0.001f)
        assertEquals("2/3", l.cardFace())
        assertEquals("2 of 3 today", l.entryLine())
        assertEquals(0, l.doneCount())
        assertTrue(Kind.HABITS.hasOwnPage && Kind.HABITS.isHabits)
        assertEquals(listOf(Layout.LIST), Kind.HABITS.layouts)
    }

    @Test fun habitsSaveAndLoadLikeAnyBind() {
        val habit = Item(
            id = "h1", title = "Read", sub = "📚", note = "Ten pages", cover = 9, target = 3, streakGoal = 30,
            marks = mapOf(20000 to 3, 20001 to 1), added = 42,
        )
        val l = BinderList(id = "b", name = "Habits", kind = Kind.HABITS, layout = Layout.LIST, items = listOf(habit))
        val back = parseLists(listsToJson(listOf(l)).toString()).single()
        assertEquals(Kind.HABITS, back.kind)
        assertEquals(habit, back.items.single())

        // a plain habit writes none of the new keys
        val json = JSONObject(listsToJson(listOf(l.copy(items = listOf(Item(id = "p", title = "Run"))))).toString())
        val plain = json.getJSONArray("lists").getJSONObject(0).getJSONArray("items").getJSONObject(0)
        assertFalse(plain.has("marks"))
        assertFalse(plain.has("target"))
        assertFalse(plain.has("streakGoal"))
    }

    @Test fun olderFilesLoadWithNoHabitData() {
        val old = """{"format":"binder","version":3,"lists":[{"id":"a","name":"Books","kind":"BOOKS","layout":"GRID","sort":"MANUAL",""" +
            """"pinned":false,"created":1,"columns":3,"under":["TITLE"],"items":[{"id":"i","title":"Dune","added":5}]}]}"""
        val item = parseLists(old).single().items.single()
        assertTrue(item.marks.isEmpty())
        assertEquals(1, item.target)
        assertEquals(0, item.streakGoal)
    }
}
